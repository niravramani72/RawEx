package com.example.arkarcy.rawx;

import com.google.firebase.database.Exclude;

public class modelcate {
    public String Name;

    public modelcate() {
    }

    public modelcate(String Name) {
        this.Name = Name;
    }
    @Exclude
    public String getName() {
        return Name;
    }
    @Exclude
    public void setName(String name) {
        this.Name = name;
    }
}
