package com.example.arkarcy.rawx;

import com.google.firebase.database.Exclude;

public class modelBook {
    public String  BookName,CoverImage,BookAuthor,Genres1,Genres2,Genres3,Rating,RatingInReverse,AppRating,AppUserNumber;
    public String Comment101,Comment102,Comment103,Comment104,Comment105,Comment106,Comment107,Comment108,Comment109,Comment110,Comment111,Comment112,Comment113,Comment114,Comment115;
    public String Comment201,Comment202,Comment203,Comment204,Comment205,Comment206,Comment207,Comment208,Comment209,Comment210,Comment211,Comment212,Comment213,Comment214,Comment215;
    public String Comment301,Comment302,Comment303,Comment304,Comment305,Comment306,Comment307,Comment308,Comment309,Comment310,Comment311,Comment312,Comment313,Comment314,Comment315;
    public String Abstract101,Abstract102,Abstract103,Abstract104,Abstract105,Abstract106,Abstract107,Abstract108,Abstract109,Abstract110,Abstract111,Abstract112,Abstract113,Abstract114,Abstract115;
    public modelBook() {
    }

    @Exclude
    public String getAppRating() {
        return AppRating;
    }
    @Exclude
    public void setAppRating(String appRating) {
        AppRating = appRating;
    }
    @Exclude
    public String getAppUserNumber() {
        return AppUserNumber;
    }
    @Exclude
    public void setAppUserNumber(String appUserNumber) {
        AppUserNumber = appUserNumber;
    }

    @Exclude
    public String getBookName() {
        return BookName;
    }
    @Exclude
    public void setBookName(String bookName) {
        BookName = bookName;
    }
    @Exclude
    public String getCoverImage() {
        return CoverImage;
    }
    @Exclude
    public void setCoverImage(String coverImage) {
        CoverImage = coverImage;
    }
    @Exclude
    public String getBookAuthor() {
        return BookAuthor;
    }
    @Exclude
    public void setBookAuthor(String bookAuthor) {
        BookAuthor = bookAuthor;
    }
    @Exclude
    public String getGenres1() {
        return Genres1;
    }
    @Exclude
    public void setGenres1(String genres1) {
        Genres1 = genres1;
    }
    @Exclude
    public String getGenres2() {
        return Genres2;
    }
    @Exclude
    public void setGenres2(String genres2) {
        Genres2 = genres2;
    }
    @Exclude
    public String getGenres3() {
        return Genres3;
    }
    @Exclude
    public void setGenres3(String genres3) {
        Genres3 = genres3;
    }
    @Exclude
    public String getRating() {
        return Rating;
    }
    @Exclude
    public void setRating(String rating) {
        Rating = rating;
    }
    @Exclude
    public String getRatingInReverse() {
        return RatingInReverse;
    }
    @Exclude
    public void setRatingInReverse(String ratingInReverse) {
        RatingInReverse = ratingInReverse;
    }
    @Exclude
    public String getComment101() {
        return Comment101;
    }
    @Exclude
    public void setComment101(String comment101) {
        Comment101 = comment101;
    }
    @Exclude
    public String getComment102() {
        return Comment102;
    }
    @Exclude
    public void setComment102(String comment102) {
        Comment102 = comment102;
    }
    @Exclude
    public String getComment103() {
        return Comment103;
    }
    @Exclude
    public void setComment103(String comment103) {
        Comment103 = comment103;
    }
    @Exclude
    public String getComment104() {
        return Comment104;
    }
    @Exclude
    public void setComment104(String comment104) {
        Comment104 = comment104;
    }
    @Exclude
    public String getComment105() {
        return Comment105;
    }
    @Exclude
    public void setComment105(String comment105) {
        Comment105 = comment105;
    }
    @Exclude
    public String getComment106() {
        return Comment106;
    }
    @Exclude
    public void setComment106(String comment106) {
        Comment106 = comment106;
    }
    @Exclude
    public String getComment107() {
        return Comment107;
    }
    @Exclude
    public void setComment107(String comment107) {
        Comment107 = comment107;
    }
    @Exclude
    public String getComment108() {
        return Comment108;
    }
    @Exclude
    public void setComment108(String comment108) {
        Comment108 = comment108;
    }
    @Exclude
    public String getComment109() {
        return Comment109;
    }
    @Exclude
    public void setComment109(String comment109) {
        Comment109 = comment109;
    }
    @Exclude
    public String getComment110() {
        return Comment110;
    }
    @Exclude
    public void setComment110(String comment110) {
        Comment110 = comment110;
    }
    @Exclude
    public String getComment111() {
        return Comment111;
    }
    @Exclude
    public void setComment111(String comment111) {
        Comment111 = comment111;
    }
    @Exclude
    public String getComment112() {
        return Comment112;
    }
    @Exclude
    public void setComment112(String comment112) {
        Comment112 = comment112;
    }
    @Exclude
    public String getComment113() {
        return Comment113;
    }
    @Exclude
    public void setComment113(String comment113) {
        Comment113 = comment113;
    }
    @Exclude
    public String getComment114() {
        return Comment114;
    }
    @Exclude
    public void setComment114(String comment114) {
        Comment114 = comment114;
    }
    @Exclude
    public String getComment115() {
        return Comment115;
    }
    @Exclude
    public void setComment115(String comment115) {
        Comment115 = comment115;
    }
    @Exclude
    public String getComment201() {
        return Comment201;
    }
    @Exclude
    public void setComment201(String comment201) {
        Comment201 = comment201;
    }
    @Exclude
    public String getComment202() {
        return Comment202;
    }
    @Exclude
    public void setComment202(String comment202) {
        Comment202 = comment202;
    }
    @Exclude
    public String getComment203() {
        return Comment203;
    }
    @Exclude
    public void setComment203(String comment203) {
        Comment203 = comment203;
    }
    @Exclude
    public String getComment204() {
        return Comment204;
    }
    @Exclude
    public void setComment204(String comment204) {
        Comment204 = comment204;
    }
    @Exclude
    public String getComment205() {
        return Comment205;
    }
    @Exclude
    public void setComment205(String comment205) {
        Comment205 = comment205;
    }
    @Exclude
    public String getComment206() {
        return Comment206;
    }
    @Exclude
    public void setComment206(String comment206) {
        Comment206 = comment206;
    }
    @Exclude
    public String getComment207() {
        return Comment207;
    }
    @Exclude
    public void setComment207(String comment207) {
        Comment207 = comment207;
    }
    @Exclude
    public String getComment208() {
        return Comment208;
    }
    @Exclude
    public void setComment208(String comment208) {
        Comment208 = comment208;
    }
    @Exclude
    public String getComment209() {
        return Comment209;
    }
    @Exclude
    public void setComment209(String comment209) {
        Comment209 = comment209;
    }
    @Exclude
    public String getComment210() {
        return Comment210;
    }
    @Exclude
    public void setComment210(String comment210) {
        Comment210 = comment210;
    }
    @Exclude
    public String getComment211() {
        return Comment211;
    }
    @Exclude
    public void setComment211(String comment211) {
        Comment211 = comment211;
    }
    @Exclude
    public String getComment212() {
        return Comment212;
    }
    @Exclude
    public void setComment212(String comment212) {
        Comment212 = comment212;
    }
    @Exclude
    public String getComment213() {
        return Comment213;
    }
    @Exclude
    public void setComment213(String comment213) {
        Comment213 = comment213;
    }
    @Exclude
    public String getComment214() {
        return Comment214;
    }
    @Exclude
    public void setComment214(String comment214) {
        Comment214 = comment214;
    }
    @Exclude
    public String getComment215() {
        return Comment215;
    }
    @Exclude
    public void setComment215(String comment215) {
        Comment215 = comment215;
    }
    @Exclude
    public String getComment301() {
        return Comment301;
    }
    @Exclude
    public void setComment301(String comment301) {
        Comment301 = comment301;
    }
    @Exclude
    public String getComment302() {
        return Comment302;
    }
    @Exclude
    public void setComment302(String comment302) {
        Comment302 = comment302;
    }
    @Exclude
    public String getComment303() {
        return Comment303;
    }
    @Exclude
    public void setComment303(String comment303) {
        Comment303 = comment303;
    }
    @Exclude
    public String getComment304() {
        return Comment304;
    }
    @Exclude
    public void setComment304(String comment304) {
        Comment304 = comment304;
    }
    @Exclude
    public String getComment305() {
        return Comment305;
    }
    @Exclude
    public void setComment305(String comment305) {
        Comment305 = comment305;
    }
    @Exclude
    public String getComment306() {
        return Comment306;
    }
    @Exclude
    public void setComment306(String comment306) {
        Comment306 = comment306;
    }
    @Exclude
    public String getComment307() {
        return Comment307;
    }
    @Exclude
    public void setComment307(String comment307) {
        Comment307 = comment307;
    }
    @Exclude
    public String getComment308() {
        return Comment308;
    }
    @Exclude
    public void setComment308(String comment308) {
        Comment308 = comment308;
    }
    @Exclude
    public String getComment309() {
        return Comment309;
    }
    @Exclude
    public void setComment309(String comment309) {
        Comment309 = comment309;
    }
    @Exclude
    public String getComment310() {
        return Comment310;
    }
    @Exclude
    public void setComment310(String comment310) {
        Comment310 = comment310;
    }
    @Exclude
    public String getComment311() {
        return Comment311;
    }
    @Exclude
    public void setComment311(String comment311) {
        Comment311 = comment311;
    }
    @Exclude
    public String getComment312() {
        return Comment312;
    }
    @Exclude
    public void setComment312(String comment312) {
        Comment312 = comment312;
    }
    @Exclude
    public String getComment313() {
        return Comment313;
    }
    @Exclude
    public void setComment313(String comment313) {
        Comment313 = comment313;
    }
    @Exclude
    public String getComment314() {
        return Comment314;
    }
    @Exclude
    public void setComment314(String comment314) {
        Comment314 = comment314;
    }
    @Exclude
    public String getComment315() {
        return Comment315;
    }
    @Exclude
    public void setComment315(String comment315) {
        Comment315 = comment315;
    }
    @Exclude
    public String getAbstract101() {
        return Abstract101;
    }
    @Exclude
    public void setAbstract101(String abstract101) {
        Abstract101 = abstract101;
    }
    @Exclude
    public String getAbstract102() {
        return Abstract102;
    }
    @Exclude
    public void setAbstract102(String abstract102) {
        Abstract102 = abstract102;
    }
    @Exclude
    public String getAbstract103() {
        return Abstract103;
    }
    @Exclude
    public void setAbstract103(String abstract103) {
        Abstract103 = abstract103;
    }
    @Exclude
    public String getAbstract104() {
        return Abstract104;
    }
    @Exclude
    public void setAbstract104(String abstract104) {
        Abstract104 = abstract104;
    }
    @Exclude
    public String getAbstract105() {
        return Abstract105;
    }
    @Exclude
    public void setAbstract105(String abstract105) {
        Abstract105 = abstract105;
    }
    @Exclude
    public String getAbstract106() {
        return Abstract106;
    }
    @Exclude
    public void setAbstract106(String abstract106) {
        Abstract106 = abstract106;
    }
    @Exclude
    public String getAbstract107() {
        return Abstract107;
    }
    @Exclude
    public void setAbstract107(String abstract107) {
        Abstract107 = abstract107;
    }
    @Exclude
    public String getAbstract108() {
        return Abstract108;
    }
    @Exclude
    public void setAbstract108(String abstract108) {
        Abstract108 = abstract108;
    }
    @Exclude
    public String getAbstract109() {
        return Abstract109;
    }
    @Exclude
    public void setAbstract109(String abstract109) {
        Abstract109 = abstract109;
    }
    @Exclude
    public String getAbstract110() {
        return Abstract110;
    }
    @Exclude
    public void setAbstract110(String abstract110) {
        Abstract110 = abstract110;
    }
    @Exclude
    public String getAbstract111() {
        return Abstract111;
    }
    @Exclude
    public void setAbstract111(String abstract111) {
        Abstract111 = abstract111;
    }
    @Exclude
    public String getAbstract112() {
        return Abstract112;
    }
    @Exclude
    public void setAbstract112(String abstract112) {
        Abstract112 = abstract112;
    }
    @Exclude
    public String getAbstract113() {
        return Abstract113;
    }
    @Exclude
    public void setAbstract113(String abstract113) {
        Abstract113 = abstract113;
    }
    @Exclude
    public String getAbstract114() {
        return Abstract114;
    }
    @Exclude
    public void setAbstract114(String abstract114) {
        Abstract114 = abstract114;
    }
    @Exclude
    public String getAbstract115() {
        return Abstract115;
    }
    @Exclude
    public void setAbstract115(String abstract115) {
        Abstract115 = abstract115;
    }

    public modelBook(String bookName , String coverImage , String bookAuthor , String genres1 , String genres2 , String genres3 , String rating , String ratingInReverse , String appRating , String appUserNumber , String comment101 , String comment102 , String comment103 , String comment104 , String comment105 , String comment106 , String comment107 , String comment108 , String comment109 , String comment110 , String comment111 , String comment112 , String comment113 , String comment114 , String comment115 , String comment201 , String comment202 , String comment203 , String comment204 , String comment205 , String comment206 , String comment207 , String comment208 , String comment209 , String comment210 , String comment211 , String comment212 , String comment213 , String comment214 , String comment215 , String comment301 , String comment302 , String comment303 , String comment304 , String comment305 , String comment306 , String comment307 , String comment308 , String comment309 , String comment310 , String comment311 , String comment312 , String comment313 , String comment314 , String comment315 , String abstract101 , String abstract102 , String abstract103 , String abstract104 , String abstract105 , String abstract106 , String abstract107 , String abstract108 , String abstract109 , String abstract110 , String abstract111 , String abstract112 , String abstract113 , String abstract114 , String abstract115) {
        BookName = bookName;
        CoverImage = coverImage;
        BookAuthor = bookAuthor;
        Genres1 = genres1;
        Genres2 = genres2;
        Genres3 = genres3;
        Rating = rating;
        RatingInReverse = ratingInReverse;
        AppRating = appRating;
        AppUserNumber = appUserNumber;
        Comment101 = comment101;
        Comment102 = comment102;
        Comment103 = comment103;
        Comment104 = comment104;
        Comment105 = comment105;
        Comment106 = comment106;
        Comment107 = comment107;
        Comment108 = comment108;
        Comment109 = comment109;
        Comment110 = comment110;
        Comment111 = comment111;
        Comment112 = comment112;
        Comment113 = comment113;
        Comment114 = comment114;
        Comment115 = comment115;
        Comment201 = comment201;
        Comment202 = comment202;
        Comment203 = comment203;
        Comment204 = comment204;
        Comment205 = comment205;
        Comment206 = comment206;
        Comment207 = comment207;
        Comment208 = comment208;
        Comment209 = comment209;
        Comment210 = comment210;
        Comment211 = comment211;
        Comment212 = comment212;
        Comment213 = comment213;
        Comment214 = comment214;
        Comment215 = comment215;
        Comment301 = comment301;
        Comment302 = comment302;
        Comment303 = comment303;
        Comment304 = comment304;
        Comment305 = comment305;
        Comment306 = comment306;
        Comment307 = comment307;
        Comment308 = comment308;
        Comment309 = comment309;
        Comment310 = comment310;
        Comment311 = comment311;
        Comment312 = comment312;
        Comment313 = comment313;
        Comment314 = comment314;
        Comment315 = comment315;
        Abstract101 = abstract101;
        Abstract102 = abstract102;
        Abstract103 = abstract103;
        Abstract104 = abstract104;
        Abstract105 = abstract105;
        Abstract106 = abstract106;
        Abstract107 = abstract107;
        Abstract108 = abstract108;
        Abstract109 = abstract109;
        Abstract110 = abstract110;
        Abstract111 = abstract111;
        Abstract112 = abstract112;
        Abstract113 = abstract113;
        Abstract114 = abstract114;
        Abstract115 = abstract115;
    }
}
/*"BookName": "Sidelights on Relativity",
            "CoverImage": "https://images.gr-assets.com/books/1328868740l/1000548.jpg",
            "BookAuthor": "Albert Einstein",
            "Genres1": "Science",
            "Genres2": "Science",
            "Genres3": "Physics",
            "Rating": "4.12 / 5.0",
            "RatingInReverse": "0.88",
            "Abstract101": "In 1905, a German technical journal, Annalen der Physik, published a remarkable paper by a young clerk in the patent office at Berne, Switzerland. The clerk was Albert Einstein. The paper outlined his Special Theory of Relativity, a revolutionary physical theory which discarded the concept of absolute motion in favor of relative motion in the context of a four-dimensional continuum of space-time. It proved to be the most profound revolution in physics since Newton.About ten years later, buildin",
            "Abstract102": "g on his earlier work, Einstein formulated the General Theory of Relativity in which he offered a new solution to the great problem of gravitation, postulating the non-Euclidean character of the space-time continuum. Together, the two theories constituted a radically reoriented way of looking at the physical universe, an approach that solved many of the unresolved difficulties of classical mechanics and paved the way for great advances in 20th-century physics. This concise volume contains two a",
            "Abstract103": "ddresses by Dr. Einstein outlining aspects of the theories. Ether and Relativity (1920), delivered at the University of Leyden, discusses the properties demanded of the ether of space by the theory of relativity. Geometry and Experience (1921), given at the Prussian Academy of Sciences, describes the limits within which the Euclidean or any other practical geometric system can be held to be approximately true in connection with the concept of a finite universe.Both lectures are reprinted here c",
            "Abstract104": "omplete and unabridged; both express elegant ideas in simple prose devoid of complicated equations or abstruse terminology; both offer scientists and laypeople unparalleled insight into the seminal thinking of the 20th century's greatest physicist.",
            "Abstract105": "",
            "Abstract106": "",
            "Abstract107": "",
            "Abstract108": "",
            "Abstract109": "",
            "Abstract110": "",
            "Abstract111": "",
            "Abstract112": "",
            "Abstract113": "",
            "Abstract114": "",
            "Abstract115": "",
            "Comment101": "This is really not a book as in edited monologue but a transcript of some sort based on two lectures Einstein gave.",
            "Comment102": "",
            "Comment103": "",
            "Comment104": "",
            "Comment105": "",
            "Comment106": "",
            "Comment107": "",
            "Comment108": "",
            "Comment109": "",
            "Comment110": "",
            "Comment111": "",
            "Comment112": "",
            "Comment113": "",
            "Comment114": "",
            "Comment115": "",
            "Comment201": "An exceptional historic document composed of two distinct addresses by Albert Einstein.Firstly, recounting the stumbling of Physical Science from Newton's theory to his own: the intrinsic relation of matter and energy; and how the influence of problems derived from Hertz's investigations in electro-dynamics made this possible, thanks to Lorentz through Maxwell's equations. Secondly, the fundamental question for the character of Mathematics as a valid description of reality -particularly in th",
            "Comment202": "e field of Geometry. Plus a beautiful explanation of what an infinite universe, that is, an unbounded sphere, means.Perhaps equally important, there remains the question of how physics experiments are tainted by wrong philosophical approaches -now, at a time in which Philosophy is unconsidered or relegated to the dark places of Theology.Accessible to anyone (as for the large part of Einstein's public work) this is a beautiful document and a personal recommendation for lunch time!",
            "Comment203": "",
            "Comment204": "",
            "Comment205": "",
            "Comment206": "",
            "Comment207": "",
            "Comment208": "",
            "Comment209": "",
            "Comment210": "",
            "Comment211": "",
            "Comment212": "",
            "Comment213": "",
            "Comment214": "",
            "Comment215": "",
            "Comment301": "If you want to know anything about the basics of relativity, Einstein's pretty much the only one to read. He brings an unusual and remarkable clarity to his own work without grandstanding.This short bit combines two lectures from the early 1920s answering some of the inherent queries on his recent work. The first deals with the idea of the 'ether' which his work both discredited and, as he shows, retained in its essence. The second shows, remarkably, that you CAN envision a finite unbounded u",
            "Comment302": "niverse. The analogy he uses also hints at the holographic outlook on the universe that popped up some decades later. There was little that Einstein didn't presage in one way or another. There's also in quick side comment that indicates he was not so put off by quantum theory as is sometimes suggested.",
            "Comment303": "",
            "Comment304": "",
            "Comment305": "",
            "Comment306": "",
            "Comment307": "",
            "Comment308": "",
            "Comment309": "",
            "Comment310": "",
            "Comment311": "",
            "Comment312": "",
            "Comment313": "",
            "Comment314": "",
            "Comment315": ""*/