package com.example.arkarcy.rawx;

import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Window;
import android.view.WindowManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class SharedWithMe extends AppCompatActivity {
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;
    private ArrayList<modelSavedStoryGroup> list = new ArrayList<>();
    private ArrayList<modelSharedStory> listGroup = new ArrayList<>();
    private int f1 = 0;
    //private TextView mbSolo ,mbGroup;
    private int flag = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shared_with_me);

        getSupportActionBar().setTitle("Shared with me!");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }


        /*mbSolo = findViewById(R.id.solo);
        mbGroup = findViewById(R.id.group);*/

        recyclerView = (RecyclerView) findViewById(R.id.myContribution);

        layoutManager = new LinearLayoutManager(this);

        recyclerView.setLayoutManager(layoutManager);

        /*mbGroup.setTextColor(getResources().getColor(R.color.grey));
        mbSolo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=1;
                mbGroup.setTextColor(getResources().getColor(R.color.grey));
                mbSolo.setTextColor(getResources().getColor(R.color.white));
                get();
            }
        });
        mbGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=2;
                mbSolo.setTextColor(getResources().getColor(R.color.grey));
                mbGroup.setTextColor(getResources().getColor(R.color.white));
                get();
            }
        });*/
        //get();

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        get();
        Log.e("Asizemycontribution","resumed");
    }

    void get(){
        f1 = 1;
        list.clear();
        listGroup.clear();
        final String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replaceAll("[^a-zA-Z0-9]", "");
        mRef.child("Story").child("StoryUser").child(email).child("SharedWithMe").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // Log.e("Datasnap",dataSnapshot.getKey());
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Log.e("Found Type :",data.getValue().toString());
                    if(data.getValue().toString().equals("True")){
                        mRef.child("Story").child("StoryGroupPending").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelSharedStory mObj  = dataSnapshot.getValue(modelSharedStory.class);
                                //Log.e("Book Name ",mObj.getTitle());
                                listGroup.add(mObj);

                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                    /*else
                    {
                        mRef.child("Story").child("StoryUser").child(email).child("SavedStories").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelSavedStoryGroup mObj  = dataSnapshot.getValue(modelSavedStoryGroup.class);
                                //Log.e("Book Name ",mObj.getTitle());
                                list.add(mObj);

                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }*/
                }

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
    void display(){
        //===========================================//
        Log.e("Display called","");
        if(flag==2)
        {
            adapter = new storyHolderShared(getApplicationContext(),listGroup);
            recyclerView.setAdapter(adapter);
            f1=0;
        }
        else {
            /*adapter = new storyHolderSavedGroup(getApplicationContext(),list);
            recyclerView.setAdapter(adapter);*/
            /*list.clear();
            listGroup.clear();*/
        }


    }
}
