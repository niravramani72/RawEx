package com.example.arkarcy.rawx;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class story_solo extends AppCompatActivity {

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser;
    private DatabaseReference mUserDatabase;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    EditText e1,e2,e3;
    TextView t1;
    Button b1,b2;
    int SID1,SID2;
    String res="";
    String finalEmail;
    int flag = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_solo);
        //Toast.makeText(this, mod.getTitle(), Toast.LENGTH_SHORT).show();
        //mStory.setText(mod.getContent());

        Intent i1 = getIntent();
        res = i1.getStringExtra("act");

        //Toast.makeText(this, res.toString(), Toast.LENGTH_SHORT).show();

        getSupportActionBar().setTitle("Story Solo");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        e1 = findViewById(R.id.title);
        e2 = findViewById(R.id.story);
        e3 = findViewById(R.id.userName);
        b1 = findViewById(R.id.submit);
        b2 = findViewById(R.id.save);
        t1 = findViewById(R.id.id);

        if (res.equals("A")){

            Intent intent = getIntent();
            final modelSavedStorySolo mod = (modelSavedStorySolo) intent.getSerializableExtra("pass");
            try{
                if (!mod.getSID().equals("") || !mod.getTitle().equals("") || !mod.getContent().equals("") || !mod.getName().equals("")) {
                    t1.setText(mod.getSID());
                    e1.setText(mod.getTitle());
                    e2.setText(mod.getContent());
                    e3.setText(mod.getName());
                }}
            catch (Exception e){}

            String email = mAuth.getEmail();
            email = email.replaceAll("[^a-zA-Z0-9]", "");
            email = email.toLowerCase();
            //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
            finalEmail = email;

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String textisemptyornot1 = e1.getText().toString();
                    String textisemptyornot2 = e3.getText().toString();
                    textisemptyornot1 = textisemptyornot1.replaceAll(" ","");
                    textisemptyornot2 = textisemptyornot2.replaceAll(" ","");
                    //Toast.makeText(story_solo.this,e2.getText().toString().length() , Toast.LENGTH_SHORT).show();
                    if(textisemptyornot1.matches("") && textisemptyornot2.matches(""))
                        Toast.makeText(story_solo.this, "Please enter all field!!!", Toast.LENGTH_SHORT).show();
                    else if (e2.getText().toString().length()<=50)
                        Toast.makeText(story_solo.this, "Not enough length of story", Toast.LENGTH_SHORT).show();
                    else {
                        if (mod.getSID().equals(""))
                            ref.child("StoryListingSolo").child(t1.getText().toString()).child("SID").setValue(t1.getText().toString());
                        else
                            ref.child("StoryListingSolo").child(t1.getText().toString()).child("SID").setValue(t1.getText().toString());
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("UID").setValue(mAuth.getEmail());
                        //ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("PartNo").setValue("1");
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("Title").setValue(e1.getText().toString().trim());
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("Content").setValue(e2.getText().toString().trim());
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("Name").setValue(e3.getText().toString().trim());
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("Type").setValue("Solo");
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("ViewCount").setValue(0);
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("Like").setValue(0);

                        //ref.child("StoryUser").child(finalEmail).child(String.valueOf(SID1));
                        ref.child("StoryUser").child(finalEmail).child("UID").setValue(String.valueOf(finalEmail));
                        ref.child("StoryUser").child(finalEmail).child("Story").child(t1.getText().toString()).child("SID").setValue(t1.getText().toString());
                        ref.child("StoryUser").child(finalEmail).child("Story").child(t1.getText().toString()).child("Type").setValue("Solo");

                        Date c = Calendar.getInstance().getTime();
                        String DateTime = String.valueOf(c);
                        System.out.println("Current time => " + DateTime);
                        ref.child("StoryListingSolo").child(t1.getText().toString()).child("DateTime").setValue(DateTime);

                        try {
                            ref.child("StoryGroupPending").child(mod.getSID()).removeValue();
                            ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).removeValue();
                        } catch (Exception e) {
                            Log.d("Exe", String.valueOf(e));
                            Log.d("Exe Caught", "Found");
                        }
                        Toast.makeText(story_solo.this , "Published Successfully" , Toast.LENGTH_SHORT).show();
                        //  startActivity(new Intent(getApplicationContext(),story_saved.class));
                        finish();
                    }
                    //startActivity(new Intent(getApplicationContext(),story_group.class));
                /*ref.child("StoryUser").child(finalEmail).child(String.valueOf(SID1)).child("Title").setValue(e1.getText().toString().trim());
                ref.child("StoryUser").child(finalEmail).child(String.valueOf(SID1)).child("Story").setValue(e2.getText().toString().trim());*/
                    //ref.child(mAuth.getUid()).child(String.valueOf(SID1)).child("Email").setValue(mAuth.getEmail());
                }
            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    //ref.child("StoryGroupPending").child(mod.getSID()).child("Content5").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content").setValue(e2.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Type").setValue("Solo");
                    //startActivity(new Intent(getApplicationContext(),story_saved.class));
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child("UID").setValue(String.valueOf(finalEmail));
                    ref.child("StoryUser").child(finalEmail).child("Pending").child(t1.getText().toString()).child("SID").setValue(t1.getText().toString());
                    ref.child("StoryUser").child(finalEmail).child("Pending").child(t1.getText().toString()).child("Type").setValue("Solo");
                    // startActivity(new Intent(getApplicationContext(),story_saved.class));
                    Toast.makeText(story_solo.this , "Saved Successfully" , Toast.LENGTH_SHORT).show();
                    finish();
                }
            });
        }

        else if  (res.equals("B")){
            String email = mAuth.getEmail();
            email = email.replaceAll("[^a-zA-Z0-9]", "");
            email = email.toLowerCase();
            //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
            finalEmail = email;
            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String textisemptyornot1 = e1.getText().toString();
                    String textisemptyornot2 = e3.getText().toString();
                    textisemptyornot1 = textisemptyornot1.replaceAll(" ","");
                    textisemptyornot2 = textisemptyornot2.replaceAll(" ","");
                    if (textisemptyornot1.matches("") || textisemptyornot2.matches(""))
                        Toast.makeText(story_solo.this, "Please enter all field!!!", Toast.LENGTH_SHORT).show();
                    else if (e2.getText().toString().length()<=50)
                        Toast.makeText(story_solo.this, "Not enough length of story", Toast.LENGTH_SHORT).show();
                    else{
                        flag = 1;
                        ref.child("StoryListingSolo").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                                for (DataSnapshot dataSnapshot : dataSnapshot1.getChildren()) {
                                    ref.child("StoryListingSolo").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                            modelStory mObj = dataSnapshot.getValue(modelStory.class);
                                            Log.e("story solo", mObj.getContent());
                                            double ans = contentMatch(e2.getText().toString().trim().toLowerCase(), mObj.getContent().toLowerCase());
                                            if (ans < 70 && flag != 2) {
                                                flag = 1;
                                            } else {
                                                flag = 2;
                                            }
                                            Log.e("done5", "done");
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });
                                    Log.e("done2", "done");
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        ref.child("StoryListingSolo").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                                for (DataSnapshot dataSnapshot : dataSnapshot1.getChildren()) {
                                    ref.child("StoryListingSolo").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            get();

                                            Log.e("done6", "done");
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });
                                    Log.e("done1", "done");
                                }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        Toast.makeText(story_solo.this , "Published Successfully" , Toast.LENGTH_SHORT).show();
                    }
                }

                private double contentMatch(String main, String string1) {
                    Log.e("String main : ",main);
                    Log.e("String string1 : ",string1);
                    Set<String> mainWords = new HashSet<>();
                    for (String s : main.split("\\W")) {
                        if (s.length() > 1) {
                            mainWords.add(s);
                        }
                    }
                    //String string1 = "Cars came into global use during the 20th century, and developed economies depend on them. The year 1886 is regarded as the birth year of the modern car when German inventor Karl Benz patented his Benz Patent-Motorwagen. Cars became widely available in the early 20th century. One of the first cars accessible to the masses was the 1908 Model T, an American car manufactured by the Ford Motor Company. Cars were rapidly adopted in the US, where they replaced animal-drawn carriages and carts,   but took much longer to be accepted in Western Europe and other parts of the world.";

                    Set<String> mainWordsToFind = new HashSet<>(mainWords);
// Iterate over all the words and remove the word from the list to find
                    for (String word : string1.split("\\W")) {
                        if (word.length() > 1) {
                            mainWordsToFind.remove(word);
                        }
                    }

// Print the percent of word found
                    double ans = ((double)(mainWords.size() - mainWordsToFind.size()) / mainWords.size())*100;
                    Log.e("String ans is : ",String.valueOf(ans));
                    /*System.out.println("ans is : "+ans);
                    System.out.format("%.3f",ans);*/

                    return ans;
                }

            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
                    ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Name").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Content").setValue(e2.getText().toString().trim());
                    ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Type").setValue("Solo");
                    ref.child("StoryUser").child(finalEmail).child("Pending").child(String.valueOf(SID1)).child("SID").setValue(t1.getText().toString());
                    ref.child("StoryUser").child(finalEmail).child("Pending").child(String.valueOf(SID1)).child("Type").setValue("Solo");
                    Toast.makeText(story_solo.this , "Saved Successfully" , Toast.LENGTH_SHORT).show();
                    finish();
                }
            });

            mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
            String current_uid = mCurrentUser.getUid();
            mUserDatabase = FirebaseDatabase.getInstance().getReference().child("Story");
            //mUserDatabase.keepSynced(true);

            mUserDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    SID1 = Integer.parseInt(dataSnapshot.child("GlobalStoryID").getValue().toString());
                    t1.setText(String.valueOf(SID1));
                    SID2 = SID1 + 1;
                    mUserDatabase.child("GlobalStoryID").setValue(SID2);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }



    }
    public void get(){
        Log.e("flag ni value bahar",String.valueOf(flag));
        if (flag==1){
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("Content").setValue(e2.getText().toString().trim());
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("UID").setValue(mAuth.getEmail());
            //ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("PartNo").setValue("1");
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("Title").setValue(e1.getText().toString().trim());

            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("Name").setValue(e3.getText().toString().trim());
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("Type").setValue("Solo");
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("ViewCount").setValue(0);
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("Like").setValue(0);

            //ref.child("StoryUser").child(finalEmail).child(String.valueOf(SID1));
            ref.child("StoryUser").child(finalEmail).child("UID").setValue(String.valueOf(finalEmail));
            ref.child("StoryUser").child(finalEmail).child("Story").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
            ref.child("StoryUser").child(finalEmail).child("Story").child(String.valueOf(SID1)).child("Type").setValue("Solo");

            Date c = Calendar.getInstance().getTime();
            String DateTime = String.valueOf(c);
            System.out.println("Current time => " + DateTime);
            ref.child("StoryListingSolo").child(String.valueOf(SID1)).child("DateTime").setValue(DateTime);

            startActivity(new Intent(getApplicationContext(), story.class));
            finish();
        }
        else if (flag == 2){
            Toast.makeText(story_solo.this, "Content has already been published!", Toast.LENGTH_SHORT).show();
            // flag=1;
        }
    }
}