package com.example.arkarcy.rawx;

import com.google.firebase.database.Exclude;

public class modelAmazonBook {
    public String  BookName,CoverImage,BookAuthor,key;

    public modelAmazonBook() {
    }

    public modelAmazonBook(String bookName , String coverImage , String bookAuthor , String key) {
        BookName = bookName;
        CoverImage = coverImage;
        BookAuthor = bookAuthor;
        this.key = key;
    }
    @Exclude
    public String getKey() {
        return key;
    }
    @Exclude
    public void setKey(String key) {
        this.key = key;
    }
    @Exclude
    public String getBookName() {
        return BookName;
    }
    @Exclude
    public void setBookName(String bookName) {
        BookName = bookName;
    }
    @Exclude
    public String getCoverImage() {
        return CoverImage;
    }
    @Exclude
    public void setCoverImage(String coverImage) {
        CoverImage = coverImage;
    }
    @Exclude
    public String getBookAuthor() {
        return BookAuthor;
    }
    @Exclude
    public void setBookAuthor(String bookAuthor) {
        BookAuthor = bookAuthor;
    }
}
