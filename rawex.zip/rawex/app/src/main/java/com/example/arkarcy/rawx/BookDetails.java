package com.example.arkarcy.rawx;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.ms.square.android.expandabletextview.ExpandableTextView;
import com.squareup.picasso.Picasso;

import me.biubiubiu.justifytext.library.JustifyTextView;

public class BookDetails extends AppCompatActivity {

    //ExpandableTextView expTv1,expTv2,expTv3;
    //JustifyTextView ;
    private ImageView mDCoverImage;
    private Button mDbtnLike;
    private TextView mDbookName,mDbookAuthor,mDGenres,mDbookRating,mDbookAbstract,mDBookReview1,mDBookReview2,mDBookReview3,AppRatingTextView;
    private String mBookName;
    private Button mbtnFind,allreviews,submit;
    private EditText addreview;
    private int f =0;
    private String longi1 ="21.2274165" , latti1 = "72.8252499";
    private String longi2 ="21.2274165" , latti2 = "72.8252499";
    private String longi3 ="21.2274165" , latti3 = "72.8252499";
    private String longi4 ="21.2274165" , latti4 = "72.8252499";
    private String longi5 ="21.2274165" , latti5 = "72.8252499";
    private String longi6 ="21.2274165" , latti6 = "72.8252499";
    private String longi7 ="21.2274165" , latti7 = "72.8252499";
    private static final int MY_PERMISSION_ACCESS_COARSE_LOCATION = 11;
    private DatabaseReference mRef = FirebaseDatabase.getInstance().getReference();
    private RatingBar ratingBar;
    private String BookKey,AppReview1,AppReview2,AppReview3,AppReviewEmail1,AppReviewEmail2,AppReviewEmail3;
    private float prevRating,NumberOfUser,prevDatabaseRating = -0.1f;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details);


        mDbtnLike = findViewById(R.id.DbtnLike);
        mDCoverImage = findViewById(R.id.DCoverImage);
        mDbookName = findViewById(R.id.DbookName);
        mDbookAuthor = findViewById(R.id.DbookAuthor);
        mDGenres = findViewById(R.id.DGenres);
        mDbookRating  = findViewById(R.id.DbookRating);
        mDbookAbstract = findViewById(R.id.DbookAbstract);
        mbtnFind = findViewById(R.id.btnFindDetails);
        AppRatingTextView = findViewById(R.id.appRating);
        ratingBar = findViewById(R.id.ratingBar);
        allreviews = findViewById(R.id.allReviews);
        addreview =  findViewById(R.id.addReview);
        submit = findViewById(R.id.submit);
       /* mDBookReview1 = findViewById(R.id.DBookReview1);
        mDBookReview2 = findViewById(R.id.DBookReview2);
        mDBookReview3 = findViewById(R.id.DBookReview3);*/
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();
        final String BookNuName = bd.getString("BookName");
        final String BookName =bd.getString("BookName").replaceAll("[^a-zA-Z0-9]", "");

        mDbookName.setText(bd.getString("BookName"));
        mDbookAuthor.setText(bd.getString("BookAuthor"));
        mDGenres.setText(bd.getString("Genres"));
        mDbookRating.setText(bd.getString("BookRating"));

        mBookName = bd.getString("BookName");
        mbtnFind.setEnabled(false);

        String AppRating = bd.getString("AppRating");
        final String AppUserNumber = bd.getString("AppUserNumber");

        AppRatingTextView.setText(bd.getString("AppRating"));




       /* ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar , float v , boolean b) {
                rating = v;
                Toast.makeText(BookDetails.this , "rating : "+String.valueOf(v) , Toast.LENGTH_SHORT).show();
            }
        });*/
        mRef.child("Books").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    if (data.child("BookName").getValue().equals(BookNuName)){
                        BookKey = data.getKey();
                        Log.e("BookKey1",BookKey);
                        prevRating = Float.parseFloat(data.child("AppRating").getValue().toString());
                        NumberOfUser = Float.parseFloat(data.child("AppUserNumber").getValue().toString());
                        AppReview1 = data.child("AppReview1").getValue().toString();
                        AppReview2 = data.child("AppReview2").getValue().toString();
                        AppReview3 = data.child("AppReview3").getValue().toString();
                        AppReviewEmail1 = data.child("AppReviewEmail1").getValue().toString();
                        AppReviewEmail2 = data.child("AppReviewEmail2").getValue().toString();
                        AppReviewEmail3 = data.child("AppReviewEmail3").getValue().toString();

                        Log.e("AppReviewEmail11",AppReviewEmail1);
                        Log.e("AppReviewEmail12",AppReviewEmail2);
                        Log.e("AppReviewEmail13",AppReviewEmail3);

                        try{
                            FirebaseAuth auth = FirebaseAuth.getInstance();
                            FirebaseUser firebaseUser = auth.getCurrentUser();
                            String currentUser = firebaseUser.getUid();
                            Log.e("current user",currentUser);

                            mRef.child("Users").child(currentUser).child("BookRating").addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    //Log.e("getBookRating",dataSnapshot.getChildren().toString());
                                    for (DataSnapshot data : dataSnapshot.getChildren()){
                                        if(data.getKey() ==  BookKey){
                                             Log.e("BookKey2",data.getValue().toString());
                                            prevDatabaseRating = Float.parseFloat(data.getValue().toString());
                                            ratingBar.setRating(Float.parseFloat(data.getValue().toString()));
                                        }
                                       // Log.e("BookKey2",BookKey);
                                    }
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }
                        catch (Exception e){

                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        //Toast.makeText(this , "AppRating"+AppRating , Toast.LENGTH_SHORT).show();
        //Toast.makeText(this , "AppUserNumber"+AppUserNumber , Toast.LENGTH_SHORT).show();

        String Comment101 = bd.getString("review101");
        String Comment102 = bd.getString("review102");
        String Comment103 = bd.getString("review103");
        String Comment104 = bd.getString("review104");
        String Comment105 = bd.getString("review105");
        String Comment106 = bd.getString("review106");
        String Comment107 = bd.getString("review107");
        String Comment108 = bd.getString("review108");
        String Comment109 = bd.getString("review109");
        String Comment110 = bd.getString("review110");
        String Comment111 = bd.getString("review111");
        String Comment112 = bd.getString("review112");
        String Comment113 = bd.getString("review113");
        String Comment114 = bd.getString("review114");
        String Comment115 = bd.getString("review115");
        String Comment201 = bd.getString("review201");
        String Comment202 = bd.getString("review202");
        String Comment203 = bd.getString("review203");
        String Comment204 = bd.getString("review204");
        String Comment205 = bd.getString("review205");
        String Comment206 = bd.getString("review206");
        String Comment207 = bd.getString("review207");
        String Comment208 = bd.getString("review208");
        String Comment209 = bd.getString("review209");
        String Comment210 = bd.getString("review210");
        String Comment211 = bd.getString("review211");
        String Comment212 = bd.getString("review212");
        String Comment213 = bd.getString("review213");
        String Comment214 = bd.getString("review214");
        String Comment215 = bd.getString("review215");
        String Comment301 = bd.getString("review301");
        String Comment302 = bd.getString("review302");
        String Comment303 = bd.getString("review303");
        String Comment304 = bd.getString("review304");
        String Comment305 = bd.getString("review305");
        String Comment306 = bd.getString("review306");
        String Comment307 = bd.getString("review307");
        String Comment308 = bd.getString("review308");
        String Comment309 = bd.getString("review309");
        String Comment310 = bd.getString("review310");
        String Comment311 = bd.getString("review311");
        String Comment312 = bd.getString("review312");
        String Comment313 = bd.getString("review313");
        String Comment314 = bd.getString("review314");
        String Comment315 = bd.getString("review315");


        String Abstract101 = bd.getString("Abstract101");
        String Abstract102 = bd.getString("Abstract102");
        String Abstract103 = bd.getString("Abstract103");
        String Abstract104 = bd.getString("Abstract104");
        String Abstract105 = bd.getString("Abstract105");
        String Abstract106 = bd.getString("Abstract106");
        String Abstract107 = bd.getString("Abstract107");
        String Abstract108 = bd.getString("Abstract108");
        String Abstract109 = bd.getString("Abstract109");
        String Abstract110 = bd.getString("Abstract110");
        String Abstract111 = bd.getString("Abstract111");
        String Abstract112 = bd.getString("Abstract112");
        String Abstract113 = bd.getString("Abstract113");
        String Abstract114 = bd.getString("Abstract114");
        String Abstract115 = bd.getString("Abstract115");
        String Abstract = Abstract101 + Abstract102 + Abstract103 + Abstract104 + Abstract105 + Abstract106 + Abstract107 + Abstract108 + Abstract109 + Abstract110 + Abstract111 + Abstract112 + Abstract113 + Abstract114 + Abstract115;
        //Log.e("R1 :",bd.getString("review1"));
 /*       String l1 =bd.getString("review101");
        String l2 =bd.getString("review2");
        String l3 =bd.getString("review3");*/

        final String c1 = Comment101 + Comment102 + Comment103 + Comment104 + Comment105 + Comment106 + Comment107 + Comment108 + Comment109 + Comment110 + Comment111 + Comment112 + Comment113 + Comment114 + Comment115;
        final String c2 = Comment201 + Comment202 + Comment203 + Comment204 + Comment205 + Comment206 + Comment207 + Comment208 + Comment209 + Comment210 + Comment211 + Comment212 + Comment213 + Comment214 + Comment215;
        final String c3 = Comment301 + Comment302 + Comment303 + Comment304 + Comment305 + Comment306 + Comment307 + Comment308 + Comment309 + Comment310 + Comment311 + Comment312 + Comment313 + Comment314 + Comment315;

        mDbookAbstract.setText("\t\t\t\t" + Abstract);
        /*expTv1 = findViewById(R.id.DBookReview1);
        expTv2 = findViewById(R.id.DBookReview2);
        expTv3 = findViewById(R.id.DBookReview3);
        expTv1.setText(c1);
        expTv2.setText(c2);
        expTv3.setText(c3);*/

        allreviews.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),AllReviews.class);
                i.putExtra("c1",c1);
                i.putExtra("c2",c2);
                i.putExtra("c3",c3);
                i.putExtra("AppReview1",AppReview1);
                i.putExtra("AppReview2",AppReview2);
                i.putExtra("AppReview3",AppReview3);
                i.putExtra("AppReviewEmail1",AppReviewEmail1);
                i.putExtra("AppReviewEmail2",AppReviewEmail2);
                i.putExtra("AppReviewEmail3",AppReviewEmail3);
                startActivity(i);
            }
        });


        if(bd.getString("BookImage")!="")
            try {
                Picasso.get().load(bd.getString("BookImage")).into(mDCoverImage);
            }
            catch (Exception e){

            }

   /*     Bundle extras = new Bundle();
        extras.putString("BookName",model.getBookName());
        extras.putString("BookAuthor",model.getBookAuthor());
        extras.putString("BookImage",model.getCoverImage());
        extras.putString("Genres",model.getGenres1());
        extras.putString("BookRating",model.getRating());
        extras.putString("Abstract",model.getAbstract());*/

        mRef.child("Library").child("Library5").child("Library5").child("LBooks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(BookName)){
                    Log.e("Found At Library 5",BookName);

                    mRef.child("Library").child("Library5").child("Library5").child("Location").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.e("Library 5 Location :", (String) dataSnapshot.getValue());
                            String sp[] = ((String)dataSnapshot.getValue()).split(",");
                            longi5 = sp[0];
                            latti5 = sp[1];

                            mbtnFind.setText("Find Near ME");
                            mbtnFind.setEnabled(true);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mRef.child("Library").child("Library6").child("Library6").child("LBooks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(BookName)){
                    Log.e("Found At Library 6",BookName);

                    mRef.child("Library").child("Library6").child("Library6").child("Location").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.e("Library 6 Location :", (String) dataSnapshot.getValue());
                            String sp[] = ((String)dataSnapshot.getValue()).split(",");
                            longi6 = sp[0];
                            latti6 = sp[1];

                            mbtnFind.setText("Find Near ME");
                            mbtnFind.setEnabled(true);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mRef.child("Library").child("Library7").child("Library7").child("LBooks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(BookName)){
                    Log.e("Found At Library 7",BookName);

                    mRef.child("Library").child("Library7").child("Library7").child("Location").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.e("Library 7 Location :", (String) dataSnapshot.getValue());
                            String sp[] = ((String)dataSnapshot.getValue()).split(",");
                            longi5 = sp[0];
                            latti5 = sp[1];

                            mbtnFind.setText("Find Near ME");
                            mbtnFind.setEnabled(true);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mbtnFind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle extra = new Bundle();
                extra.putString("Longi1",longi1);
                extra.putString("Latti1",latti1);
                extra.putString("Longi2",longi2);
                extra.putString("Latti2",latti2);
                extra.putString("Longi3",longi3);
                extra.putString("Latti3",latti3);
                extra.putString("Longi4",longi4);
                extra.putString("Latti4",latti4);

                extra.putString("Longi5",longi5);
                extra.putString("Latti5",latti5);
                extra.putString("Longi6",longi6);
                extra.putString("Latti6",latti6);
                extra.putString("Longi7",longi7);
                extra.putString("Latti7",latti7);


                Intent map = new Intent(getApplicationContext() , MapsActivity.class);
                map.putExtras(extra);
                if (ActivityCompat.checkSelfPermission(getApplicationContext() , android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(BookDetails.this , android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    ActivityCompat.requestPermissions(BookDetails.this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSION_ACCESS_COARSE_LOCATION);

                    //return;
                }else{

                }
                if (ActivityCompat.checkSelfPermission(getApplicationContext() , android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(BookDetails.this , android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                }
                else{
                    startActivity(map);
                }
            }
        });
        try{
        mRef.child("RecommendationUserMatch").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(BookName).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.getValue() != null)
                if(dataSnapshot.getValue().equals(BookName)){

                    mDbtnLike.setBackgroundResource(R.drawable.thumb_filled);
                    f=1;
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        }catch(Exception e){

        }

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseUser firebaseUser = auth.getCurrentUser();
                final String currentUser = firebaseUser.getEmail();

                if (AppReview1.equals("")){
                    mRef.child("Books").child(BookKey).child("AppReview1").setValue(addreview.getText().toString().trim());
                    mRef.child("Books").child(BookKey).child("AppReviewEmail1").setValue(currentUser);
                }
                else if (AppReview2.equals("")){
                    mRef.child("Books").child(BookKey).child("AppReview2").setValue(AppReview1);
                    mRef.child("Books").child(BookKey).child("AppReview1").setValue(addreview.getText().toString().trim());
                    mRef.child("Books").child(BookKey).child("AppReviewEmail2").setValue((String)AppReviewEmail1);
                    mRef.child("Books").child(BookKey).child("AppReviewEmail1").setValue(currentUser);
                    Log.e("AppReviewEmail1--->",AppReviewEmail1);
                }
                else {
                    mRef.child("Books").child(BookKey).child("AppReview3").setValue(AppReview2);
                    mRef.child("Books").child(BookKey).child("AppReview2").setValue(AppReview1);
                    mRef.child("Books").child(BookKey).child("AppReview1").setValue(addreview.getText().toString().trim());
                    mRef.child("Books").child(BookKey).child("AppReviewEmail3").setValue(AppReviewEmail2);
                    mRef.child("Books").child(BookKey).child("AppReviewEmail2").setValue(AppReviewEmail1);
                    mRef.child("Books").child(BookKey).child("AppReviewEmail1").setValue(currentUser);
                    Log.e("AppReviewEmail1******>",AppReviewEmail1);
                    Log.e("AppReviewEmail2******>",AppReviewEmail2);
                }

              /*  mRef.child("Books").child(BookKey).child("AppReviewEmail2").setValue(AppReviewEmail2);
                mRef.child("Books").child(BookKey).child("AppReviewEmail3").setValue(AppReviewEmail3);*/
                addreview.setText("");
                Toast.makeText(BookDetails.this, "Review submitted successfully!", Toast.LENGTH_LONG).show();
            }
        });


        final RatingBar mBar = (RatingBar) findViewById(R.id.ratingBar);
        mBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar , float v , boolean b) {
                Double rating = 0.0;
                if (prevDatabaseRating==-0.1f){
                    rating = Double.valueOf((((prevRating * NumberOfUser) + v) / (NumberOfUser + 1)));
                    rating = Math.round(rating * 100.0) / 100.0;
                    NumberOfUser++;
                    Log.e("NIrav1","1");
                    Log.e("prevDatabaseRating",String.valueOf(prevDatabaseRating));
                }
                else{
                    rating = Double.valueOf((((prevRating * NumberOfUser) - prevDatabaseRating)+ v) / NumberOfUser);
                    rating = Math.round(rating * 100.0) / 100.0;
                    Log.e("NIrav1","2");
                    Log.e("prevDatabaseRating",String.valueOf(prevDatabaseRating));
                }


                Log.e("prevRating",String.valueOf(prevRating));
                Log.e("NumberOfUser",String.valueOf(NumberOfUser));
                Log.e("v",String.valueOf(v));
                //Toast.makeText(BookDetails.this , String.valueOf(rating) , Toast.LENGTH_SHORT).show();
                mRef.child("Books").child(BookKey).child("AppRating").setValue(String.valueOf(rating));
                mRef.child("Books").child(BookKey).child("AppUserNumber").setValue(String.valueOf(NumberOfUser));
                AppRatingTextView.setText(String.valueOf(rating));

                FirebaseAuth auth = FirebaseAuth.getInstance();
                FirebaseUser firebaseUser = auth.getCurrentUser();
                String currentUser = firebaseUser.getUid();
                Log.e("current user",currentUser);

                mRef.child("Users").child(currentUser).child("BookRating").child(BookKey).setValue(String.valueOf(v));
                //mRef.child("Users").child()

               /* mRef.child("Books").child(BookKey).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            if (dataSnapshot.child("BookName").getValue().equals(BookNuName)) {
                                //data.child("AppRating").set
                                mRef.child("Books").child(BookKey).child("AppRating").setValue(String.valueOf(rating));
                                Toast.makeText(BookDetails.this , "rating : " + String.valueOf(rating) , Toast.LENGTH_SHORT).show();
                            }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });*/
            }
        });

        mDbtnLike.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (f == 0){
                    mDbtnLike.setBackgroundResource(R.drawable.thumb_filled);
                    f = 1;
                    mRef.child("RecommendationUserMatch").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(BookName).setValue(BookName);
                }
                else {
                    mDbtnLike.setBackgroundResource(R.drawable.thumb_empty);
                    f = 0;
                    mRef.child("RecommendationUserMatch").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child(BookName).removeValue();
                }
                //if(mDbtnLike.getBackground() == R.drawable.thumb_filled)
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.singlebook , menu);
        // MenuItem item = menu.findItem(R.id.action_search);

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.action_share){
            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            String shareBody = "\""+mBookName+"\" \nThis Book is Shared By RawEx\nIf you haven't installed yet installed it now....";
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "RawEx");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(sharingIntent, "Share via"));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
