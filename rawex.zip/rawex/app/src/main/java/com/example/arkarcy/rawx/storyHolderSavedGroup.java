package com.example.arkarcy.rawx;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class storyHolderSavedGroup extends RecyclerView.Adapter<storyHolderSavedGroup.MyViewHolder> {

    private Context mContext;
    private List<modelSavedStoryGroup> mDataList;


    public storyHolderSavedGroup(Context mContext, ArrayList<modelSavedStoryGroup> mDataList) {
        this.mContext = mContext;
        this.mDataList = mDataList;
    }

    @NonNull
    @Override
    public storyHolderSavedGroup.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.model,viewGroup,false);
        return new storyHolderSavedGroup.MyViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull storyHolderSavedGroup.MyViewHolder myViewHolder, int i) {
        final modelSavedStoryGroup mod = mDataList.get(i);
        myViewHolder.title1.setText(mod.getTitle());
        myViewHolder.story1.setText(mod.getContent1());
        myViewHolder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.e("Story",mod.getContent1());
                Intent intent = new Intent(mContext,story_group.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                intent.putExtra("act","A");
                intent.putExtra("pass", (Serializable) mod);
                mContext.startActivity(intent);

            }
        });
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{


        TextView title1,story1;
        View mView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            title1 = itemView.findViewById(R.id.title);
            story1 = itemView.findViewById(R.id.story);
        }
    }
}