package com.example.arkarcy.rawx;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

public class BookDetails_OnlyBooks extends AppCompatActivity {

    private ImageView mDCoverImage;
    private TextView mDbookName,mDbookAuthor,mDGenres,mDbookAbstract,mDbookRating,mDBookReview1,mDBookReview2,mDBookReview3;
    private String mBookName;
    private Button mbfind;
    private static final int MY_PERMISSION_ACCESS_COARSE_LOCATION = 11;
    private DatabaseReference mRef = FirebaseDatabase.getInstance().getReference();
    private String longi1 ="21.2274165" , latti1 = "72.8252499";
    private String longi2 ="21.2274165" , latti2 = "72.8252499";
    private String longi3 ="21.2274165" , latti3 = "72.8252499";
    private String longi4 ="21.2274165" , latti4 = "72.8252499";

    private String longi5 ="21.2274165" , latti5 = "72.8252499";
    private String longi6 ="21.2274165" , latti6 = "72.8252499";
    private String longi7 ="21.2274165" , latti7 = "72.8252499";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_details__only_books);
        mDCoverImage = findViewById(R.id.DCoverImage);
        mDbookName = findViewById(R.id.DbookName);
        mDbookAuthor = findViewById(R.id.DbookAuthor);
        mDGenres = findViewById(R.id.DGenres);
        mDbookRating  = findViewById(R.id.DbookRating);
        mDbookAbstract = findViewById(R.id.DbookAbstract);
        mbfind = findViewById(R.id.btnFind);

       /* mDBookReview1 = findViewById(R.id.DBookReview1);
        mDBookReview2 = findViewById(R.id.DBookReview2);
        mDBookReview3 = findViewById(R.id.DBookReview3);*/
        Intent intent = getIntent();
        Bundle bd = intent.getExtras();

        mDbookName.setText(bd.getString("BookName"));
        mDbookAuthor.setText(bd.getString("BookAuthor"));
        mDGenres.setText(bd.getString("Genres"));
        mDbookRating.setText(bd.getString("BookRating"));
        mbfind.setText("Wait It is Finding...");
        mbfind.setEnabled(false);


        //database
        final String BookName =bd.getString("BookName").replaceAll("[^a-zA-Z0-9]", "");


        mRef.child("Library").child("Library4").child("LBooks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(BookName)){
                    Log.e("Found At Library 4",BookName);

                            mRef.child("Library").child("Library4").child("Location").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.e("Library 4 Location :", (String) dataSnapshot.getValue());

                            String sp[] = ((String)dataSnapshot.getValue()).split(",");
                            longi4 = sp[0];
                            latti4 = sp[1];

                            mbfind.setText("Find Near ME");
                            mbfind.setEnabled(true);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mRef.child("Library").child("Library3").child("LBooks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(BookName)){
                    Log.e("Found At Library 3",BookName);
                    mRef.child("Library").child("Library3").child("Location").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.e("Library 3 Location :", (String) dataSnapshot.getValue());
                            String sp[] = ((String)dataSnapshot.getValue()).split(",");
                            longi3 = sp[0];
                            latti3 = sp[1];

                            mbfind.setText("Find Near ME");
                            mbfind.setEnabled(true);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mRef.child("Library").child("Library2").child("LBooks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(BookName)){
                    Log.e("Found At Library 2",BookName);
                    mRef.child("Library").child("Library2").child("Location").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.e("Library 2 Location :", (String) dataSnapshot.getValue());
                            String sp[] = ((String)dataSnapshot.getValue()).split(",");
                            longi2 = sp[0];
                            latti2 = sp[1];

                            mbfind.setText("Find Near ME");
                            mbfind.setEnabled(true);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mRef.child("Library").child("Library1").child("LBooks").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(BookName)){
                    Log.e("Found At Library 1",BookName);
                    mRef.child("Library").child("Library1").child("Location").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            Log.e("Library 1 Location :", (String) dataSnapshot.getValue());
                            String sp[] = ((String)dataSnapshot.getValue()).split(",");
                            longi1 = sp[0];
                            latti1 = sp[1];

                            mbfind.setText("Find Near ME");
                            mbfind.setEnabled(true);
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mBookName = bd.getString("BookName");
        mbfind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // "21.2274165,72.8252499"
                Bundle extra = new Bundle();

                extra.putString("Longi1",longi1);
                extra.putString("Latti1",latti1);
                extra.putString("Longi2",longi2);
                extra.putString("Latti2",latti2);
                extra.putString("Longi3",longi3);
                extra.putString("Latti3",latti3);
                extra.putString("Longi4",longi4);
                extra.putString("Latti4",latti4);


                extra.putString("Longi5",longi5);
                extra.putString("Latti5",latti5);
                extra.putString("Longi6",longi6);
                extra.putString("Latti6",latti6);
                extra.putString("Longi7",longi7);
                extra.putString("Latti7",latti7);

                Intent map = new Intent(getApplicationContext() , MapsActivity.class);
                map.putExtras(extra);
                if (ActivityCompat.checkSelfPermission(getApplicationContext() , android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(BookDetails_OnlyBooks.this , android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    ActivityCompat.requestPermissions(BookDetails_OnlyBooks.this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSION_ACCESS_COARSE_LOCATION);

                    //return;
                }else{

                }
                if (ActivityCompat.checkSelfPermission(getApplicationContext() , android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(BookDetails_OnlyBooks.this , android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                }
                else{
                    startActivity(map);
                }

            }
        });
        if(bd.getString("BookImage")!="")
            try {
                Picasso.get().load(bd.getString("BookImage")).into(mDCoverImage);
            }
            catch (Exception e){

            }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.singlebook , menu);
        // MenuItem item = menu.findItem(R.id.action_search);

        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement

        if(id == R.id.action_share){
            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            String shareBody = "\""+mBookName+"\" \nThis Book is Shared By RawEx\nIf you haven't installed yet installed it now....";
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "RawEx");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(sharingIntent, "Share via"));
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
