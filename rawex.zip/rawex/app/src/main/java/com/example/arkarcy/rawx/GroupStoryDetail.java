package com.example.arkarcy.rawx;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class GroupStoryDetail extends AppCompatActivity {

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser;
    private DatabaseReference mUserDatabase;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    private TextView mStory,mTitle,mName1,mName2,mName3,mName4,mName5,mMember1,mMember2,mMember3,mMember4,mMember5,mUID,mViewCount,mLikeCount,DateTime;
    private Button deleteThisStory;
    private ImageButton fav,like;
    private String SID;
    private String email,email1;
    String res="",mem="";
    private int flag = 0,like123=0;
    private int f = 0,l=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_group_story_detail);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }
        mStory = findViewById(R.id.stText);
        mTitle = findViewById(R.id.stTitle);
        mName1 = findViewById(R.id.name1);
        mName2 = findViewById(R.id.name2);
        mName3 = findViewById(R.id.name3);
        mName4 = findViewById(R.id.name4);
        mName5 = findViewById(R.id.name5);
        mMember1 = findViewById(R.id.member1);
        mMember2 = findViewById(R.id.member2);
        mMember3 = findViewById(R.id.member3);
        mMember4 = findViewById(R.id.member4);
        mMember5 = findViewById(R.id.member5);
        DateTime = findViewById(R.id.datetime);
        mUID = findViewById(R.id.stUID);
        deleteThisStory = findViewById(R.id.deleteThisStory);
        fav = findViewById(R.id.fav);
        mViewCount = findViewById(R.id.viewCount);
        mLikeCount = findViewById(R.id.likeCount);
        like = findViewById(R.id.like);

        Intent intent = getIntent();
        final modelStoryGroup mod = (modelStoryGroup) intent.getSerializableExtra("pass");
        String story = mod.getContent1() + " " + mod.getContent2() + " " + mod.getContent3() + " " + mod.getContent4() + " " + mod.getContent5();
        mTitle.setText(mod.getTitle());
        mStory.setText(story.toString());
        mName1.setText(mod.getName1());
        mName2.setText(mod.getName2());
        mName3.setText(mod.getName3());
        mName4.setText(mod.getName4());
        mName5.setText(mod.getName5());
        mMember1.setText(mod.getMember1());
        mMember2.setText(mod.getMember2());
        mMember3.setText(mod.getMember3());
        mMember4.setText(mod.getMember4());
        mMember5.setText(mod.getMember5());
        DateTime.setText(mod.getDateTime());

        mMember1.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setText(mod.getUID());
                Toast.makeText(GroupStoryDetail.this, "Copied!", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        mMember2.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setText(mod.getUID());
                Toast.makeText(GroupStoryDetail.this, "Copied!", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        mMember3.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setText(mod.getUID());
                Toast.makeText(GroupStoryDetail.this, "Copied!", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        mMember4.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setText(mod.getUID());
                Toast.makeText(GroupStoryDetail.this, "Copied!", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        mMember5.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setText(mod.getUID());
                Toast.makeText(GroupStoryDetail.this, "Copied!", Toast.LENGTH_SHORT).show();
                return false;
            }
        });
        SID = mod.getSID();
        mLikeCount.setText(String.valueOf(mod.getLike()));
        mViewCount.setText(String.valueOf(mod.getViewCount()));

        if (mName2.getText().equals("")){
            mName2.setVisibility(View.GONE);
        }
        if (mName3.getText().equals("")){
            mName3.setVisibility(View.GONE);
        }
        if (mName4.getText().equals("")){
            mName4.setVisibility(View.GONE);
        }
        if (mName5.getText().equals("")){
            mName5.setVisibility(View.GONE);
        }
        if (mMember2.getText().equals("")){
            mMember2.setVisibility(View.GONE);
        }
        if (mMember3.getText().equals("")){
            mMember3.setVisibility(View.GONE);
        }
        if (mMember4.getText().equals("")){
            mMember4.setVisibility(View.GONE);
        }
        if (mMember5.getText().equals("")){
            mMember5.setVisibility(View.GONE);
        }


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        String email = mAuth.getEmail();
        email = email.replaceAll("[^a-zA-Z0-9]", "");
        email = email.toLowerCase();
        //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
        final String finalEmail = email;

        String email1 = mAuth.getEmail();
        if (email1.equals(mod.getUID())){
            deleteThisStory.setVisibility(View.VISIBLE);
        }
        else{
            deleteThisStory.setVisibility(View.GONE);
            fav.setVisibility(View.VISIBLE);

            ref.child("StoryListingGroup").child(mod.getSID()).child("ViewCount").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    int count = Integer.parseInt(dataSnapshot.getValue().toString());
                    count += 1;
                    ref.child("StoryListingGroup").child(mod.getSID()).child("ViewCount").setValue(count);
                    Log.e("view",String.valueOf(count));
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });

        }
        deleteThisStory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    ref.child("StoryUser").child(finalEmail).child("Story").child(String.valueOf(SID)).removeValue();
                    ref.child("StoryListingGroup").child(String.valueOf(SID)).removeValue();
                }
                catch (Exception e) {
                    Log.d("Exe",String.valueOf(e));
                    Log.d("Exe Caught","Found");
                }

                finish();
            }
        });


        try{
            ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot data : dataSnapshot.getChildren()){
                        Log.e("qwer",data.getValue().toString());
                        Log.e("SoloStory_fav---->","YES");
                        //flag = 2;
                        like.setImageResource(R.drawable.thumb_filled);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            Log.e("qazxsw","notcrash");
        }
        catch (Exception e){
            Log.e("SoloStory_fav---->","NO");
            like123 = 1;
            Log.e("qazxsw",e.toString());
        }


        try{
            ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    for (DataSnapshot data : dataSnapshot.getChildren()){
                        Log.e("qwer",data.getValue().toString());
                        Log.e("SoloStory_fav---->","YES");
                        //flag = 2;
                        fav.setImageResource(R.drawable.ic_favorite_black_24dp);
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
            Log.e("qazxsw","notcrash");
        }
        catch (Exception e){
            Log.e("SoloStory_fav---->","NO");
            flag = 1;
            Log.e("qazxsw",e.toString());
        }


        like.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //Toast.makeText(SoloStoryDetail.this, "jarvis", Toast.LENGTH_SHORT).show();
                if (l == 0){
                    like.setImageResource(R.drawable.thumb_filled);
                    l = 1;
                    ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).child("Type").setValue("Group");

                    ref.child("StoryListingGroup").child(mod.getSID()).child("Like").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            int count = Integer.parseInt(dataSnapshot.getValue().toString());
                            count += 1;
                            ref.child("StoryListingGroup").child(mod.getSID()).child("Like").setValue(count);
                            Log.e("like",String.valueOf(count));
                            mLikeCount.setText(String.valueOf(count));
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });

                }
                else {
                    like.setImageResource(R.drawable.thumb_empty);
                    l = 0;
                    ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).removeValue();

                    ref.child("StoryListingGroup").child(mod.getSID()).child("Like").addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                            int count = Integer.parseInt(dataSnapshot.getValue().toString());
                            count -= 1;
                            ref.child("StoryListingGroup").child(mod.getSID()).child("Like").setValue(count);
                            Log.e("like123",String.valueOf(count));
                            mLikeCount.setText(String.valueOf(count));
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError databaseError) {

                        }
                    });
                }
            }
        });


        fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (f == 0){
                    fav.setImageResource(R.drawable.ic_favorite_black_24dp);
                    f = 1;
                    ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).child("Type").setValue("Group");
                }
                else {
                    fav.setImageResource(R.drawable.ic_favorite_border_black_24dp);
                    f = 0;
                    ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).removeValue();
                }
            }
        });





////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //Toast.makeText(this, mod.getTitle()+"\n"+mod.getUID(), Toast.LENGTH_SHORT).show();
    }
}
