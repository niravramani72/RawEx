package com.example.arkarcy.rawx;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import com.ms.square.android.expandabletextview.ExpandableTextView;

public class AllReviews extends AppCompatActivity {

    Button goodreads,app;
    LinearLayout ll1,ll2;
    ExpandableTextView expTv1,expTv2,expTv3,expTv4,expTv5,expTv6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_reviews);

        Intent intent = getIntent();
        final String c1 = intent.getStringExtra("c1");
        final String c2 = intent.getStringExtra("c2");
        final String c3 = intent.getStringExtra("c3");
        final String AppReview1 = intent.getStringExtra("AppReview1");
        final String AppReview2 = intent.getStringExtra("AppReview2");
        final String AppReview3 = intent.getStringExtra("AppReview3");
        final String AppReviewEmail1 = intent.getStringExtra("AppReviewEmail1");
        final String AppReviewEmail2 = intent.getStringExtra("AppReviewEmail2");
        final String AppReviewEmail3 = intent.getStringExtra("AppReviewEmail3");


        //Log.e("review",c1 + "\n" + c2 + "\n" + c3);

        goodreads = findViewById(R.id.goodreadsreview);
        app = findViewById(R.id.inappreview);
        ll1 = findViewById(R.id.llgoodreads);
        ll2 = findViewById(R.id.llappreview);

        ll2.setVisibility(View.GONE);

        expTv1 = findViewById(R.id.DBookReview1);
        expTv2 = findViewById(R.id.DBookReview2);
        expTv3 = findViewById(R.id.DBookReview3);
        expTv1.setText(c1);
        expTv2.setText(c2);
        expTv3.setText(c3);

        goodreads.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                app.setTextColor(getResources().getColor(R.color.grey));
                goodreads.setTextColor(getResources().getColor(R.color.white));
                ll2.setVisibility(View.GONE);
                ll1.setVisibility(View.VISIBLE);

                expTv1 = findViewById(R.id.DBookReview1);
                expTv2 = findViewById(R.id.DBookReview2);
                expTv3 = findViewById(R.id.DBookReview3);
                expTv1.setText(c1);
                expTv2.setText(c2);
                expTv3.setText(c3);

            }
        });

        app.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                goodreads.setTextColor(getResources().getColor(R.color.grey));
                app.setTextColor(getResources().getColor(R.color.white));
                ll1.setVisibility(View.GONE);
                ll2.setVisibility(View.VISIBLE);

                expTv4 = findViewById(R.id.DBookReview4);
                expTv5 = findViewById(R.id.DBookReview5);
                expTv6 = findViewById(R.id.DBookReview6);
                expTv4.setText(AppReview1 + "\n\n\n--" + AppReviewEmail1);
                expTv5.setText(AppReview2 + "\n\n\n--" + AppReviewEmail2);
                expTv6.setText(AppReview3 + "\n\n\n--" + AppReviewEmail3);
            }
        });
    }
}
