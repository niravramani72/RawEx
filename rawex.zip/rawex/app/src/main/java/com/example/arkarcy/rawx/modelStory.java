package com.example.arkarcy.rawx;

import java.io.Serializable;

public class modelStory implements Serializable {
    private static final long serialVersionUID = 1L;
    private String SID;
    private String Title;
    private String Content;
    private String Name;
    private String PartNo;
    private String Type;
    private String UID;

    public String getDateTime() {
        return DateTime;
    }

    public void setDateTime(String dateTime) {
        DateTime = dateTime;
    }

    public modelStory(String dateTime) {

        DateTime = dateTime;
    }

    private String DateTime;
    private int Like,ViewCount;

    public modelStory() {
    }

    public modelStory(String SID, String title, String content, String name, String partNo, String type, String UID, int like, int viewCount) {
        this.SID = SID;
        Title = title;
        Content = content;
        Name = name;
        PartNo = partNo;
        Type = type;
        this.UID = UID;
        Like = like;
        ViewCount = viewCount;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getSID() {
        return SID;
    }

    public void setSID(String SID) {
        this.SID = SID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getPartNo() {
        return PartNo;
    }

    public void setPartNo(String partNo) {
        PartNo = partNo;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public int getLike() {
        return Like;
    }

    public void setLike(int like) {
        Like = like;
    }

    public int getViewCount() {
        return ViewCount;
    }

    public void setViewCount(int viewCount) {
        ViewCount = viewCount;
    }
}
