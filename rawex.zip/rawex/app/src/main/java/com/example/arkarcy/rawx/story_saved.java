package com.example.arkarcy.rawx;

import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class story_saved extends AppCompatActivity {

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser,mCurrentUser1;
    private DatabaseReference mUserDatabase,mUserDatabase1;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;
    private ArrayList<modelSavedStorySolo> list = new ArrayList<modelSavedStorySolo>();
    private ArrayList<modelSavedStoryGroup> listGroup = new ArrayList<modelSavedStoryGroup>();
    private ArrayList<modelSharedStory> listShared = new ArrayList<modelSharedStory>();
    private ArrayList<modelStoryGroup> timestamp = new ArrayList<modelStoryGroup>();

    private TextView mbSolo ,mbGroup ,mbShared;
    private int flag = 0;
    private int f1 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_saved);

        getSupportActionBar().setTitle("Pending Stories");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        mbSolo = findViewById(R.id.solo);
        mbGroup = findViewById(R.id.group);
        mbShared = findViewById(R.id.shared);

        recyclerView = (RecyclerView) findViewById(R.id.myContribution);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        mbGroup.setTextColor(getResources().getColor(R.color.grey));
        mbShared.setTextColor(getResources().getColor(R.color.grey));

        flag=1;

        mbSolo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=1;
                mbGroup.setTextColor(getResources().getColor(R.color.grey));
                mbSolo.setTextColor(getResources().getColor(R.color.white));
                mbShared.setTextColor(getResources().getColor(R.color.grey));
                if(f1==0)
                get();
            }
        });
        mbGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=2;
                mbSolo.setTextColor(getResources().getColor(R.color.grey));
                mbGroup.setTextColor(getResources().getColor(R.color.white));
                mbShared.setTextColor(getResources().getColor(R.color.grey));
                if(f1==0)
                get();
            }
        });
        mbShared.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=3;
                mbSolo.setTextColor(getResources().getColor(R.color.grey));
                mbShared.setTextColor(getResources().getColor(R.color.white));
                mbGroup.setTextColor(getResources().getColor(R.color.grey));
                if(f1==0)
                get1();
            }
        });
        //get();
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        get(); // Solo + Group
        get1(); // SharedWithMe
        Log.e("StorySaved_saved","resumed");
    }

    void get(){
        f1=1;
        list.clear();
        listGroup.clear();
        final String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replaceAll("[^a-zA-Z0-9]", "");
        mRef.child("Story").child("StoryUser").child(email).child("Pending").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Log.e("Datasnap",dataSnapshot.getKey());
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Log.e("Found Type :",data.getValue().toString());
                    if(data.getValue().toString().equals("Group")){
                        mRef.child("Story").child("StoryGroupPending").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                final modelSavedStoryGroup mObj  = dataSnapshot.getValue(modelSavedStoryGroup.class);



////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                try {
                                    String getEmail2 = mObj.getMember2();
                                    getEmail2 = getEmail2.replaceAll("[^a-zA-Z0-9]", "");
                                    String getEmail3 = mObj.getMember3();
                                    getEmail3 = getEmail3.replaceAll("[^a-zA-Z0-9]", "");
                                    String getEmail4 = mObj.getMember4();
                                    getEmail4 = getEmail4.replaceAll("[^a-zA-Z0-9]", "");
                                    String getEmail5 = mObj.getMember5();
                                    getEmail5 = getEmail5.replaceAll("[^a-zA-Z0-9]", "");
                                    Date date = new Date();
                                    final Timestamp timestamp1 = new Timestamp(date.getTime());
                                    Calendar cal = Calendar.getInstance();
                                    cal.setTimeInMillis(timestamp1.getTime());
                                    Log.e("email", getEmail2);

                                    final String finalGetEmail = getEmail2;
                                    ref.child("StoryUser").child(getEmail2).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            //Log.e("timestamp", dataSnapshot.getValue().toString());
                                            String tmp = (String)dataSnapshot.getValue();
                                            if(tmp == null){
                                                ref.child("StoryUser").child(finalGetEmail).child("SharedWithMe").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        try {
                                                            getTime(dataSnapshot, timestamp1, finalGetEmail, mObj);
                                                        }
                                                        catch (Exception e){}
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                            else{
                                                Log.e("timestamp", dataSnapshot.getValue().toString());
                                                ref.child("StoryUser").child(finalGetEmail).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        try {
                                                            getTime(dataSnapshot, timestamp1, finalGetEmail, mObj);
                                                        }
                                                        catch (Exception e){}
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });

                                    final String finalGetEmail1 = getEmail3;
                                    ref.child("StoryUser").child(getEmail3).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            //getTime();
                                            //Log.e("timestamp", dataSnapshot.getValue().toString());
                                            String tmp = (String)dataSnapshot.getValue();
                                            if(tmp == null){
                                                ref.child("StoryUser").child(finalGetEmail1).child("SharedWithMe").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        //Log.e("timestamp in string", dataSnapshot.getValue().toString());
                                                        String temp = (String)dataSnapshot.getValue();
                                                        if (temp != null)
                                                            try {
                                                                getTime(dataSnapshot, timestamp1, finalGetEmail1, mObj);
                                                            }
                                                            catch (Exception e){}

                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                            else{
                                                Log.e("timestamp", dataSnapshot.getValue().toString());
                                                ref.child("StoryUser").child(finalGetEmail1).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        try {
                                                            getTime(dataSnapshot, timestamp1, finalGetEmail1, mObj);
                                                        }
                                                        catch (Exception e){}

                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });

                                    final String finalGetEmail2 = getEmail4;
                                    ref.child("StoryUser").child(getEmail4).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            //getTime();
                                            //Log.e("timestamp", dataSnapshot.getValue().toString());
                                            String tmp = (String)dataSnapshot.getValue();
                                            if(tmp == null){
                                                ref.child("StoryUser").child(finalGetEmail2).child("SharedWithMe").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        //Log.e("timestamp in string", dataSnapshot.getValue().toString());
                                                        String temp = (String)dataSnapshot.getValue();
                                                        if (temp != null)
                                                            getTime(dataSnapshot,timestamp1,finalGetEmail2,mObj);
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                            else{
                                                Log.e("timestamp", dataSnapshot.getValue().toString());
                                                ref.child("StoryUser").child(finalGetEmail2).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        getTime(dataSnapshot,timestamp1,finalGetEmail2,mObj);
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });

                                    final String finalGetEmail3 = getEmail5;
                                    ref.child("StoryUser").child(getEmail5).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            //getTime();
                                            //Log.e("timestamp", dataSnapshot.getValue().toString());
                                            String tmp = (String)dataSnapshot.getValue();
                                            if(tmp == null){
                                                ref.child("StoryUser").child(finalGetEmail3).child("SharedWithMe").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        //Log.e("timestamp in string", dataSnapshot.getValue().toString());
                                                        String temp = (String)dataSnapshot.getValue();
                                                        if (temp != null)
                                                            getTime(dataSnapshot,timestamp1,finalGetEmail3,mObj);

                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                            else{
                                                Log.e("timestamp", dataSnapshot.getValue().toString());
                                                ref.child("StoryUser").child(finalGetEmail3).child("SharedWithMeSave").child(mObj.getSID()).child("TimeStamp").addValueEventListener(new ValueEventListener() {
                                                    @Override
                                                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                        getTime(dataSnapshot,timestamp1,finalGetEmail3,mObj);
                                                    }

                                                    @Override
                                                    public void onCancelled(@NonNull DatabaseError databaseError) {

                                                    }
                                                });
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {

                                        }
                                    });
                                }
                                catch (Exception e){

                                }





///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


                                try{
                                    if(mObj.getTitle()!= null){
                                        listGroup.add(mObj);
                                    }

                                }catch (Exception e){

                                }
                              //  listGroup.add(mObj);

                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                    else if(data.getValue().toString().equals("Solo"))
                    {
                        mRef.child("Story").child("StoryGroupPending").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelSavedStorySolo mObj  = dataSnapshot.getValue(modelSavedStorySolo.class);
                                //Log.e("Book Name ",mObj.getTitle());
                                try{
                                    if(mObj.getTitle()!= null){
                                        list.add(mObj);

                                    }

                                }catch (Exception e){

                                }
                              //  list.add(mObj);
                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }

            }

            private void getTime(DataSnapshot dataSnapshot , Timestamp timestamp1 , String email , modelSavedStoryGroup mObj) {
                Log.e("timestamp in string", dataSnapshot.getValue().toString());
                String temp = dataSnapshot.getValue().toString();
                try {
                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
                    Date parsedDate = dateFormat.parse(temp);
                    Timestamp timestamp2 = new Timestamp(parsedDate.getTime());
                    Log.e("timestamp in TimeStamp", timestamp2.toString());

                    long milliseconds = timestamp2.getTime() - timestamp1.getTime();
                    int seconds = (int) milliseconds / 1000;

                    // calculate hours minutes and seconds
                    int hours = seconds / 3600;
                    int minutes = (seconds % 3600) / 60;
                    seconds = (seconds % 3600) % 60;

                    Log.e("timestamphours", String.valueOf(hours));
                    Log.e("timestampmin",String.valueOf(minutes));
                    Log.e("timestampsec",String.valueOf(seconds));

                    if (hours<=0 && minutes<=0 && seconds<=0) {
                        autoSubmit(email,mObj);
                    }
                    else{
                        Log.e("timestamp","else ma avyu");
                    }

                } catch(Exception e) { //this generic but you can control another types of exception
                    // look the origin of excption
                }
            }

            private void autoSubmit(String email, modelSavedStoryGroup mod) {

                ref.child("StoryUser").child(email).child("Story").child(mod.getSID()).child("SID").setValue(mod.getSID());
                ref.child("StoryUser").child(email).child("Story").child(mod.getSID()).child("Type").setValue("Group");

                ref.child("StoryUser").child(email).child("SharedWithMeSave").child(mod.getSID()).removeValue();

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    void get1(){
        f1=1;
        listShared.clear();
        final String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replaceAll("[^a-zA-Z0-9]", "");
        mRef.child("Story").child("StoryUser").child(email).child("SharedWithMeSave").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // Log.e("Datasnap",dataSnapshot.getKey());
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Log.e("Found Type :",data.getValue().toString());
                    if(data.getValue().toString().equals("True")){
                        mRef.child("Story").child("StoryGroupPending").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelSharedStory mObj  = dataSnapshot.getValue(modelSharedStory.class);
                                //Log.e("Book Name ",mObj.getTitle());
                                listShared.add(mObj);

                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    void display(){
        //===========================================//
        Log.e("Display called","");
        if(flag==2)
        {
            adapter = new storyHolderSavedGroup(getApplicationContext(),listGroup);
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }
        else {
            adapter = new storyHolderSavedSolo(getApplicationContext(),list);
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }
        if(flag==3)
        {
            adapter = new StoryHolderSharedSave(getApplicationContext(),listShared);
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }


    }

}
