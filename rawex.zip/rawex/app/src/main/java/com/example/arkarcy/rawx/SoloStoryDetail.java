package com.example.arkarcy.rawx;

import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class SoloStoryDetail extends AppCompatActivity {

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser;
    private DatabaseReference mUserDatabase;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    private TextView mStory,mTitle,mName,mUID,mViewCount,mLikeCount,DateTime;
    private Button deleteThisStory;
    private ImageButton fav,like;
    private String SID;
    private String email,email1;
    String res="",mem="";
    private int flag = 0,like123=0;
    private int f = 0,l=0;
    private LinearLayout count;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_solo_story_detail);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        mStory = findViewById(R.id.stText);
        mTitle = findViewById(R.id.stTitle);
        mName = findViewById(R.id.stName);
        mUID = findViewById(R.id.stUID);
        deleteThisStory = findViewById(R.id.deleteThisStory);
        fav = findViewById(R.id.fav);
        mViewCount = findViewById(R.id.viewCount);
        mLikeCount = findViewById(R.id.likeCount);
        like = findViewById(R.id.like);
        count = findViewById(R.id.count);
        DateTime = findViewById(R.id.datetime);
        Intent i1 = getIntent();
        res = i1.getStringExtra("act");
        mem = i1.getStringExtra("member");

        email1 = mAuth.getEmail();
        email = mAuth.getEmail();
        email = email.replaceAll("[^a-zA-Z0-9]", "");
        email = email.toLowerCase();

        flag=1;
        like123=1;
        final String finalEmail1 = email;

        if (res.equals("A")){
            Intent intent = getIntent();
            modelSharedStory mod = (modelSharedStory) intent.getSerializableExtra("pass");
            getSupportActionBar().setTitle("Shared Story");
//        Toast.makeText(this, mod.getTitle(), Toast.LENGTH_SHORT).show();
            mStory.setText(mod.getContent1() +" "+ mod.getContent2() +" "+ mod.getContent3() +" "+ mod.getContent4());
            mTitle.setText(mod.getTitle());
            DateTime.setText(mod.getDateTime());
            /*mName.setText(mod.getName1());
            mUID.setText(mod.getUID());*/
            mName.setVisibility(View.GONE);
            mUID.setVisibility(View.GONE);
            count.setVisibility(View.GONE);
            like.setVisibility(View.GONE);
            SID = mod.getSID();

            String email = mAuth.getEmail();
            email = email.replaceAll("[^a-zA-Z0-9]", "");
            email = email.toLowerCase();
            //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
            final String finalEmail = email;


            String email1 = mAuth.getEmail();
            if (email1.equals(mod.getUID())){
                deleteThisStory.setVisibility(View.GONE);
            }
            else{
                deleteThisStory.setVisibility(View.GONE);
            }
            deleteThisStory.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try{
                        ref.child("StoryUser").child(finalEmail).child("Story").child(String.valueOf(SID)).removeValue();
                        ref.child("StoryListingSolo").child(String.valueOf(SID)).removeValue();
                        Toast.makeText(SoloStoryDetail.this , "Deleted Successfully" , Toast.LENGTH_SHORT).show();
                    }
                    catch (Exception e) {
                        Log.d("Exe",String.valueOf(e));
                        Log.d("Exe Caught","Found");
                    }
                    startActivity(new Intent(getApplicationContext(),mycontribution.class));
                    finish();
                }
            });
        }

        if (res.equals("B")){

            Intent intent = getIntent();
            final modelStory mod = (modelStory) intent.getSerializableExtra("pass");
            getSupportActionBar().setTitle("Story ID : " + mod.getSID());
//        Toast.makeText(this, mod.getTitle(), Toast.LENGTH_SHORT).show();
            mStory.setText(mod.getContent());
            mTitle.setText(mod.getTitle());
            mName.setText(mod.getName());
            mUID.setText(mod.getUID());
            DateTime.setText(mod.getDateTime());
            mUID.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    ((ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE)).setText(mod.getUID());
                    Toast.makeText(SoloStoryDetail.this, "Copied!", Toast.LENGTH_SHORT).show();
                    return false;
                }
            });
            SID = mod.getSID();
            mLikeCount.setText(String.valueOf(mod.getLike()));
            mViewCount.setText(String.valueOf(mod.getViewCount()));

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////





/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            String email = mAuth.getEmail();
            email = email.replaceAll("[^a-zA-Z0-9]", "");
            email = email.toLowerCase();
            //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
            final String finalEmail = email;

            String email1 = mAuth.getEmail();
            if (email1.equals(mod.getUID())){
                deleteThisStory.setVisibility(View.VISIBLE);
            }
            else{
                deleteThisStory.setVisibility(View.GONE);
                fav.setVisibility(View.VISIBLE);

                ref.child("StoryListingSolo").child(mod.getSID()).child("ViewCount").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        int count = Integer.parseInt(dataSnapshot.getValue().toString());
                        count += 1;
                        ref.child("StoryListingSolo").child(mod.getSID()).child("ViewCount").setValue(count);
                        Log.e("view",String.valueOf(count));
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }
            deleteThisStory.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try{
                        ref.child("StoryUser").child(finalEmail).child("Story").child(String.valueOf(SID)).removeValue();
                        ref.child("StoryListingSolo").child(String.valueOf(SID)).removeValue();
                    }
                    catch (Exception e) {
                        Log.d("Exe",String.valueOf(e));
                        Log.d("Exe Caught","Found");
                    }

                    finish();
                }
            });


            try{
                ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot data : dataSnapshot.getChildren()){
                            Log.e("qwer",data.getValue().toString());
                            Log.e("SoloStory_fav---->","YES");
                            l = 1;
                            like.setImageResource(R.drawable.thumb_filled);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                Log.e("qazxsw","notcrash");
            }
            catch (Exception e){
                Log.e("SoloStory_fav---->","NO");
                like123 = 1;
                Log.e("qazxsw",e.toString());
            }


            try{
                ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        for (DataSnapshot data : dataSnapshot.getChildren()){
                            Log.e("qwer",data.getValue().toString());
                            Log.e("SoloStory_fav---->","YES");
                            f = 1;
                            fav.setImageResource(R.drawable.ic_favorite_black_24dp);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
                Log.e("qazxsw","notcrash");
            }
            catch (Exception e){
                Log.e("SoloStory_fav---->","NO");
                flag = 1;
                Log.e("qazxsw",e.toString());
            }


            like.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //Toast.makeText(SoloStoryDetail.this, "jarvis", Toast.LENGTH_SHORT).show();
                    if (l == 0){
                        like.setImageResource(R.drawable.thumb_filled);
                        l = 1;
                        ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).child("SID").setValue(mod.getSID());
                        ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).child("Type").setValue("Solo");

                        ref.child("StoryListingSolo").child(mod.getSID()).child("Like").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int count = Integer.parseInt(dataSnapshot.getValue().toString());
                                count += 1;
                                ref.child("StoryListingSolo").child(mod.getSID()).child("Like").setValue(count);
                                Log.e("like",String.valueOf(count));
                                mLikeCount.setText(String.valueOf(count));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });

                    }
                    else {
                        like.setImageResource(R.drawable.thumb_empty);
                        l = 0;
                        ref.child("StoryUser").child(finalEmail).child("Like").child(mod.getSID()).removeValue();

                        ref.child("StoryListingSolo").child(mod.getSID()).child("Like").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                int count = Integer.parseInt(dataSnapshot.getValue().toString());
                                count -= 1;
                                ref.child("StoryListingSolo").child(mod.getSID()).child("Like").setValue(count);
                                Log.e("like123",String.valueOf(count));
                                mLikeCount.setText(String.valueOf(count));
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }
            });


            fav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    if (f == 0){
                        fav.setImageResource(R.drawable.ic_favorite_black_24dp);
                        f = 1;
                        ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).child("SID").setValue(mod.getSID());
                        ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).child("Type").setValue("Solo");
                    }
                    else {
                        fav.setImageResource(R.drawable.ic_favorite_border_black_24dp);
                        f = 0;
                        ref.child("StoryUser").child(finalEmail).child("Favorite").child(mod.getSID()).removeValue();
                    }
                }
            });

        }

        if (res.equals("C")){
            Intent intent = getIntent();
            final modelSavedStoryGroup mod = (modelSavedStoryGroup) intent.getSerializableExtra("pass");
            getSupportActionBar().setTitle("Shared Story");
//        Toast.makeText(this, mod.getTitle(), Toast.LENGTH_SHORT).show();

            like.setVisibility(View.GONE);
            count.setVisibility(View.GONE);

            try{

                if (mem.equals("two")){
                    mStory.setText(mod.getContent2());
                    mTitle.setText(mod.getTitle());
                    mName.setText(mod.getName2());
                    mUID.setText(mod.getMember2());
                    SID = mod.getSID();

                    String email = mAuth.getEmail();
                    email = email.replaceAll("[^a-zA-Z0-9]", "");
                    email = email.toLowerCase();
                    final String finalEmail = email;
                    String email1 = mAuth.getEmail();
                    deleteThisStory.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            try{
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Content2").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member2").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Name2").setValue("");
                                String temp = mod.getMember2();
                                temp = temp.replaceAll("[^a-zA-Z0-9]", "");
                                temp = temp.toLowerCase();
                                ref.child("StoryUser").child(temp).child("Story").child(String.valueOf(SID)).removeValue();
                            }
                            catch (Exception e) {
                                Log.d("Exe",String.valueOf(e));
                                Log.d("Exe Caught","Found");
                            }

                            finish();
                        }
                    });
                }
                if (mem.equals("three")){
                    mStory.setText(mod.getContent3());
                    mTitle.setText(mod.getTitle());
                    mName.setText(mod.getName3());
                    mUID.setText(mod.getMember3());
                    SID = mod.getSID();

                    String email = mAuth.getEmail();
                    email = email.replaceAll("[^a-zA-Z0-9]", "");
                    email = email.toLowerCase();
                    final String finalEmail = email;
                    String email1 = mAuth.getEmail();
                    deleteThisStory.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            try{
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Content3").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member3").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Name3").setValue("");
                                String temp = mod.getMember3();
                                temp = temp.replaceAll("[^a-zA-Z0-9]", "");
                                temp = temp.toLowerCase();
                                ref.child("StoryUser").child(temp).child("Story").child(String.valueOf(SID)).removeValue();
                            }
                            catch (Exception e) {
                                Log.d("Exe",String.valueOf(e));
                                Log.d("Exe Caught","Found");
                            }

                            finish();
                        }
                    });
                }
                if (mem.equals("four")){
                    mStory.setText(mod.getContent4());
                    mTitle.setText(mod.getTitle());
                    mName.setText(mod.getName4());
                    mUID.setText(mod.getMember4());
                    SID = mod.getSID();

                    String email = mAuth.getEmail();
                    email = email.replaceAll("[^a-zA-Z0-9]", "");
                    email = email.toLowerCase();
                    final String finalEmail = email;
                    String email1 = mAuth.getEmail();
                    deleteThisStory.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            try{
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Content4").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member4").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Name4").setValue("");
                                String temp = mod.getMember4();
                                temp = temp.replaceAll("[^a-zA-Z0-9]", "");
                                temp = temp.toLowerCase();

                                ref.child("StoryUser").child(temp).child("Story").child(String.valueOf(SID)).removeValue();
                            }
                            catch (Exception e) {
                                Log.d("Exe",String.valueOf(e));
                                Log.d("Exe Caught","Found");
                            }

                            finish();
                        }
                    });
                }
                if (mem.equals("five")){
                    mStory.setText(mod.getContent5());
                    mTitle.setText(mod.getTitle());
                    mName.setText(mod.getName5());
                    mUID.setText(mod.getMember5());
                    SID = mod.getSID();

                    String email = mAuth.getEmail();
                    email = email.replaceAll("[^a-zA-Z0-9]", "");
                    email = email.toLowerCase();
                    final String finalEmail = email;
                    String email1 = mAuth.getEmail();
                    deleteThisStory.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            try{
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Content5").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member5").setValue("");
                                ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Name5").setValue("");
                                String temp = mod.getMember5();
                                temp = temp.replaceAll("[^a-zA-Z0-9]", "");
                                temp = temp.toLowerCase();
                                ref.child("StoryUser").child(temp).child("Story").child(String.valueOf(SID)).removeValue();
                                //ref.child("StoryUser").child(mod.getMember5()).child("Story").child(String.valueOf(SID)).removeValue();
                            }
                            catch (Exception e) {
                                Log.d("Exe",String.valueOf(e));
                                Log.d("Exe Caught","Found");
                            }
                            startActivity(new Intent(getApplicationContext(),mycontribution.class));
                            finish();
                        }
                    });
                }
            }
            catch(Exception e){}

        }
    }
}
