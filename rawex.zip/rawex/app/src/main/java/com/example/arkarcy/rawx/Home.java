package com.example.arkarcy.rawx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.RecoverySystem;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.android.gms.tasks.TaskCompletionSource;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.Semaphore;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Home.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Home#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Home extends Fragment {

    private RecyclerView mrec;
    private Query mQuery;
    private String genres;
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();
    private Button bgenres,mbgooglemap,mbAllBooks;
    private TextView mRecText;
    private static final int MY_PERMISSION_ACCESS_COARSE_LOCATION = 11;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    private String CurrentUserbook="";
    //private String[] OtherUserbook = new String[500];
    private ArrayList<String> OtherUserbook = new ArrayList<>();
    private ArrayList<Integer> match = new ArrayList<>();
    private int otherIndex=0;
    private String RecoomendationBook="";
    public Home() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Home.
     */
    // TODO: Rename and change types and number of parameters
    public static Home newInstance(String param1 , String param2) {
        Home fragment = new Home();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1 , param1);
        args.putString(ARG_PARAM2 , param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        final Semaphore semaphore = new Semaphore(1);


        mRef.child("RecommendationUserMatch").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
               // Log.e("current :",dataSnapshot.getKey());
                for (DataSnapshot data: dataSnapshot.getChildren()) {
                   // Log.e("current :",data.getKey());
                    CurrentUserbook = CurrentUserbook +";"+ data.getKey();


                }

                if(CurrentUserbook != null)
                {
                 //   Log.e("CurrentUserbook",CurrentUserbook);
                 //   Recommendation();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
/*
        final ArrayList<String> temppp = new ArrayList<>();
        mRef.child("RecommendationUserMatch").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot , @Nullable String s) {

             *//*   while(dataSnapshot.hasChildren()){
                    Log.e("Rec1 : ", (String) dataSnapshot.getKey());
                }*//*
                String temp ="";
                if(!temppp.contains(dataSnapshot.getKey()))
                if(!dataSnapshot.getKey().equals(FirebaseAuth.getInstance().getCurrentUser().getUid() )) {
                    for (DataSnapshot data : dataSnapshot.getChildren()) {
                        temppp.add(dataSnapshot.getKey());
                        temp = temp+";"+ data.getKey();
                    }
                    OtherUserbook.add(temp);
                   // Log.e("REx1 :" + otherIndex + " " , OtherUserbook.get(otherIndex));
                    Recommendation(otherIndex);
                    otherIndex++;

                }

              //  Log.e("Rec : ", String.valueOf(dataSnapshot.getChildrenCount()));
                semaphore.release();
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot , @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot , @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mRef.child("RecommendationUserMatch").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Log.e("Completed","Finding");
                int max = match.get(0);
                int maxIndex = 0;
                for(int i = 1; i < match.size(); i++ ){
                    if( match.get(i) > max ){
                        max = match.get(i);
                        maxIndex = i;
                    }
                }
                Log.e("maximum "+OtherUserbook.get(maxIndex), String.valueOf(match.get(maxIndex)));
                String[] otherb = OtherUserbook.get(maxIndex).split(";");
                for (int j=1;j<otherb.length;j++){
                    if(!CurrentUserbook.contains(otherb[j])){
                        Log.e("Recommend",otherb[j]);
                        RecoomendationBook = RecoomendationBook+otherb[j];
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/
        mRef = FirebaseDatabase.getInstance().getReference().child("Books");
        mRef.keepSynced(true);


        mQuery = mRef.orderByKey();
       // mQuery = mRef.orderByChild("RatingInReverse").limitToFirst(15);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
      //  Log.e("REx1 :" + otherIndex+ " ",OtherUserbook.get(0));
        //Recommendation();

        // To start program after childEvenListener complete
       /* int count = 0;
        ref.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                count++;


                if(count >= dataSnapshot.getChildrenCount()){
                    //stop progress bar here
                }
            }*/
    }

    void Recommendation(int index){
        int count=0;
        String[] otherb = OtherUserbook.get(index).split(";");
        String[] cb = CurrentUserbook.split(";");
        for (int i=1 ;i<otherb.length;i++){
            for (int j=1;j<cb.length;j++){
                if(otherb[i].matches(cb[j])){
                    count++;
                }
            }
        }
        match.add(count);
        for (int i = 1 ;i<cb.length;i++){
         //   Log.e("cb "+ OtherUserbook.get(index)+ " ", String.valueOf(match.get(index)));
        }
        //Log.e("REcommendation Function",CurrentUserbook );
        //Log.e();
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        final View mViewvv = inflater.inflate(R.layout.fragment_home , container , false);//fragment_home


        bgenres = mViewvv.findViewById(R.id.bgenrers);
        mbgooglemap = mViewvv.findViewById(R.id.bgooglemap);
        mbAllBooks = mViewvv.findViewById(R.id.AllBooks);
        mRecText = (TextView) mViewvv.findViewById(R.id.recText);
        mRecText.setVisibility(View.INVISIBLE);
        mbAllBooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getFragmentManager().beginTransaction().replace(R.id.frameofbooks , new AllBooks()).addToBackStack(null).commit();
            }
        });
        bgenres.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getFragmentManager().beginTransaction().replace(R.id.frameofbooks , new BookListFragment()).addToBackStack(null).commit();
            }
        });
        mbgooglemap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (ActivityCompat.checkSelfPermission(getActivity() , android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity() , android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                    // TODO: Consider calling
                    //    ActivityCompat#requestPermissions
                    // here to request the missing permissions, and then overriding
                    //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
                    //                                          int[] grantResults)
                    // to handle the case where the user grants the permission. See the documentation
                    // for ActivityCompat#requestPermissions for more details.
                    ActivityCompat.requestPermissions(getActivity(), new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSION_ACCESS_COARSE_LOCATION);

                    //return;
                }else{

                }
                if (ActivityCompat.checkSelfPermission(getActivity() , android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity() , android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                }
                else{
                    startActivity(new Intent(getActivity(),MapsActivity.class));
                }

               // getFragmentManager().beginTransaction().replace(R.id.frameofbooks , new Map_Fragment()).addToBackStack(null).commit();
            }
        });
        //added

        final ArrayList<String> temppp = new ArrayList<>();
        mDatabase.getReference().child("RecommendationUserMatch").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot , @Nullable String s) {

             /*   while(dataSnapshot.hasChildren()){
                    Log.e("Rec1 : ", (String) dataSnapshot.getKey());
                }*/
                String temp ="";
                if(!temppp.contains(dataSnapshot.getKey()))
                    if(!dataSnapshot.getKey().equals(FirebaseAuth.getInstance().getCurrentUser().getUid() )) {
                        for (DataSnapshot data : dataSnapshot.getChildren()) {
                            temppp.add(dataSnapshot.getKey());
                            temp = temp+";"+ data.getKey();
                        }
                        OtherUserbook.add(temp);
                        // Log.e("REx1 :" + otherIndex + " " , OtherUserbook.get(otherIndex));
                        Recommendation(otherIndex);
                        otherIndex++;

                    }

                //  Log.e("Rec : ", String.valueOf(dataSnapshot.getChildrenCount()));

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot , @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot , @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mDatabase.getReference().child("RecommendationUserMatch").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                Log.e("Completed","Finding");
                int max = match.get(0);
                int maxIndex = 0;
                for(int i = 1; i < match.size(); i++ ){
                    if( match.get(i) > max ){
                        max = match.get(i);
                        maxIndex = i;
                    }
                }
                Log.e("maximum "+OtherUserbook.get(maxIndex), String.valueOf(match.get(maxIndex)));
                String[] otherb = OtherUserbook.get(maxIndex).split(";");
                for (int j=1;j<otherb.length;j++){
                    if(!CurrentUserbook.contains(otherb[j])){
                        Log.e("Recommend",otherb[j]);
                        RecoomendationBook = RecoomendationBook+otherb[j];
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        //added
        mrec= (RecyclerView)mViewvv.findViewById(R.id.topratedrec);
        final LinearLayoutManager Linearmanage  = new LinearLayoutManager(getContext(),LinearLayoutManager.HORIZONTAL,false);

        final boolean[] loading = {true};
        final int[] pastVisiblesItems = new int[1];
        final int[] visibleItemCount = new int[1];
        final int[] totalItemCount = new int[1];

        mrec.addOnScrollListener(new RecyclerView.OnScrollListener()
        {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy)
            {
                if(dy > 0) //check for scroll down
                {
                    visibleItemCount[0] = Linearmanage.getChildCount();
                    totalItemCount[0] = Linearmanage.getItemCount();
                    pastVisiblesItems[0] = Linearmanage.findFirstVisibleItemPosition();

                    if (loading[0])
                    {
                        if ( (visibleItemCount[0] + pastVisiblesItems[0]) >= totalItemCount[0])
                        {
                            loading[0] = false;
                            Log.v("...", "Last Item Wow !");
                            //Do pagination.. i.e. fetch new data
                        }
                    }
                }
            }
        });
        mRef = FirebaseDatabase.getInstance().getReference().child("Books");


        class BlogViewHolder extends RecyclerView.ViewHolder {
            View mView;
            public BlogViewHolder(@NonNull View itemView) {
                super(itemView);
                mView = itemView;
            }


            public void setImage(String image) throws IOException {
                ImageView mDCoverImage = mView.findViewById(R.id.DCoverImage);
               // Log.e("CoverImage :",image);
                try {
                    if (image != "" || image.equals(null))
                        Picasso.get().load(image).into(mDCoverImage);
                }catch(Exception e)
                {
                  //  Log.e("CoverImage :",image);
                }
                //mDCoverImage.setImageBitmap(bmp);
            }


            public void setRating(String rating) {
                TextView mDbookRating = (TextView)mView.findViewById(R.id.DbookRating);
                mDbookRating.setText(rating);
                mRecText.setVisibility(View.VISIBLE);
            }

            public void setSizeZero() {
                RelativeLayout rlayout = mView.findViewById(R.id.Home_book_card);
                rlayout.getLayoutParams().width = 0;
            }

           /* public void setReverse(String reverse) {
                if(!reverse.equals(""))
                Log.e("RatingInreverse",reverse);
            }*/
        }
        FirebaseRecyclerOptions<modelBook> options =
                new FirebaseRecyclerOptions.Builder<modelBook>()
                        .setQuery(mQuery, modelBook.class)
                        .setLifecycleOwner(this)
                        .build();
        FirebaseRecyclerAdapter<modelBook,BlogViewHolder> firebaseadapter = new FirebaseRecyclerAdapter<modelBook, BlogViewHolder>(options) {


            @Override
            protected void onBindViewHolder(@NonNull BlogViewHolder holder, int position, @NonNull final modelBook model) {
                   Log.e("onBindViewHolder","Called");
                if(RecoomendationBook.contains(model.getBookName().replaceAll("[^a-zA-Z0-9]", ""))) {
                    Log.e("onBindViewHolder  1","Called");

                       try {
                           holder.setImage(model.getCoverImage());
                       } catch (IOException e) {
                           e.printStackTrace();
                       }
                       // if(!model.getRatingInReverse().equals(null))
                       // holder.setReverse(model.getRatingInReverse());
                       holder.setRating(model.getRating());
                  }else{
                    holder.setSizeZero();
                   // Log.e("onBindViewHolder  2",model.getBookName());
                  //  Log.e("onBindViewHolder  2","Called");
                   }
                    holder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Bundle extras = new Bundle();
                            extras.putString("BookName" , model.getBookName());
                            extras.putString("BookAuthor" , model.getBookAuthor());
                            extras.putString("BookImage" , model.getCoverImage());
                            extras.putString("Genres" , model.getGenres1());
                            extras.putString("BookRating" , model.getRating());
                            extras.putString("Abstract101" , model.getAbstract101());
                            extras.putString("Abstract102" , model.getAbstract102());
                            extras.putString("Abstract103" , model.getAbstract103());
                            extras.putString("Abstract104" , model.getAbstract104());
                            extras.putString("Abstract105" , model.getAbstract105());
                            extras.putString("Abstract106" , model.getAbstract106());
                            extras.putString("Abstract107" , model.getAbstract107());
                            extras.putString("Abstract108" , model.getAbstract108());
                            extras.putString("Abstract109" , model.getAbstract109());
                            extras.putString("Abstract110" , model.getAbstract110());
                            extras.putString("Abstract111" , model.getAbstract111());
                            extras.putString("Abstract112" , model.getAbstract112());
                            extras.putString("Abstract113" , model.getAbstract113());
                            extras.putString("Abstract114" , model.getAbstract114());
                            extras.putString("Abstract115" , model.getAbstract115());


                            extras.putString("review101" , model.getComment101());
                            extras.putString("review102" , model.getComment102());
                            extras.putString("review103" , model.getComment103());
                            extras.putString("review104" , model.getComment104());
                            extras.putString("review105" , model.getComment105());
                            extras.putString("review106" , model.getComment106());
                            extras.putString("review107" , model.getComment107());
                            extras.putString("review108" , model.getComment108());
                            extras.putString("review109" , model.getComment109());
                            extras.putString("review110" , model.getComment110());
                            extras.putString("review111" , model.getComment111());
                            extras.putString("review112" , model.getComment112());
                            extras.putString("review113" , model.getComment113());
                            extras.putString("review114" , model.getComment114());
                            extras.putString("review115" , model.getComment115());

                            extras.putString("review201" , model.getComment201());
                            extras.putString("review202" , model.getComment202());
                            extras.putString("review203" , model.getComment203());
                            extras.putString("review204" , model.getComment204());
                            extras.putString("review205" , model.getComment205());
                            extras.putString("review206" , model.getComment206());
                            extras.putString("review207" , model.getComment207());
                            extras.putString("review208" , model.getComment208());
                            extras.putString("review209" , model.getComment209());
                            extras.putString("review210" , model.getComment210());
                            extras.putString("review211" , model.getComment211());
                            extras.putString("review212" , model.getComment212());
                            extras.putString("review213" , model.getComment213());
                            extras.putString("review214" , model.getComment214());
                            extras.putString("review215" , model.getComment215());



                            extras.putString("review301" , model.getComment301());
                            extras.putString("review302" , model.getComment302());
                            extras.putString("review303" , model.getComment303());
                            extras.putString("review304" , model.getComment304());
                            extras.putString("review305" , model.getComment305());
                            extras.putString("review306" , model.getComment306());
                            extras.putString("review307" , model.getComment307());
                            extras.putString("review308" , model.getComment308());
                            extras.putString("review309" , model.getComment309());
                            extras.putString("review310" , model.getComment310());
                            extras.putString("review311" , model.getComment311());
                            extras.putString("review312" , model.getComment312());
                            extras.putString("review313" , model.getComment313());
                            extras.putString("review314" , model.getComment314());
                            extras.putString("review315" , model.getComment315());

                            //extras.putString("mobile",model.getMobile());
                            // extras.putString("noacc",model.getTotalAcc());

                            Intent Details = new Intent(getActivity() , BookDetails.class);
                            Details.putExtras(extras);

                            startActivity(Details);

                        }
                    });
                    // Toast.makeText(getApplicationContext(),model.getName(),Toast.LENGTH_LONG).show();

            }

            @SuppressLint("RestrictedApi")
            @NonNull
            @Override
            public BlogViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view;
                view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.home_book_card, viewGroup , false);

                BlogViewHolder viewHolder = new BlogViewHolder(view);
                return viewHolder;
            }
        };
        //mrec.setLayoutManager(new LinearLayoutManager(getActivity()));
        mrec.setLayoutManager(Linearmanage);
        mrec.setAdapter(firebaseadapter);
        // Inflate the layout for this fragment
        return mViewvv;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
