package com.example.arkarcy.rawx;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class story extends AppCompatActivity {

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser,mCurrentUser1;
    private DatabaseReference mUserDatabase,mUserDatabase1;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    EditText e1,e2,e3;
    TextView t1;
    int SID1,SID2;
    String res="";
    //String t1,t2,t3,t4,t5;
    public String m5 = "",m2 = "",m3 = "",m4 = "";
    public String content,name,sid,title;
    String fetch2="", fetch3="", fetch4="", fetch5="";
    Button b1,b2,b3,b4,b5,b6;

    /*@Override
    public void onBackPressed(){
        Intent a = new Intent(Intent.ACTION_MAIN);
        a.addCategory(Intent.CATEGORY_HOME);
        a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(a);
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story);

        getSupportActionBar().setTitle("Story Contribution");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        b1 = findViewById(R.id.myContribution);
        b2 = findViewById(R.id.createStory);
        b3 = findViewById(R.id.otherPeopleStory);
        b4 = findViewById(R.id.saved);
        b5 = findViewById(R.id.sharedwithMe);
        b6 = findViewById(R.id.fav);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(story.this,mycontribution.class));
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openDialog();
                //finish();
                //startActivity(new Intent(story.this,story_solo.class));
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                startActivity(new Intent(story.this,OtherPeopleStories.class));
            }
        });

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),story_saved.class);
                i.putExtra("act","story");
                startActivity(i);
                //startActivity(new Intent(story.this,story_saved.class));
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(story.this,SharedWithMe.class));
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(story.this,myFavorite.class));
            }
        });
    }

    private void openDialog() {
        alertboxstory dialog = new alertboxstory();
        dialog.show(getSupportFragmentManager(),"Example Dialog");
    }
}
