package com.example.arkarcy.rawx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.ArrayList;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link PopularityRec.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link PopularityRec#newInstance} factory method to
 * create an instance of this fragment.
 */
public class PopularityRec extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    String bookId = "[",userId = "[",userRating = "[",genre = "[",bookName = "[",bookRating = "[";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public int keyOfBooks[] = new int[100];
    public ArrayList<Integer> keyOfBook = new ArrayList<Integer>();
    private String l0 = "",l1="",l2="";

    private RecyclerView mrec;
    private Query mQuery;
    private String genres;
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();


    private OnFragmentInteractionListener mListener;

    public PopularityRec() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment PopularityRec.
     */
    // TODO: Rename and change types and number of parameters
    public static PopularityRec newInstance(String param1, String param2) {
        PopularityRec fragment = new PopularityRec();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        mRef = FirebaseDatabase.getInstance().getReference().child("content").child("content");
        mRef.keepSynced(true);


        mQuery = mRef.orderByKey();

       /* mRef.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    //Log.e("datasnapshot",data.child("Email").toString());
                    if (data.hasChild("BookRating")){
                        //Log.e("datasnapshot",data.getKey().toString());
                        for (DataSnapshot data1 : data.child("BookRating").getChildren()){
                            userId = userId + data.getKey() + ",";
                            bookId = bookId + data1.getKey() + ",";
                            userRating = userRating + data1.getValue() + ",";

                            mRef.child("Books").child(data1.getKey()).addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                                    //Log.e("genre111",dataSnapshot1.child("Genres1").getValue().toString());
                                    genre = genre + dataSnapshot1.child("Genres1").getValue().toString() + ",";
                                    bookName = bookName + dataSnapshot1.child("BookName").getValue().toString() + ",";
                                    bookRating = bookRating + dataSnapshot1.child("AppRating").getValue().toString() + ",";
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }

                        //bookId = bookId + data.child("BookRating").getKey() + ",";
                    }
                }
                userId = userId + "0" + "]";
                bookId = bookId + "0" + "]";
                userRating = userRating + "0" + "]";
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/

       /* mRef.child("Users").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                final int[] flag = {0};
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    //Log.e("datasnapshot",data.child("Email").toString());
                    if (data.hasChild("BookRating")){
                        //Log.e("datasnapshot",data.getKey().toString());
                        for (DataSnapshot data1 : data.child("BookRating").getChildren()){

                            mRef.child("Books").child(data1.getKey()).addValueEventListener(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                                    //Log.e("genre111",dataSnapshot1.child("Genres1").getValue().toString());
                                    if (flag[0] == 0){
                                        genre = genre + "0" + "]";
                                        bookName = bookName + "0" + "]";
                                        bookRating = bookRating + "0" + "]";
                                        flag[0] = 1;

                                        Log.e("genre",genre);
                                        Log.e("bookName",bookName);
                                        Log.e("bookRating",bookRating);

                                    }

                                    Log.e("userid",userId);
                                    Log.e("bookid",bookId);
                                    Log.e("userRating",userRating);
                                }

                                @Override
                                public void onCancelled(@NonNull DatabaseError databaseError) {

                                }
                            });
                        }

                        //bookId = bookId + data.child("BookRating").getKey() + ",";
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });*/
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View mView = inflater.inflate(R.layout.fragment_trending_books_popularity , container , false);

        mrec= (RecyclerView)mView.findViewById(R.id.rectrend);
        class BlogViewHolder extends RecyclerView.ViewHolder {
            View mView;
            public BlogViewHolder(@NonNull View itemView) {
                super(itemView);
                mView = itemView;
            }

            public void setBookname(String bookname) {
                TextView mcname = (TextView) mView.findViewById(R.id.DbookName);
                mcname.setText(bookname);
                TextView mDbookAuthor = (TextView)mView.findViewById(R.id.DbookAuthor);
                mDbookAuthor.setText("");
                TextView mdFrom = (TextView)mView.findViewById(R.id.Dfrom);
                mdFrom.setText("");
                TextView mDGenresT = (TextView)mView.findViewById(R.id.DGenresT);
                mDGenresT.setText("");
            }

            public void setImage(String image) throws IOException {
                ImageView mDCoverImage = mView.findViewById(R.id.DCoverImage);
                Log.e("CoverImage :",image);
                try {
                    if (image != "" || image.equals(null))
                        Picasso.get().load(image).into(mDCoverImage);
                }catch(Exception e)
                {
                    Log.e("CoverImage :",image);
                }
                //mDCoverImage.setImageBitmap(bmp);
            }


            public void setBookAuthor(String bookAuthor) {
                TextView mDbookAuthor = (TextView)mView.findViewById(R.id.DbookAuthor);
                mDbookAuthor.setText(bookAuthor);
                //   this.bookAuthor = bookAuthor;
            }

            public void setGenres(String genres1 , String genres2 , String genres3) {
                TextView mDGenres = (TextView)mView.findViewById(R.id.DGenres);
                TextView mDGenresT = (TextView)mView.findViewById(R.id.DGenresT);
                mDGenres.setText(genres1);
                mDGenresT.setText("");
//                this.genres = genres;
            }

            public void setRating(String rating) {
                TextView mDbookRating = (TextView)mView.findViewById(R.id.DbookRating);
                mDbookRating.setText("Rating : "+rating);
            }

            public void setSizeZero() {
                RelativeLayout rlayout = mView.findViewById(R.id.book_card);
                rlayout.getLayoutParams().height = 0;

            }


        }
        FirebaseRecyclerOptions<modelContent> options =
                new FirebaseRecyclerOptions.Builder<modelContent>()
                        .setQuery(mQuery, modelContent.class)
                        .setLifecycleOwner(this)
                        .build();
        FirebaseRecyclerAdapter<modelContent,BlogViewHolder> firebaseadapter = new FirebaseRecyclerAdapter<modelContent, BlogViewHolder>(options) {


            @Override
            protected void onBindViewHolder(@NonNull BlogViewHolder holder, int position, @NonNull final modelContent model) {

                //Log.e("BookName : " , model.getBookName());
                holder.setBookname(model.getBookName());
                try {
                    holder.setImage(model.getBookImage());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                holder.setRating(model.getBookRating());

                // Toast.makeText(getApplicationContext(),model.getName(),Toast.LENGTH_LONG).show();

            }


            @SuppressLint("RestrictedApi")
            @NonNull
            @Override
            public BlogViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view;
                view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.book_card, viewGroup , false);

                BlogViewHolder viewHolder = new BlogViewHolder(view);
                return viewHolder;
            }
        };
        mrec.setLayoutManager(new LinearLayoutManager(getActivity()));
        mrec.setAdapter(firebaseadapter);
        return mView;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
