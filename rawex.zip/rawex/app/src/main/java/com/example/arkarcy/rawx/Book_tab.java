package com.example.arkarcy.rawx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import java.io.IOException;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link Book_tab.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link Book_tab#newInstance} factory method to
 * create an instance of this fragment.
 */
public class Book_tab extends DialogFragment {
    private RecyclerView mrec;
    private Query mQuery;
    private String genres;
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public Book_tab() {
        // Required empty public constructor
    }

    @SuppressLint("ValidFragment")
    public Book_tab(String gen) {
      genres = gen;
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment Book_tab.
     */
    // TODO: Rename and change types and number of parameters
    public static Book_tab newInstance(String param1 , String param2) {
        Book_tab fragment = new Book_tab();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1 , param1);
        args.putString(ARG_PARAM2 , param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mRef = FirebaseDatabase.getInstance().getReference().child("Books");
        mRef.keepSynced(true);
        mQuery = mRef.orderByChild("Genres1").equalTo(genres);
        //mQuery = mRef.orderByKey();
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        if(getFragmentManager().getBackStackEntryCount() > 0){
         //   getFragmentManager().popBackStackImmediate();
        }
        else{
          //  super.onBackPressed();
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        final View mViewvv = inflater.inflate(R.layout.fragment_booklist , container , false);//fragment_booklist

        mrec= (RecyclerView)mViewvv.findViewById(R.id.drec);
        mRef = FirebaseDatabase.getInstance().getReference().child("Books");


        class BlogViewHolder extends RecyclerView.ViewHolder {
            View mView;
            public BlogViewHolder(@NonNull View itemView) {
                super(itemView);
                mView = itemView;
            }

            public void setBookname(String bookname) {
                TextView mcname = (TextView) mView.findViewById(R.id.DbookName);
                mcname.setText(bookname);
            }

            public void setImage(String image) throws IOException {
                ImageView mDCoverImage = mView.findViewById(R.id.DCoverImage);
                Log.e("CoverImage :",image);
                try {
                    if (image != "" || image.equals(null))
                        Picasso.get().load(image).into(mDCoverImage);
                }catch(Exception e)
                {
                    Log.e("CoverImage :",image);
                }
                //mDCoverImage.setImageBitmap(bmp);
            }

            public void setBookAuthor(String bookAuthor) {
                TextView mDbookAuthor = (TextView)mView.findViewById(R.id.DbookAuthor);
                mDbookAuthor.setText(bookAuthor);
                //   this.bookAuthor = bookAuthor;
            }

            public void setGenres(String genres1 , String genres2 , String genres3) {
                TextView mDGenres = (TextView)mView.findViewById(R.id.DGenres);
                mDGenres.setText(genres1);
//                this.genres = genres;
            }

            public void setRating(String rating) {
                TextView mDbookRating = (TextView)mView.findViewById(R.id.DbookRating);
                mDbookRating.setText(rating);
            }

            public void setSizeZero() {
                RelativeLayout rlayout = mView.findViewById(R.id.book_card);
                rlayout.getLayoutParams().height = 0;


            }
        }
        FirebaseRecyclerOptions<modelBook> options =
                new FirebaseRecyclerOptions.Builder<modelBook>()
                        .setQuery(mQuery, modelBook.class)
                        .setLifecycleOwner(this)
                        .build();
        FirebaseRecyclerAdapter<modelBook,BlogViewHolder> firebaseadapter = new FirebaseRecyclerAdapter<modelBook, BlogViewHolder>(options) {


            @Override
            protected void onBindViewHolder(@NonNull BlogViewHolder holder, int position, @NonNull final modelBook model) {
                if(model.getGenres1().equals(genres)) {
                    holder.setBookname(model.getBookName());
                    try {
                        holder.setImage(model.getCoverImage());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    holder.setBookAuthor(model.getBookAuthor());
                    holder.setGenres(model.getGenres1() , model.getGenres2() , model.getGenres3());
                    holder.setRating(model.getRating());
                    holder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Bundle extras = new Bundle();

                            extras.putString("AppRating",model.getAppRating());
                            extras.putString("AppUserNumber",model.getAppUserNumber());

                            extras.putString("BookName" , model.getBookName());
                            extras.putString("BookAuthor" , model.getBookAuthor());
                            extras.putString("BookImage" , model.getCoverImage());
                            extras.putString("Genres" , model.getGenres1());
                            extras.putString("BookRating" , model.getRating());

                            extras.putString("Abstract101" , model.getAbstract101());
                            extras.putString("Abstract102" , model.getAbstract102());
                            extras.putString("Abstract103" , model.getAbstract103());
                            extras.putString("Abstract104" , model.getAbstract104());
                            extras.putString("Abstract105" , model.getAbstract105());
                            extras.putString("Abstract106" , model.getAbstract106());
                            extras.putString("Abstract107" , model.getAbstract107());
                            extras.putString("Abstract108" , model.getAbstract108());
                            extras.putString("Abstract109" , model.getAbstract109());
                            extras.putString("Abstract110" , model.getAbstract110());
                            extras.putString("Abstract111" , model.getAbstract111());
                            extras.putString("Abstract112" , model.getAbstract112());
                            extras.putString("Abstract113" , model.getAbstract113());
                            extras.putString("Abstract114" , model.getAbstract114());
                            extras.putString("Abstract115" , model.getAbstract115());


                            extras.putString("review101" , model.getComment101());
                            extras.putString("review102" , model.getComment102());
                            extras.putString("review103" , model.getComment103());
                            extras.putString("review104" , model.getComment104());
                            extras.putString("review105" , model.getComment105());
                            extras.putString("review106" , model.getComment106());
                            extras.putString("review107" , model.getComment107());
                            extras.putString("review108" , model.getComment108());
                            extras.putString("review109" , model.getComment109());
                            extras.putString("review110" , model.getComment110());
                            extras.putString("review111" , model.getComment111());
                            extras.putString("review112" , model.getComment112());
                            extras.putString("review113" , model.getComment113());
                            extras.putString("review114" , model.getComment114());
                            extras.putString("review115" , model.getComment115());

                            extras.putString("review201" , model.getComment201());
                            extras.putString("review202" , model.getComment202());
                            extras.putString("review203" , model.getComment203());
                            extras.putString("review204" , model.getComment204());
                            extras.putString("review205" , model.getComment205());
                            extras.putString("review206" , model.getComment206());
                            extras.putString("review207" , model.getComment207());
                            extras.putString("review208" , model.getComment208());
                            extras.putString("review209" , model.getComment209());
                            extras.putString("review210" , model.getComment210());
                            extras.putString("review211" , model.getComment211());
                            extras.putString("review212" , model.getComment212());
                            extras.putString("review213" , model.getComment213());
                            extras.putString("review214" , model.getComment214());
                            extras.putString("review215" , model.getComment215());



                            extras.putString("review301" , model.getComment301());
                            extras.putString("review302" , model.getComment302());
                            extras.putString("review303" , model.getComment303());
                            extras.putString("review304" , model.getComment304());
                            extras.putString("review305" , model.getComment305());
                            extras.putString("review306" , model.getComment306());
                            extras.putString("review307" , model.getComment307());
                            extras.putString("review308" , model.getComment308());
                            extras.putString("review309" , model.getComment309());
                            extras.putString("review310" , model.getComment310());
                            extras.putString("review311" , model.getComment311());
                            extras.putString("review312" , model.getComment312());
                            extras.putString("review313" , model.getComment313());
                            extras.putString("review314" , model.getComment314());
                            extras.putString("review315" , model.getComment315());

                            //extras.putString("mobile",model.getMobile());
                            // extras.putString("noacc",model.getTotalAcc());

                            Intent Details = new Intent(getActivity() , BookDetails.class);
                            Details.putExtras(extras);

                            startActivity(Details);

                        }
                    });
                    // Toast.makeText(getApplicationContext(),model.getName(),Toast.LENGTH_LONG).show();
                }
                else
                {
                    holder.setSizeZero();
                }
            }

            @SuppressLint("RestrictedApi")
            @NonNull
            @Override
            public BlogViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view;
                view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.book_card, viewGroup , false);

                BlogViewHolder viewHolder = new BlogViewHolder(view);
                return viewHolder;
            }
        };
        mrec.setLayoutManager(new LinearLayoutManager(getActivity()));
        mrec.setAdapter(firebaseadapter);
        // Inflate the layout for this fragment
        return mViewvv;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       /* if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }*/
    }

    @Override
    public void onStart() {
        super.onStart();
        try {
            mListener = (OnFragmentInteractionListener) getActivity();
        } catch (ClassCastException e) {
            throw new ClassCastException(getActivity().toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }



    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }



}
