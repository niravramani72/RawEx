package com.example.arkarcy.rawx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import java.io.IOException;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link AllBooks.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link AllBooks#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AllBooks extends Fragment {
    private RecyclerView mrec;
    private Query mQuery;
    private String genres;
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();
    private int numberOfNode = 8839;
    private int randomIndex = (int) Math.floor(Math.random() * numberOfNode);


    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public AllBooks() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AllBooks.
     */
    // TODO: Rename and change types and number of parameters
    public static AllBooks newInstance(String param1 , String param2) {
        AllBooks fragment = new AllBooks();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1 , param1);
        args.putString(ARG_PARAM2 , param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mRef = FirebaseDatabase.getInstance().getReference().child("Amazon").child(String.valueOf(randomIndex*30));
        mRef.keepSynced(true);
        //mQuery = mRef.startAt(randomIndex).endAt(randomIndex + 4);
        mQuery = mRef.orderByChild("key");
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        final View mViewvv = inflater.inflate(R.layout.fragment_booklist , container , false);//fragment_booklist

        mrec= (RecyclerView)mViewvv.findViewById(R.id.drec);

       // mrec.setHasFixedSize(true);
      //  mQuery = mRef.startAt(randomIndex).endAt(randomIndex + 4);

        class BlogViewHolder extends RecyclerView.ViewHolder {
            View mView;
            public BlogViewHolder(@NonNull View itemView) {
                super(itemView);
                mView = itemView;
            }

            public void setBookname(String bookname) {
                TextView mcname = (TextView) mView.findViewById(R.id.DbookName);
                TextView mfrom = mView.findViewById(R.id.Dfrom);
                TextView mrat = mView.findViewById(R.id.DbookRating);
                TextView mgenere = mView.findViewById(R.id.DGenres);
                TextView mgeneret = mView.findViewById(R.id.DGenresT);
                mgeneret.setText("");
                mgenere.setText("");
                mrat.setText("");
                mfrom.setText("-By Amazon");
                mcname.setText(bookname);
            }

            public void setImage(String image) throws IOException {
                ImageView mDCoverImage = mView.findViewById(R.id.DCoverImage);
                Log.e("CoverImage :",image);
                try {
                    if (image != "" || image.equals(null))
                        Picasso.get().load(image).into(mDCoverImage);
                }catch(Exception e)
                {
                    Log.e("CoverImage :",image);
                }
                //mDCoverImage.setImageBitmap(bmp);
            }

            public void setBookAuthor(String bookAuthor) {
                TextView mDbookAuthor = (TextView)mView.findViewById(R.id.DbookAuthor);
                mDbookAuthor.setText(bookAuthor);
                //   this.bookAuthor = bookAuthor;
            }


            public void setSizeZero() {
                RelativeLayout rlayout = mView.findViewById(R.id.book_card);
                rlayout.getLayoutParams().height = 0;


            }
        }
        FirebaseRecyclerOptions<modelAmazonBook> options =
                new FirebaseRecyclerOptions.Builder<modelAmazonBook>()
                        .setQuery(mQuery, modelAmazonBook.class)
                        .setLifecycleOwner(this)
                        .build();
        FirebaseRecyclerAdapter<modelAmazonBook,BlogViewHolder> firebaseadapter = new FirebaseRecyclerAdapter<modelAmazonBook, BlogViewHolder>(options) {


            @Override
            protected void onBindViewHolder(@NonNull BlogViewHolder holder, int position, @NonNull final modelAmazonBook model) {
                    Log.e("Book :","Book Found");

                    holder.setBookname(model.getBookName());
                    try {
                        holder.setImage(model.getCoverImage());
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    holder.setBookAuthor(model.getBookAuthor());
                    //holder.setGenres(model.getGenres1() , model.getGenres2() , model.getGenres3());
                  //  holder.setRating(model.getRating());
                    holder.mView.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            Bundle extras = new Bundle();
                            extras.putString("BookName" , model.getBookName());
                            extras.putString("BookAuthor" , model.getBookAuthor());
                            extras.putString("BookImage" , model.getCoverImage());

                            // extras.putString("noacc",model.getTotalAcc());

                            Intent Details = new Intent(getActivity() , BookDetails_OnlyBooks.class);
                            Details.putExtras(extras);

                            startActivity(Details);

                        }
                    });
                    // Toast.makeText(getApplicationContext(),model.getName(),Toast.LENGTH_LONG).show();

            }

            @SuppressLint("RestrictedApi")
            @NonNull
            @Override
            public BlogViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view;
                view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.book_card, viewGroup , false);

                BlogViewHolder viewHolder = new BlogViewHolder(view);
                return viewHolder;
            }
        };
        mrec.setLayoutManager(new LinearLayoutManager(getActivity()));
        mrec.setAdapter(firebaseadapter);

        // Inflate the layout for this fragment
        return mViewvv;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
