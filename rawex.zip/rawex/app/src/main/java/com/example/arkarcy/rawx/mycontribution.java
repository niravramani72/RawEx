package com.example.arkarcy.rawx;

import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class mycontribution extends AppCompatActivity{
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;
    private ArrayList<modelStory> list = new ArrayList<>();
    private ArrayList<modelStory> listShared = new ArrayList<>();
    private ArrayList<modelStoryGroup> listGroup = new ArrayList<>();

    private TextView mbSolo ,mbGroup ,mbShared;
    private int flag = 0;
    private int f1 = 0;
    private String res = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mycontribution);

        getSupportActionBar().setTitle("My Contribution");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        mbSolo = findViewById(R.id.solo);
        mbGroup = findViewById(R.id.group);
        mbShared = findViewById(R.id.shared);

        recyclerView = (RecyclerView) findViewById(R.id.myContribution);

        layoutManager = new LinearLayoutManager(this);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(layoutManager);

        mbGroup.setTextColor(getResources().getColor(R.color.grey));
        mbShared.setTextColor(getResources().getColor(R.color.grey));
        flag=1;
       // get();
        mbSolo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=1;
                mbGroup.setTextColor(getResources().getColor(R.color.grey));
                mbSolo.setTextColor(getResources().getColor(R.color.white));
                mbShared.setTextColor(getResources().getColor(R.color.grey));
                if(f1==0)
                get();
            }
        });
        mbGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=2;
                mbSolo.setTextColor(getResources().getColor(R.color.grey));
                mbGroup.setTextColor(getResources().getColor(R.color.white));
                mbShared.setTextColor(getResources().getColor(R.color.grey));
                if(f1==0)
                get();
            }
        });
        mbShared.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=3;
                mbSolo.setTextColor(getResources().getColor(R.color.grey));
                mbShared.setTextColor(getResources().getColor(R.color.white));
                mbGroup.setTextColor(getResources().getColor(R.color.grey));
                if(f1==0)
                    get1();
            }
        });
       // get();
       // recyclerView.invalidate();

        Log.e("Asizemycontribution","oncreate");
    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        get();
        Log.e("Asizemycontribution","resumed");
    }

    void get(){
        f1=1;
        list.clear();

        listShared.clear();
        Log.e("ListSize",String.valueOf(list.size()));
        listGroup.clear();
        String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replaceAll("[^a-zA-Z0-9]", "");
        mRef.child("Story").child("StoryUser").child(email).child("Story").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Log.e("Datasnap",dataSnapshot.getKey());
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Log.e("Found Type :",data.getValue().toString());
                    if(data.getValue().toString().equals("Group")){
                        mRef.child("Story").child("StoryListingGroup").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelStoryGroup mObj  = dataSnapshot.getValue(modelStoryGroup.class);
                                //Log.e("Book Name ",mObj.getTitle());
                                listGroup.add(mObj);

                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                    else if(data.getValue().toString().equals("Solo"))
                    {
                        mRef.child("Story").child("StoryListingSolo").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelStory mObj  = dataSnapshot.getValue(modelStory.class);
//                                Log.e("Book Name ",mObj.getContent());

                                try{
                                    if(mObj.getTitle()!= null){
                                        list.add(mObj);
  //                                      Log.e("Asizemycontribution",mObj.getTitle());
                                    }

                                }catch (Exception e){

                                }

                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        Log.e("GET","Get Completed");
    }

    void get1(){
        f1=1;
        listShared.clear();
        final String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replaceAll("[^a-zA-Z0-9]", "");
        mRef.child("Story").child("StoryUser").child(email).child("StoryShared").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // Log.e("Datasnap",dataSnapshot.getKey());
                for (DataSnapshot data : dataSnapshot.getChildren()){
                    Log.e("Found Type :",data.getValue().toString());
                    if(data.getValue().toString().equals("Shared")){
                        mRef.child("Story").child("StoryListingShared").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                modelStory mObj  = dataSnapshot.getValue(modelStory.class);
                                //Log.e("Book Name ",mObj.getTitle());
                                listShared.add(mObj);

                                display();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    void display(){
        //===========================================//
        Log.e("Display called","");
        if(flag==2)
        {

            adapter = new storyHolderGroup(getApplicationContext(),listGroup);
            Log.e("Asize",String.valueOf(adapter.getItemCount()));
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }
        else {

            Log.e("AsizeListSize",String.valueOf(list.size()));
            adapter = new storyHolder(getApplicationContext(),list);
            Log.e("Asize",String.valueOf(adapter.getItemCount()));
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }
        if(flag==3)
        {
            adapter = new storyHolder(getApplicationContext(),listShared);
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }


    }
}
