package com.example.arkarcy.rawx;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class list_of_books extends AppCompatActivity {
    private RecyclerView mrec;
    private Query mQuery;
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_books);
        mrec= (RecyclerView)findViewById(R.id.drec);
        mRef = FirebaseDatabase.getInstance().getReference().child("Books");
        mQuery = mRef.orderByKey();

    }
    @Override
    protected void onStart() {
        super.onStart();
        class BlogViewHolder extends RecyclerView.ViewHolder {
            View mView;
            public BlogViewHolder(@NonNull View itemView) {
                super(itemView);
                mView = itemView;
            }

            public void setBookname(String bookname) {
                TextView mcname = (TextView) mView.findViewById(R.id.DbookName);
                mcname.setText(bookname);
            }

            public void setImage(String image) throws IOException {
                ImageView mDCoverImage = mView.findViewById(R.id.DCoverImage);
                Log.e("CoverImage :",image);
                try {
                    if (image != "" || image.equals(null))
                        Picasso.get().load(image).into(mDCoverImage);
                }catch(Exception e)
                {
                    Log.e("CoverImage :",image);
                }
                //mDCoverImage.setImageBitmap(bmp);
            }

            public void setBookAuthor(String bookAuthor) {
                TextView mDbookAuthor = (TextView)mView.findViewById(R.id.DbookAuthor);
                mDbookAuthor.setText(bookAuthor);
             //   this.bookAuthor = bookAuthor;
            }

            public void setGenres(String genres1 , String genres2 , String genres3) {
                TextView mDGenres = (TextView)mView.findViewById(R.id.DGenres);
                mDGenres.setText(genres1);
//                this.genres = genres;
            }

            public void setRating(String rating) {
                TextView mDbookRating = (TextView)mView.findViewById(R.id.DbookRating);
                mDbookRating.setText(rating);
            }
        }
        FirebaseRecyclerOptions<modelBook> options =
                new FirebaseRecyclerOptions.Builder<modelBook>()
                        .setQuery(mQuery, modelBook.class)
                        .setLifecycleOwner(this)
                        .build();
        FirebaseRecyclerAdapter<modelBook,BlogViewHolder> firebaseadapter = new FirebaseRecyclerAdapter<modelBook, BlogViewHolder>(options) {


            @Override
            protected void onBindViewHolder(@NonNull BlogViewHolder holder, int position, @NonNull final modelBook model) {
                holder.setBookname(model.getBookName());
                try {
                    holder.setImage(model.getCoverImage());
                } catch (IOException e) {
                    e.printStackTrace();
                }
                holder.setBookAuthor(model.getBookAuthor());
                holder.setGenres(model.getGenres1(),model.getGenres2(),model.getGenres3());
                holder.setRating(model.getRating());
                holder.mView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Bundle extras = new Bundle();
                        extras.putString("BookName",model.getBookName());
                        extras.putString("BookAuthor",model.getBookAuthor());
                        extras.putString("BookImage",model.getCoverImage());
                        extras.putString("Genres",model.getGenres1());
                        extras.putString("BookRating",model.getRating());
                    /*    extras.putString("Abstract",model.getAbstract());
                        extras.putString("review1",model.getComment1());
                        extras.putString("review2",model.getComment2());
                        extras.putString("review3",model.getComment3());*/

                        //extras.putString("mobile",model.getMobile());
                       // extras.putString("noacc",model.getTotalAcc());

                        Intent Details = new Intent(getApplicationContext(),BookDetails.class);
                        Details.putExtras(extras);

                        startActivity(Details);

                    }
                });
                // Toast.makeText(getApplicationContext(),model.getName(),Toast.LENGTH_LONG).show();

            }

            @NonNull
            @Override
            public BlogViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view;
                view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.book_card, viewGroup , false);

                BlogViewHolder viewHolder = new BlogViewHolder(view);
                return viewHolder;
            }
        };
        mrec.setLayoutManager(new LinearLayoutManager(this));
        mrec.setAdapter(firebaseadapter);



    }

}


