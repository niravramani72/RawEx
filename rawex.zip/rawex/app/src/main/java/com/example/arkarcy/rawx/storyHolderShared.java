package com.example.arkarcy.rawx;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.List;

public class storyHolderShared extends RecyclerView.Adapter<storyHolderShared.MyViewHolder> {

    private Context mContext;
    private List<modelSharedStory> mDataList;

    public storyHolderShared(Context mContext, List<modelSharedStory> mDataList) {
        this.mContext = mContext;
        this.mDataList = mDataList;
    }

    @NonNull
    @Override
    public storyHolderShared.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.model,viewGroup,false);
        return new storyHolderShared.MyViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull storyHolderShared.MyViewHolder myViewHolder, int i) {
        final modelSharedStory mod = mDataList.get(i);
        try{
            myViewHolder.title1.setText(mod.getTitle());
            myViewHolder.story1.setText("Shared by "+mod.getName1());
            myViewHolder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.e("Story",mod.getContent1());
                    Intent intent = new Intent(mContext,AcceptDeclineGroupStory.class);
                    intent.putExtra("pass", (Serializable) mod);
                    //intent.putExtra("act","B");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(intent);

                }
            });
        }
        catch(Exception e){}
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{


        TextView title1,story1;
        View mView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            title1 = itemView.findViewById(R.id.title);
            story1 = itemView.findViewById(R.id.story);
        }
    }
}