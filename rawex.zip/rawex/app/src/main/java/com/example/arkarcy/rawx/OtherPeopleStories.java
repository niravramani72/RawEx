package com.example.arkarcy.rawx;

import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class OtherPeopleStories extends AppCompatActivity {

    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView.Adapter adapter;
    private ArrayList<modelStory> list = new ArrayList<>();
    private ArrayList<modelStoryGroup> listGroup = new ArrayList<>();

    private TextView mbSolo ,mbGroup;
    private int flag = 0;
    private int f1 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other_people_stories);

        getSupportActionBar().setTitle("All People Stories");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }


        mbSolo = findViewById(R.id.solo);
        mbGroup = findViewById(R.id.group);

        recyclerView = (RecyclerView) findViewById(R.id.myContribution);

        layoutManager = new LinearLayoutManager(this);

        recyclerView.setLayoutManager(layoutManager);

        mbGroup.setTextColor(getResources().getColor(R.color.grey));
        flag=1;

        mbSolo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=1;
                mbGroup.setTextColor(getResources().getColor(R.color.grey));
                mbSolo.setTextColor(getResources().getColor(R.color.white));
                if(f1==0)
                    get();
            }
        });
        mbGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                flag=2;
                mbSolo.setTextColor(getResources().getColor(R.color.grey));
                mbGroup.setTextColor(getResources().getColor(R.color.white));
                if(f1==0)
                    get();
            }
        });
        //get();

    }

    @Override
    protected void onPostResume() {
        super.onPostResume();

        get();
        Log.e("Asizemycontribution","resumed");
    }

    void get(){
        f1=1;
        list.clear();
        listGroup.clear();
        final String email = FirebaseAuth.getInstance().getCurrentUser().getEmail().replaceAll("[^a-zA-Z0-9]", "");
        mRef.child("Story").child("StoryListingSolo").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // Log.e("Datasnap",dataSnapshot.getKey());
                //Log.e("Found Type :",data.getValue().toString());

                mRef.child("Story").child("StoryListingSolo").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        modelStory mObj  = dataSnapshot.getValue(modelStory.class);
                        Log.e("other people story ",mObj.getContent());

                        list.add(mObj);

                        display();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        mRef.child("Story").child("StoryListingGroup").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                // Log.e("Datasnap",dataSnapshot.getKey());
                //Log.e("Found Type :",data.getValue().toString());
                mRef.child("Story").child("StoryListingGroup").child(dataSnapshot.getKey()).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        modelStoryGroup mObj1  = dataSnapshot.getValue(modelStoryGroup.class);
                        //Log.e("Book Name ",mObj.getTitle());
                        listGroup.add(mObj1);

                        display();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });

            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }
    void display(){
        //===========================================//
        Log.e("Display called","");
        if(flag==2)
        {
            adapter = new storyHolderGroup(getApplicationContext(),listGroup);
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }
        else {
            adapter = new storyHolder(getApplicationContext(),list);
            recyclerView.setAdapter(adapter);
            adapter.notifyDataSetChanged();
            f1=0;
        }


    }
}
