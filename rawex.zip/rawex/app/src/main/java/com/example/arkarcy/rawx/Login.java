package com.example.arkarcy.rawx;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

public class Login extends AppCompatActivity implements  View.OnClickListener,GoogleApiClient.OnConnectionFailedListener {
    private SignInButton signinbtn;
    private GoogleApiClient mGoogleSignInClient;
    private FirebaseAuth.AuthStateListener mAuthListner;
    private FirebaseAuth mAuth;
    private static final int RC_SIGN_IN = 1;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference myRef = database.getReference().child("users");
    private DatabaseReference mynewRef = database.getReference().child("newusers");
    String usern;


    private DatabaseReference ref = database.getReference("Users");
    private FirebaseUser mAuth2 = FirebaseAuth.getInstance().getCurrentUser();
    // login
    private Button mblogin,msignup;
    private TextView mforgettext;
    private EditText memail;
    private EditText mpassword;
    private ProgressDialog mprogressdialog;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mdatabaseUsers;
    //dialogue
    private ProgressDialog pd;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mforgettext = (TextView) findViewById(R.id.forgetpassword);
        pd = new ProgressDialog(Login.this);
        mforgettext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LayoutInflater inflater = LayoutInflater.from(Login.this);
                View subView = inflater.inflate(R.layout.dialog_forget, null);
                final EditText email = (EditText) subView.findViewById(R.id.email);
                AlertDialog.Builder builder = new AlertDialog.Builder(Login.this);
                builder.setMessage("Enter Email for reset Password : ").setTitle("Forget Password?");

                // final String code = joinroomcode.getText().toString().trim();
                // Inflate and set the layout for the dialog
                // Pass null as the parent view because its going in the dialog layout

                builder.setView(subView);

                builder.setPositiveButton("Reset", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        String remail = email.getText().toString();
                        if(remail.isEmpty())
                        {
                            Toast.makeText(Login.this,"Make sure You Entered the Email",Toast.LENGTH_SHORT).show();
                        } else {
                            FirebaseAuth auth = FirebaseAuth.getInstance();
                            auth.sendPasswordResetEmail(remail)
                                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {
                                            if (task.isSuccessful()) {
                                                Toast.makeText(Login.this, "Reset mail is sent", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });
                        }


                    }
                });
                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User cancelled the dialog
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
        signinbtn = (SignInButton) findViewById(R.id.googlelogin);
        mAuth = FirebaseAuth.getInstance();
        mAuthListner = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    usern= mAuth.getInstance().getCurrentUser().getUid();
                    myRef.addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(DataSnapshot dataSnapshot) {
                            for( DataSnapshot snap: dataSnapshot.getChildren()){
                                Log.e(snap.getKey(),snap.getChildrenCount() + "");
                            }

                            if(!dataSnapshot.hasChild(usern)){
                                myRef.child(usern).child("username").setValue(usern);
                                mynewRef.child(mAuth.getInstance().getCurrentUser().getUid()).child("username").setValue(usern);
                            }
                          /*  else{
                                  Intent i = new Intent(MainActivity.this,chat.class);
                                // Intent i = new Intent(this,chat.class);
                                startActivity(i);
                                overridePendingTransition(R.anim.slide_in, R.anim.slide_out);

                            }*/
                        }

                        @Override
                        public void onCancelled(DatabaseError databaseError) {
                            //   Toast.makeText(MainActivity.this, " DataBase ERROR!",Toast.LENGTH_LONG).show();
                            // startActivity(new Intent(getApplicationContext(),chatRecycler.class));
                            overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                            finish();
                        }
                    });

                    //Toast.makeText(MainActivity.this, "Logging IN!",Toast.LENGTH_LONG).show();
                    //finish();
                    // startActivity(new Intent(getApplicationContext(),chat.class));
                    if (user.isEmailVerified()) {
                        Intent i = new Intent(Login.this, Main2Activity.class);
                        // Intent i = new Intent(this,chat.class);
                        // Toast.makeText(MainActivity.this, "1",Toast.LENGTH_LONG).show();
                        startActivity(i);
                        // overridePendingTransition(R.anim.slide_in, R.anim.slide_out);
                        finish();
                    }
                    //Toast.makeText()
                } else {
                }
            }
        };
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();



        mGoogleSignInClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, this)
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        signinbtn.setOnClickListener(this);

        //login
        firebaseAuth = FirebaseAuth.getInstance();
        mdatabaseUsers= FirebaseDatabase.getInstance().getReference().child("users");
        mdatabaseUsers.keepSynced(true);

        if(firebaseAuth.getCurrentUser() != null)
        {
            FirebaseUser user = firebaseAuth.getCurrentUser();
            if(user.isEmailVerified()) {
                finish();
                //  Toast.makeText(MainActivity.this, "4", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(getApplicationContext(), Main2Activity.class));
            }
        }
        mblogin = (Button) findViewById(R.id.blogin);
        memail = (EditText) findViewById(R.id.email);
        mpassword = (EditText) findViewById(R.id.password);
        msignup = (Button) findViewById(R.id.bsignup);
        msignup.setOnClickListener(this);
        mblogin.setOnClickListener(this);

        mprogressdialog = new ProgressDialog(this);

        //login

    }

    @Override
    protected void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListner);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if(mAuthListner != null){
            mAuth.removeAuthStateListener(mAuthListner);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
      //  Toast.makeText(Login.this,"Login1",Toast.LENGTH_LONG).show();


        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
         //   Toast.makeText(Login.this,"Login1 in",Toast.LENGTH_LONG).show();
            if (result.isSuccess()) {
             //   Toast.makeText(Login.this,"Login2",Toast.LENGTH_LONG).show();
                GoogleSignInAccount account = result.getSignInAccount();
                firebaseAuthWithGoogle(account);
            } else {
                Log.e("Google sign in error:",result.getStatus().toString());
                //   Toast.makeText(MainActivity.this,"Login2 else",Toast.LENGTH_LONG).show();
            }
        }

    }
    private void firebaseAuthWithGoogle(GoogleSignInAccount acct){
   //     Toast.makeText(Login.this,"Login3",Toast.LENGTH_LONG).show();
        AuthCredential credential = GoogleAuthProvider.getCredential(acct.getIdToken(),null);
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        String deviceToken = FirebaseInstanceId.getInstance().getToken();
                        FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("device_token").setValue(deviceToken).addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {

                            }
                        });
                        // startActivity(new Intent(getApplicationContext(),chat.class));
                    }
                });
    }

    private void signIn(){


        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleSignInClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);


    }
    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
    //login
    private void userLogin() {
        String email = memail.getText().toString().trim();
        String password = mpassword.getText().toString().trim();
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this, "PLEASE!Enter the Email",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(this, "PLEASE!Enter the Password",Toast.LENGTH_SHORT).show();
            return;
        }
        mprogressdialog.setMessage("Progressing...");
        mprogressdialog.show();
        firebaseAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {


                if(task.isSuccessful()){
                    checkIfEmailVerified();
                    String deviceToken = FirebaseInstanceId.getInstance().getToken();
                    mprogressdialog.dismiss();
                    FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("device_token").setValue(deviceToken).addOnSuccessListener(new OnSuccessListener<Void>() {

                        @Override
                        public void onSuccess(Void aVoid) {

                            checklogin();
                        }
                    });


                }
                else
                {
                    mprogressdialog.dismiss();
                    Toast.makeText(Login.this, "ERROR! Maybe you need to SIGNUP.",Toast.LENGTH_LONG).show();
                }
            }
        });
    }
    private void checkIfEmailVerified()
    {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        if (user.isEmailVerified())
        {
            //Toast.makeText(MainActivity.this, "2", Toast.LENGTH_SHORT).show();
            // user is verified, so you can finish this activity or send user to activity which you want.
            startActivity(new Intent(getApplicationContext(),Main2Activity.class));
            finish();
            Toast.makeText(Login.this, "Successfully logged in", Toast.LENGTH_SHORT).show();
        }
        else
        {
            // Toast.makeText(MainActivity.this, "3", Toast.LENGTH_SHORT).show();
            Toast.makeText(Login.this, "Email is not Verified Yet", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();
            // email is not verified, so just prompt the message to the user and restart this activity.
            // NOTE: don't forget to log out the user.
            //FirebaseAuth.getInstance().signOut();
            //restart this activity

        }
    }
    private void checklogin() {
        final String user_id =firebaseAuth.getCurrentUser().getUid();
        mdatabaseUsers.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if(dataSnapshot.hasChild(user_id)){
                    finish();
                    //   startActivity(new Intent(getApplicationContext(),chatRecycler.class));
                }

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }

    //login
    @Override
    public void onClick(View view) {
        if(view == signinbtn){
            signIn();
        }
        if(view == mblogin){
            userLogin();
        }
        if(view== msignup){
            finish();
            startActivity(new Intent(getApplicationContext(),signup.class));
        }
    }

    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }
}