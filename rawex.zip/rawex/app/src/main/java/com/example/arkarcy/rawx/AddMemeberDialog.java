package com.example.arkarcy.rawx;

import android.app.Dialog;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDialogFragment;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class AddMemeberDialog  extends AppCompatDialogFragment {

    Button add1;
    AlertDialog dialog;
    EditText editText;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    //String SID,Title,Story;

    addMember getValue = new addMember();
    final String SID = getValue.SID;
    final String Title = addMember.Title;
    final String Story = addMember.Story;


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();

        android.view.View view = inflater.inflate(R.layout.addmemberdialog,null);

        builder.setView(view);

        String email = mAuth.getEmail();
        email = email.replaceAll("[^a-zA-Z0-9]", "");
        //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
        final String finalEmail = email;

        Toast.makeText(getActivity(), SID+"\n"+Title+"\n"+Story, Toast.LENGTH_SHORT).show();

        editText = view.findViewById(R.id.addMember);
        /*builder.setTitle("Select type of story");
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setPositiveButton("Hope in!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (solo.isChecked()) {
                    startActivity(new Intent(getActivity(), story_solo.class));
                }

                if (grp.isChecked()) {
                    startActivity(new Intent(getActivity(), story_group.class));
                }
            }
        });*/
        add1 = view.findViewById(R.id.add);

        add1.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                String newMember = editText.getText().toString().trim();
                newMember = newMember.replaceAll("[^a-zA-Z0-9]", "");
                String lowerCase = newMember.toLowerCase();
                //ref.child(finalEmail).child(String.valueOf(SID)).child("SID").setValue(String.valueOf(SID1));
                ref.child(lowerCase).child("SharedWithMe").child(String.valueOf(SID));
                ref.child(lowerCase).child("SharedWithMe").child(String.valueOf(SID)).child("SID").setValue(String.valueOf(SID));
                ref.child(lowerCase).child("SharedWithMe").child(String.valueOf(SID)).child("Title").setValue(String.valueOf(Title));
                ref.child(lowerCase).child("SharedWithMe").child(String.valueOf(SID)).child("Story").setValue(String.valueOf(Story));
                editText.setText("");
                //startActivity(new Intent(getActivity(),story_solo.class));
            }
        });


        return builder.create();
    }
}
