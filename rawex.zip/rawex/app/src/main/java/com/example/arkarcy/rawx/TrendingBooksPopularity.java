package com.example.arkarcy.rawx;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static com.firebase.ui.auth.AuthUI.getApplicationContext;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link TrendingBooksPopularity.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link TrendingBooksPopularity#newInstance} factory method to
 * create an instance of this fragment.
 */
public class TrendingBooksPopularity extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    public int keyOfBooks[] = new int[100];
    public ArrayList<Integer> keyOfBook = new ArrayList<Integer>();
    private String l0 = "",l1="",l2="";

    private RecyclerView mrec;
    private Query mQuery;
    private String genres;
    private FirebaseDatabase mDatabase=FirebaseDatabase.getInstance();
    private DatabaseReference mRef = mDatabase.getReference();

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private OnFragmentInteractionListener mListener;

    public TrendingBooksPopularity() {
        // Required empty public constructor
    }
    // TODO: Rename and change types and number of parameters
    public static TrendingBooksPopularity newInstance(String param1 , String param2) {
        TrendingBooksPopularity fragment = new TrendingBooksPopularity();


        Bundle args = new Bundle();
        args.putString(ARG_PARAM1 , param1);
        args.putString(ARG_PARAM2 , param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mRef = FirebaseDatabase.getInstance().getReference().child("popularity").child("popularity");
        mRef.keepSynced(true);


        mQuery = mRef.orderByKey();
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
        l0="[";
        l1="[";
        l2="[";
        mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                int i =0;
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()){
                        if(i%1==0){
                        PopularityBasedBooks book = snapshot.getValue(PopularityBasedBooks.class);
                        if(i>177 && i<183){
                           // Log.e("Boo"+i,book.getISBN() +" "+book.getBookVoteCount()+" "+book.getBookRating() );
                          //  Log.e("isbn", String.valueOf((long)(8.845902e+17)));
                        }
                            Pattern p = Pattern.compile("\\d+");
                            Matcher m = p.matcher(book.getISBN());
                            String Bisbn= book.getISBN().replaceAll("X","");
                            while(m.find()) {
                                Bisbn = Bisbn+m.group();
                            }

                        try {
                            Long isbn = Long.parseLong(Bisbn);

                           // if(isbn == (long)(8.845902e+17))
                             //   Log.e("isbn",Bisbn );
                             //  l0 = l0 + isbn + ",";
                            //Log.e("key",snapshot.getKey());
                            l0 = l0 + snapshot.getKey()+",";
                            l1 = l1 + book.getBookRating() + ",";
                            l2 = l2 + book.getBookVoteCount() + ",";
                        }catch(Exception e){

                        }
                        }
                        i++;
                       // Log.e("BookName","done1");
                    }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        mRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                l0=l0+"0]";l1=l1+"0]";l2=l2+"0]";
               // Log.e("BookName","done2");

                if (android.os.Build.VERSION.SDK_INT > 9)
                {
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    //l1 = "[5,5,3.38,2,0]";l2 = "[1,1,19,7,0]";l0 = "[3125785,1569870,671898,36654,0]";
                  //  l1 = "[5.0,4.99999999999999999,5,3,1,2,0]";l2 = "[96,60,41,10,10,65,0]";l0 = "[1232352,452356,752389,332545,523256,8275,0]";
                    l0 = l0.replaceAll("X","");
                    Server server = new Server();
                    server.script = "import pandas as pd;l1 = "+l1+";l2 = "+l2+";l0 = "+l0+";lr = [l0,l1,l2];md = pd.DataFrame(lr);md = md.transpose();md.columns = ['User-ID','Book-Rating','Book-Vote-Count'];metadata=md;C=metadata['Book-Rating'].mean();m=metadata['Book-Vote-Count'].quantile(0.95);q_books=metadata.copy().loc[metadata['Book-Vote-Count'] >= m];q_books.shape;exec('def weighted_rating(x,m=m,C=C):    v=x[2];    R=x[0];    return (v/(v+m)*R)+(m/(m+v)*C)');q_books['q_ratings']=q_books.apply(weighted_rating,axis=1);q_books=q_books.sort_values('q_ratings',ascending=False);q_books[['User-ID','Book-Vote-Count','Book-Rating','q_ratings']].head(5);print(q_books)";
                    //Log.e("Server", server.script);
                    Log.e("Server", String.valueOf(server.script.length()));
                    Log.e("l0", String.valueOf(l0.length()));
                    Log.e("l2", String.valueOf(l2.length()));

                    String a1[] = server.fetch().split("\"");
                    String a[] = a1[3].split("\\\\n");


                    for (int k = 0 ;k<a.length;k++){
                        Log.e("a[]"+k, a[k]);
                        if(k!=0){
                            String b[] = a[k].split(" ");
                           // Log.e("b[]"+3,b[3]);
                        ///    Log.e("b[]"+4,String.valueOf(Integer.parseInt(b[4])));

                            for(int j=0;j<b.length;j++){

                            }
                            if(b[3].length()>0)
                                keyOfBook.add((int)Float.parseFloat(b[3]));
                            else if (b[4].length()>0)
                                keyOfBook.add((int)Float.parseFloat(b[4]));
                            else if  (b[5].length()>0)
                                keyOfBook.add((int)Float.parseFloat(b[5]));
                            else if  (b[6].length()>0)
                                keyOfBook.add((int)Float.parseFloat(b[6]));
                            else if  (b[7].length()>0)
                                keyOfBook.add((int)Float.parseFloat(b[7]));
                            else if  (b[8].length()>0)
                                keyOfBook.add((int)Float.parseFloat(b[8]));
                          // Log.e("KEY", String.valueOf(keyOfBooks[k-1]));
                            Log.e("Key", String.valueOf(keyOfBook.size()));
                            for (int h = 0; h< keyOfBook.size();h++){
                                //Log.e("Key", String.valueOf(keyOfBook.get(h)));
                            }
                        }
                       // Log.e("a1[]"+k, a[k]);
                    }
                   // Toast.makeText(this , server.fetch() , Toast.LENGTH_SHORT).show();
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public View onCreateView(LayoutInflater inflater , ViewGroup container ,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        final View mView = inflater.inflate(R.layout.fragment_trending_books_popularity , container , false);

        mrec= (RecyclerView)mView.findViewById(R.id.rectrend);
     //   mRef = FirebaseDatabase.getInstance().getReference().child("Books");


        class BlogViewHolder extends RecyclerView.ViewHolder {
            View mView;
            public BlogViewHolder(@NonNull View itemView) {
                super(itemView);
                mView = itemView;
            }

            public void setBookname(String bookname) {
                TextView mcname = (TextView) mView.findViewById(R.id.DbookName);
                mcname.setText(bookname);
            }

            public void setImage(String image) throws IOException {
                ImageView mDCoverImage = mView.findViewById(R.id.DCoverImage);
                Log.e("CoverImage :",image);
                try {
                    image = "https://s.gr-assets.com/assets/nophoto/book/111x148-bcc042a9c91a29c1d680899eff700a03.png";
                        Picasso.get().load(image).into(mDCoverImage);
                }catch(Exception e)
                {
                    Log.e("CoverImage :",image);
                }
                //mDCoverImage.setImageBitmap(bmp);
            }


            public void setBookAuthor(String bookAuthor) {
                TextView mDbookAuthor = (TextView)mView.findViewById(R.id.DbookAuthor);
                mDbookAuthor.setText(bookAuthor);
                //   this.bookAuthor = bookAuthor;
            }

            public void setGenres(String genres1 , String genres2 , String genres3) {
                TextView mDGenres = (TextView)mView.findViewById(R.id.DGenres);
                TextView mDGenresT = (TextView)mView.findViewById(R.id.DGenresT);
                mDGenres.setText(genres1);
                mDGenresT.setText("");
//                this.genres = genres;
            }

            public void setRating(String rating) {
                TextView mDbookRating = (TextView)mView.findViewById(R.id.DbookRating);
                mDbookRating.setText("Rating : "+rating);
            }

            public void setSizeZero() {
                RelativeLayout rlayout = mView.findViewById(R.id.book_card);
                rlayout.getLayoutParams().height = 0;

            }
        }
        FirebaseRecyclerOptions<PopularityBasedBooks> options =
                new FirebaseRecyclerOptions.Builder<PopularityBasedBooks>()
                        .setQuery(mQuery, PopularityBasedBooks.class)
                        .setLifecycleOwner(this)
                        .build();
        FirebaseRecyclerAdapter<PopularityBasedBooks,BlogViewHolder> firebaseadapter = new FirebaseRecyclerAdapter<PopularityBasedBooks, BlogViewHolder>(options) {


            @Override
            protected void onBindViewHolder(@NonNull BlogViewHolder holder, int position, @NonNull final PopularityBasedBooks model) {

                    if(keyOfBook.contains(position)){
                        holder.setBookname(model.getBookName());
                    try {
                        holder.setImage("");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                        holder.setGenres("","","");
                        holder.setBookAuthor("");
                        holder.setRating(model.getBookRating());
                        holder.mView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {


                            }
                        });
                    }
                    else{
                        holder.setSizeZero();
                    }

                    // Toast.makeText(getApplicationContext(),model.getName(),Toast.LENGTH_LONG).show();

                }


            @SuppressLint("RestrictedApi")
            @NonNull
            @Override
            public BlogViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
                View view;
                view = LayoutInflater.from(getApplicationContext()).inflate(R.layout.book_card, viewGroup , false);

                BlogViewHolder viewHolder = new BlogViewHolder(view);
                return viewHolder;
            }
        };
        mrec.setLayoutManager(new LinearLayoutManager(getActivity()));
        mrec.setAdapter(firebaseadapter);
        return mView;
    }

    // TODO: Rename method, update argument and hook method into UI event
    public void onButtonPressed(Uri uri) {
        if (mListener != null) {
            mListener.onFragmentInteraction(uri);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        if (context instanceof OnFragmentInteractionListener) {
            mListener = (OnFragmentInteractionListener) context;
        } else {
            throw new RuntimeException(context.toString()
                    + " must implement OnFragmentInteractionListener");
        }
    }

    @Override
    public void onDetach() {
        super.onDetach();
        mListener = null;
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
