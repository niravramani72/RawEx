package com.example.arkarcy.rawx;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;

public class addMember extends AppCompatActivity {

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser;
    private DatabaseReference mUserDatabase;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();

    LinearLayout l1,l2,l3,l4;
    EditText e5,e2,e3,e4;
    Button done;
    public static String SID,Title,Story;
    String t1,t2,t3,t4,t5;
    public String m5,m2,m3,m4,ts2,ts3,ts4,ts5;
    String fetch2="", fetch3="", fetch4="", fetch5="";
    private ImageView i1,i2,i3,i4;
    private int ff=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_member);

        java.util.Date date = new java.util.Date();
        Timestamp timestamp1 = new Timestamp(date.getTime());
        //timestamp1 = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss").format(new Date());

        // create a calendar and assign it the same time
        final Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(timestamp1.getTime());

        // add a bunch of seconds to the calendar
        cal.add(Calendar.SECOND, 172799);

        // create a  second time stamp
        final Timestamp timestamp2 = new Timestamp(cal.getTime().getTime());
        final Timestamp timestamp3 = new Timestamp(cal.getTime().getTime());
        final Timestamp timestamp4 = new Timestamp(cal.getTime().getTime());
        final Timestamp timestamp5 = new Timestamp(cal.getTime().getTime());

        SID = getIntent().getStringExtra("SID");
        Title = getIntent().getStringExtra("Title");
        Story = getIntent().getStringExtra("Story");

        //AddMemeberDialog.SID1 = SID;
        //AddMemeberDialog.SID1 = SID;
        //AddMemeberDialog.SID1 = SID;

        //Toast.makeText(this, SID+"\n"+Title+"\n"+Story, Toast.LENGTH_SHORT).show();

        getSupportActionBar().setTitle("Add Member");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        Intent intent = getIntent();
        final modelSavedStoryGroup mod = (modelSavedStoryGroup) intent.getSerializableExtra("pass");

        e2 = findViewById(R.id.Member1);
        e3 = findViewById(R.id.Member2);
        e4 = findViewById(R.id.Member3);
        e5 = findViewById(R.id.Member4);
        done = findViewById(R.id.done);

        i1 = findViewById(R.id.image1);
        i2 = findViewById(R.id.image2);
        i3 = findViewById(R.id.image3);
        i4 = findViewById(R.id.image4);

        l1 = findViewById(R.id.ll1);
        l2 = findViewById(R.id.ll2);
        l3 = findViewById(R.id.ll3);
        l4 = findViewById(R.id.ll4);

//        l2.setVisibility(View.GONE);
//        l3.setVisibility(View.GONE);
//        l4.setVisibility(View.GONE);


        i1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Toast.makeText(addMember.this, mod.getContent2().toString(), Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(),SoloStoryDetail.class);
                intent.putExtra("pass", (Serializable) mod);
                intent.putExtra("act","C");
                intent.putExtra("member","two");
                startActivity(intent);
            }
        });

        i2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SoloStoryDetail.class);
                intent.putExtra("pass", (Serializable) mod);
                intent.putExtra("act","C");
                intent.putExtra("member","three");
                startActivity(intent);
            }
        });

        i3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SoloStoryDetail.class);
                intent.putExtra("pass", (Serializable) mod);
                intent.putExtra("act","C");
                intent.putExtra("member","four");
                startActivity(intent);
            }
        });

        i4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SoloStoryDetail.class);
                intent.putExtra("pass", (Serializable) mod);
                intent.putExtra("act","C");
                intent.putExtra("member","five");
                startActivity(intent);
            }
        });

        String email = mAuth.getEmail();
        email = email.replaceAll("[^a-zA-Z0-9]", "");
        String lowerCase = email.toLowerCase();
        //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
        final String finalEmail = lowerCase;



       done.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {

               t1 = finalEmail;
               t2 = e2.getText().toString().trim();
               t2 = t2.replaceAll("[^a-zA-Z0-9]", "");
               t2 = t2.toLowerCase();
               t3 = e3.getText().toString().trim();
               t3 = t3.replaceAll("[^a-zA-Z0-9]", "");
               t3 = t3.toLowerCase();
               t4 = e4.getText().toString().trim();
               t4 = t4.replaceAll("[^a-zA-Z0-9]", "");
               t4 = t4.toLowerCase();
               t5 = e5.getText().toString().trim();
               t5 = t5.replaceAll("[^a-zA-Z0-9]", "");
               t5 = t5.toLowerCase();

               //Toast.makeText(addMember.this, t1+"\n"+t2+"\n"+t3+"\n"+t4+"\n"+t5, Toast.LENGTH_SHORT).show();

               ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member1").setValue(String.valueOf(finalEmail));
               ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member2").setValue(e2.getText().toString().trim().toLowerCase());
               ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member3").setValue(e3.getText().toString().trim().toLowerCase());
               ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member4").setValue(e4.getText().toString().trim().toLowerCase());
               ref.child("StoryGroupPending").child(String.valueOf(SID)).child("Member5").setValue(e5.getText().toString().trim().toLowerCase());

               /*if (ff==0){
                   final Timestamp timestamp2 = new Timestamp(cal.getTime().getTime());
                   ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp2.toString());
                   ff=1;
               }
               if (m3!=null){
                   final Timestamp timestamp3 = new Timestamp(cal.getTime().getTime());
                   ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp3.toString());
               }*/


               if(m2 != null && m3!= null && m4 != null && m5!= null) {

                   fetch2 = m2;
                   fetch2 = fetch2.replaceAll("[^a-zA-Z0-9]", "");
                   fetch2 = fetch2.toLowerCase();
                   fetch3 = m3;
                   fetch3 = fetch3.replaceAll("[^a-zA-Z0-9]", "");
                   fetch3 = fetch3.toLowerCase();
                   fetch4 = m4;
                   fetch4 = fetch4.replaceAll("[^a-zA-Z0-9]", "");
                   fetch4 = fetch4.toLowerCase();
                   fetch5 = m5;
                   fetch5 = fetch5.replaceAll("[^a-zA-Z0-9]", "");
                   fetch5 = fetch5.toLowerCase();
               }

               /*if (!fetch2.equals(""))
                   ref.child("StoryUser").child(fetch2).child("SharedWithMe").child(SID).removeValue();
               if (!fetch3.equals(""))
                   ref.child("StoryUser").child(fetch3).child("SharedWithMe").child(SID).removeValue();
               if (!fetch4.equals(""))
                   ref.child("StoryUser").child(fetch4).child("SharedWithMe").child(SID).removeValue();
               if (!fetch5.equals(""))
                   ref.child("StoryUser").child(fetch5).child("SharedWithMe").child(SID).removeValue();*/

               if (!t2.equals("")){
                   /*ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child(SID).setValue("True");
                    ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 2");*/
                   //ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp2.toString());

                   try{
                       mUserDatabase.child("Story").child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("TimeStamp").addListenerForSingleValueEvent(new ValueEventListener() {
                           @Override
                           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                               ts2 = (String)dataSnapshot.getValue();
//                               Log.e("ffound",ts2);
                               if  (ts2 == null){
                                   //Toast.makeText(addMember.this, fetch2.toString(), Toast.LENGTH_SHORT).show();
                                   /*if (!fetch2.equals(t2))
                                       ref.child("StoryUser").child(fetch2).child("SharedWithMe").child(SID).removeValue();*/
                                   ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                   ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 2");
                                   ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp2.toString());
                               }
                               else{
                                   Log.e("found",ts2);
                                   /*if (!fetch2.equals(t2))
                                        ref.child("StoryUser").child(fetch2).child("SharedWithMe").child(SID).removeValue();*/
                                   ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                   ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 2");
                                   ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("TimeStamp").setValue(ts2.toString());
                               }
                           }

                           @Override
                           public void onCancelled(@NonNull DatabaseError databaseError) {

                           }
                       });
                   }
                   catch (Exception e){

                   }
                    finish();
               }
               if (!t3.equals("")){
                   /*ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child(SID).setValue("True");
                   ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 3");
                   ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp3.toString());*/

                   try{
                       mUserDatabase.child("Story").child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("TimeStamp").addListenerForSingleValueEvent(new ValueEventListener() {
                           @Override
                           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                               ts3 = (String)dataSnapshot.getValue();
                               //Log.e("found",ts3);
                               if (ts3 == null){
                                   /*if (!fetch3.equals(t3))
                                        ref.child("StoryUser").child(fetch3).child("SharedWithMe").child(SID).removeValue();*/
                                   ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                   ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 3");
                                   ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp3.toString());
                               }
                               else{
                                   Log.e("found",ts3);
                                       /*if (!fetch3.equals(t3))
                                           ref.child("StoryUser").child(fetch3).child("SharedWithMe").child(SID).removeValue();*/
                                       ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                       ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 3");
                                       ref.child("StoryUser").child(t3).child("SharedWithMe").child(SID).child("TimeStamp").setValue(ts3.toString());
                               }
                           }

                           @Override
                           public void onCancelled(@NonNull DatabaseError databaseError) {

                           }
                       });
                   }
                   catch (Exception e){

                   }
                   finish();
               }
               if (!t4.equals("")){
                   /*ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child(SID).setValue("True");
                   ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 4");*/

                   try{
                       mUserDatabase.child("Story").child("StoryUser").child(t4).child("SharedWithMe").child(SID).child("TimeStamp").addListenerForSingleValueEvent(new ValueEventListener() {
                           @Override
                           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                               ts4 = (String)dataSnapshot.getValue();
                               //Log.e("found",ts3);
                               if (ts4 == null){
                                   if (!fetch3.equals(t4))
                                       ref.child("StoryUser").child(fetch4).child("SharedWithMe").child(SID).removeValue();
                                   ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                   ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 3");
                                   ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp3.toString());
                               }
                               else{
                                   if (!fetch3.equals(t4))
                                       ref.child("StoryUser").child(fetch4).child("SharedWithMe").child(SID).removeValue();
                                   ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                   ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 3");
                                   ref.child("StoryUser").child(t4).child("SharedWithMe").child(SID).child("TimeStamp").setValue(ts3.toString());
                               }
                           }

                           @Override
                           public void onCancelled(@NonNull DatabaseError databaseError) {

                           }
                       });
                   }
                   catch (Exception e){

                   }
                   finish();
               }
               if (!t5.equals("")){
                   /*ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child(SID).setValue("True");
                   ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 5");*/

                   try{
                       mUserDatabase.child("Story").child("StoryUser").child(t5).child("SharedWithMe").child(SID).child("TimeStamp").addListenerForSingleValueEvent(new ValueEventListener() {
                           @Override
                           public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                               ts3 = (String)dataSnapshot.getValue();
                               //Log.e("found",ts3);
                               if (ts5 == null){
                                   if (!fetch3.equals(t5))
                                       ref.child("StoryUser").child(fetch3).child("SharedWithMe").child(SID).removeValue();
                                   ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                   ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 3");
                                   ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp3.toString());
                               }
                               else{
                                   /*if (!fetch3.equals(t5))
                                       ref.child("StoryUser").child(fetch3).child("SharedWithMe").child(SID).removeValue();*/
                                   ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child(SID).setValue("True");
                                   ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child("MemberNumber").setValue("Member 3");
                                   ref.child("StoryUser").child(t5).child("SharedWithMe").child(SID).child("TimeStamp").setValue(ts3.toString());
                               }
                           }

                           @Override
                           public void onCancelled(@NonNull DatabaseError databaseError) {

                           }
                       });
                   }
                   catch (Exception e){

                   }
                   finish();
               }

               /*ref.child("StoryListingGroup").child(String.valueOf(SID)).child("UID").setValue(mAuth.getEmail());
               ref.child("StoryListingGroup").child(String.valueOf(SID)).child("PartNo").setValue("1");
               ref.child("StoryListingGroup").child(String.valueOf(SID)).child("Title").setValue(e1.getText().toString().trim());
               ref.child("StoryListingGroup").child(String.valueOf(SID)).child("Content").setValue(e2.getText().toString().trim());
               ref.child("StoryListingGroup").child(String.valueOf(SID)).child("Type").setValue("Solo");*/

               finish();
           }
       });

        try{
        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        String current_uid = mCurrentUser.getUid();
        mUserDatabase = FirebaseDatabase.getInstance().getReference();
        //mUserDatabase.keepSynced(true);

        mUserDatabase.child("Story").child("StoryGroupPending").child(String.valueOf(SID)).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                m2 = (String)dataSnapshot.child("Member2").getValue();
                m3 = (String)dataSnapshot.child("Member3").getValue();
                m4 = (String)dataSnapshot.child("Member4").getValue();
                m5 = (String)dataSnapshot.child("Member5").getValue();

                if(m2 != null && m3!= null && m4 != null && m5!= null){
                    e2.setText(String.valueOf(m2));
                    e3.setText(String.valueOf(m3));
                    e4.setText(String.valueOf(m4));
                    e5.setText(String.valueOf(m5));
                    //ref.child("StoryUser").child(t2).child("SharedWithMe").child(SID).child("TimeStamp").setValue(timestamp2.toString());
                    if(m3.length() == 0){
                        //l3.setVisibility(View.GONE);
                        l3.setVisibility(View.GONE);

                    }
                    if(m4.length() == 0){
                        //l3.setVisibility(View.GONE);
                        l4.setVisibility(View.GONE);
                    }

                }
                else{

                    e2.setText("");
                    e3.setText("");
                    e4.setText("");
                    e5.setText("");
                        l2.setVisibility(View.GONE);
                        l3.setVisibility(View.GONE);
                        l4.setVisibility(View.GONE);

                }


                /*SID1 = Integer.parseInt(dataSnapshot.child("GlobalStoryID").getValue().toString());
                t1.setText(String.valueOf(SID1));
                SID2 = SID1 + 1;
                mUserDatabase.child("GlobalStoryID").setValue(SID2);*/
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
            if(m2 != null || m3!= null || m4 != null || m5!= null) {

                fetch2 = m2;
                fetch2 = fetch2.replaceAll("[^a-zA-Z0-9]", "");
                fetch2 = fetch2.toLowerCase();
                fetch3 = m3;
                fetch3 = fetch3.replaceAll("[^a-zA-Z0-9]", "");
                fetch3 = fetch3.toLowerCase();
                fetch4 = m4;
                fetch4 = fetch4.replaceAll("[^a-zA-Z0-9]", "");
                fetch4 = fetch4.toLowerCase();
                fetch5 = m5;
                fetch5 = fetch5.replaceAll("[^a-zA-Z0-9]", "");
                fetch5 = fetch5.toLowerCase();
            }

            //Toast.makeText(this, m2.toString(), Toast.LENGTH_SHORT).show();


           /* mUserDatabase.child("Story").child("StoryUser").child(t3).child("SharedWithMe").child(SID).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    ts3 = (String)dataSnapshot.child("TimeStamp").getValue();
                    Log.e("found",ts3);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });*/

            /*if (m2.length()==0){
                e2.setVisibility(View.VISIBLE);
                e3.setVisibility(View.GONE);
                e4.setVisibility(View.GONE);
                e5.setVisibility(View.GONE);
            }

            if (m2.length()!=0 && m3.length()==0){
                e2.setVisibility(View.VISIBLE);
                e3.setVisibility(View.VISIBLE);
                e4.setVisibility(View.GONE);
                e5.setVisibility(View.GONE);
            }
            if (m2.length()!=0 && m3.length()!=0 && m4.length()==0){
                e2.setVisibility(View.VISIBLE);
                e3.setVisibility(View.VISIBLE);
                e4.setVisibility(View.VISIBLE);
                e5.setVisibility(View.GONE);
            }*/

        }
        catch (Exception e){
            Log.d("Exception",String.valueOf(e));
            Log.d("Exception Caught","Found");
        }

    }

    private void openDialog() {
        AddMemeberDialog dialog = new AddMemeberDialog();
        dialog.show(getSupportFragmentManager(),"Example Dialog");
    }

    public String SID(String a1) {
        //Toast.makeText(this, String.valueOf(a1), Toast.LENGTH_SHORT).show();
        a1 = SID;
        return a1;
    }
    public String TITLE() {
        return Title;
    }
    public String STORY() {
        return Story;
    }

}
