package com.example.arkarcy.rawx;

import com.google.firebase.database.Exclude;

import java.io.Serializable;

public class modelContent implements Serializable {
    private String BookImage,BookName,BookRating;

    public modelContent() {
    }

    public modelContent(String bookImage , String bookName , String bookRating) {
        BookImage = bookImage;
        BookName = bookName;
        BookRating = bookRating;
    }

    public String getBookImage() {
        return BookImage;
    }
    @Exclude
    public void setBookImage(String bookImage) {
        BookImage = bookImage;
    }

    public String getBookName() {
        return BookName;
    }
    @Exclude
    public void setBookName(String bookName) {
        BookName = bookName;
    }

    public String getBookRating() {
        return BookRating;
    }
    @Exclude
    public void setBookRating(String bookRating) {
        BookRating = bookRating;
    }
}
