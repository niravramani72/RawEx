package com.example.arkarcy.rawx;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatDialogFragment;
import android.view.LayoutInflater;
import android.widget.Button;


public class alertboxstory extends AppCompatDialogFragment {

    Button bsolo,bgroup;
    AlertDialog dialog;

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = getActivity().getLayoutInflater();


        android.view.View view = inflater.inflate(R.layout.alertboxstory,null);
        builder.setView(view);
        /*builder.setTitle("Select type of story");
        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.setPositiveButton("Hope in!", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if (solo.isChecked()) {
                    startActivity(new Intent(getActivity(), story_solo.class));
                }

                if (grp.isChecked()) {
                    startActivity(new Intent(getActivity(), story_group.class));
                }
            }
        });*/
        bsolo = view.findViewById(R.id.soloStory);
        bgroup = view.findViewById(R.id.groupStory);

        bsolo.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                Intent i = new Intent(getActivity(),story_solo.class);
                i.putExtra("act","B");
                startActivity(i);
                //startActivity(new Intent(getActivity(),story_solo.class));
            }
        });

        bgroup.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                Intent i = new Intent(getActivity(),story_group.class);
                i.putExtra("act","B");
                startActivity(i);
            }
        });


        return builder.create();
    }
}
