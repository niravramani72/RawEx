package com.example.arkarcy.rawx;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

public class signup extends AppCompatActivity implements View.OnClickListener, GoogleApiClient.OnConnectionFailedListener {
    private Button mbregister;
    private EditText memail;
    private EditText mname;
    private EditText mpassword,mcpassword;
    private TextView mloginlink;
    private ProgressDialog mprogressdialog;
    private FirebaseAuth firebaseAuth;
    private DatabaseReference mDatabase,mDatabaseUsers,mnewdatabace,mnewdatabace1;
    private static int userno=10000;
    private static int count=0;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference ref = database.getReference("Users");
    private FirebaseUser mAuth2 = FirebaseAuth.getInstance().getCurrentUser();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        mDatabaseUsers= FirebaseDatabase.getInstance().getReference().child("users");
        mDatabaseUsers.keepSynced(true);
        firebaseAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference().child("usersdetail");
        mnewdatabace = FirebaseDatabase.getInstance().getReference().child("newusers");
        mnewdatabace1 = FirebaseDatabase.getInstance().getReference().child("recdUSERS");

        //
       /* if(firebaseAuth.getCurrentUser() != null)
        {
            finish();
            startActivity(new Intent(getApplicationContext(),chatRecycler.class));
            //profileactivity
        }*/

        //checklogin();
        mbregister = (Button) findViewById(R.id.bregister);
        memail = (EditText) findViewById(R.id.email);
        mname=(EditText) findViewById(R.id.name);
        mpassword = (EditText) findViewById(R.id.password);
        mcpassword = (EditText) findViewById(R.id.cpassword);
        mloginlink =(TextView) findViewById(R.id.loginlink);
        mbregister.setOnClickListener(this);
        mloginlink.setOnClickListener(this);
        mprogressdialog = new ProgressDialog(this);

    }

    private void registerUser(){
        final String name = mname.getText().toString().trim();
        final String email = memail.getText().toString().trim();
        final String password = mpassword.getText().toString().trim();
        final String cpassword = mcpassword.getText().toString().trim();

        if(TextUtils.isEmpty(name)){
            Toast.makeText(this, "PLEASE!Enter the Name",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(email)){
            Toast.makeText(this, "PLEASE!Enter the Email",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(password)){
            Toast.makeText(this, "PLEASE!Enter the Password",Toast.LENGTH_SHORT).show();
            return;
        }
        if(TextUtils.isEmpty(cpassword)){
            Toast.makeText(this, "PLEASE!Enter the Confirm Password",Toast.LENGTH_SHORT).show();
            return;
        }
        if(password.length()<8){
            Toast.makeText(this, "Minimum length of password should be 8",Toast.LENGTH_SHORT).show();
            return;
        }
        if(!password.equals(cpassword)){
            Toast.makeText(this, "Password and confirm password don't match",Toast.LENGTH_SHORT).show();
            return;
        }


        mprogressdialog.setMessage("Progressing...");
        mprogressdialog.show();

        firebaseAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(this, new OnCompleteListener<AuthResult>()
        {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()) {
                    mprogressdialog.dismiss();
                    sendVerificationEmail();

                    /*String user_id =firebaseAuth.getCurrentUser().getUid();
                    mnewdatabace.child(user_id).child("username").setValue(name);
                    //mnewdatabace1.child(user_id).child("username").setValue(name);
                    DatabaseReference current_user_db = mDatabase.child(user_id);
                    current_user_db.child("name").setValue(name);

                    DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference().child("usersdetail");
                    mDatabase.child(name);
//                    current_user_db.child("userno").setValue(userno--);
                    current_user_db.child("password").setValue(password);
                    current_user_db.child("email").setValue(email);
                    mprogressdialog.dismiss();
                    FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("username").setValue(name);
                    String deviceToken = FirebaseInstanceId.getInstance().getToken();
                    FirebaseDatabase.getInstance().getReference().child("users").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("device_token").setValue(deviceToken).addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            Toast.makeText(signup.this, "Successfully Registered", Toast.LENGTH_SHORT).show();
                        }
                    });

                    if (firebaseAuth.getCurrentUser() != null)
                    {
                        finish();
                        startActivity(new Intent(getApplicationContext(),chatRecycler.class));
                    }*/

                }else{ mprogressdialog.dismiss();
                    Toast.makeText(signup.this, "Not Registered Due to Some ERROR",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
    private void sendVerificationEmail()
    {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

        user.sendEmailVerification()
                .addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if (task.isSuccessful()) {
                            // email sent
                            Toast.makeText(signup.this, "Verification Email is Sent.",Toast.LENGTH_SHORT).show();

                            ref.child(mAuth2.getUid()).child("UID").setValue(mAuth2.getUid());
                            ref.child(mAuth2.getUid()).child("Email").setValue(mAuth2.getEmail());
                            ref.child(mAuth2.getUid()).child("Name").setValue("one");
                            // after email is sent just logout the user and finish this activity
                            FirebaseAuth.getInstance().signOut();
                            startActivity(new Intent(signup.this, Login.class));
                            finish();
                        }
                        else
                        {
                            // email not sent, so display message and restart the activity or do whatever you wish to do

                            //restart this activity
                            overridePendingTransition(0, 0);
                            finish();
                            overridePendingTransition(0, 0);
                            startActivity(getIntent());

                        }
                    }
                });
    }
    private void checklogin() {
        final String user_id =firebaseAuth.getCurrentUser().getUid();

        mDatabaseUsers.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                for( DataSnapshot snap: dataSnapshot.getChildren()){
                    Log.e(snap.getKey(),snap.getChildrenCount() + "");

                }

                if(dataSnapshot.hasChild(user_id)){
                    finish();
                    startActivity(new Intent(getApplicationContext(),Main2Activity.class));
                }
                else{
                    finish();
                    startActivity(new Intent(getApplicationContext(),Main2Activity.class));
                    //Toast.makeText(login.this, "ERROR! Maybe you need to Register.",Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });

    }


    @Override
    public void onClick(View view) {
        if(view == mbregister){
            registerUser();
        }
        if(view == mloginlink){
            finish();
            startActivity(new Intent(this,Login.class));
        }
    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }
}
