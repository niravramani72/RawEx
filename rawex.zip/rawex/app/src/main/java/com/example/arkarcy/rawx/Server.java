package com.example.arkarcy.rawx;

import com.google.protobuf.ByteString;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class Server {
    public String script = "import pandas as pd;l1 = [5,4,5,3,1,2];l2 = [96,60,41,10,10,65];l0 = [123,456,789,345,256,743];lr = [l0,l1,l2];md = pd.DataFrame(lr);md = md.transpose();md.columns = ['User-ID','Book-Rating','Book-Vote-Count'];metadata=md;C=metadata['Book-Rating'].mean();m=metadata['Book-Vote-Count'].quantile(0.6);q_books=metadata.copy().loc[metadata['Book-Vote-Count'] >= m];q_books.shape;exec('def weighted_rating(x,m=m,C=C):    v=x[2];    R=x[0];    return (v/(v+m)*R)+(m/(m+v)*C)');q_books['q_ratings']=q_books.apply(weighted_rating,axis=1);q_books=q_books.sort_values('q_ratings',ascending=False);q_books[['User-ID','Book-Vote-Count','Book-Rating','q_ratings']].head(7);print(q_books)";
    public  String fetch() {
/*  Client ID
b73b1d8db8238efdc62e52a2e617acc4
Client Secret
833865839430f7b97b5d99ca702d76dbb7d6b94f5eb2714b773cfa9e9ba9e560
*/
        String clientId = "b73b1d8db8238efdc62e52a2e617acc4"; //Replace with your client ID
        String clientSecret = "833865839430f7b97b5d99ca702d76dbb7d6b94f5eb2714b773cfa9e9ba9e560"; //Replace with your client Secret
        //String script = "import pandas as pd\nl1 = [5,4,5,3,1,2]\nl2 = [96,60,41,10,10,65]\nl0 = [123,456,789,345,256,743]\nlr = [l0,l1,l2]\nmd = pd.DataFrame(lr)\nmd = md.transpose()\nmd.columns = [\"User-ID\",\"Book-Rating\",\"Book-Vote-Count\"]\nmetadata=md\nC=metadata['Book-Rating'].mean()\nm=metadata['Book-Vote-Count'].quantile(0.6)\nq_books=metadata.copy().loc[metadata['Book-Vote-Count'] >= m]\nq_books.shape\ndef weighted_rating(x,m=m,C=C):\n    v=x['Book-Vote-Count']\n    R=x['Book-Rating']\n    return (v/(v+m)*R)+(m/(m+v)*C)\nq_books['q_ratings']=q_books.apply(weighted_rating,axis=1)\nq_books=q_books.sort_values('q_ratings',ascending=False)\nq_books[['User-ID','Book-Vote-Count','Book-Rating','q_ratings']].head(7)\nprint(q_books)";

       // String script = "print(72)";
        //l0 userID //l1 book-raing //l2 book-vote-count
     //   String script = "import pandas as pd;l1 = [5,4,5,3,1,2];l2 = [96,60,41,10,10,65];l0 = [123,456,789,345,256,743];lr = [l0,l1,l2];md = pd.DataFrame(lr);md = md.transpose();md.columns = ['User-ID','Book-Rating','Book-Vote-Count'];metadata=md;C=metadata['Book-Rating'].mean();m=metadata['Book-Vote-Count'].quantile(0.6);q_books=metadata.copy().loc[metadata['Book-Vote-Count'] >= m];q_books.shape;exec('def weighted_rating(x,m=m,C=C):    v=x[2];    R=x[0];    return (v/(v+m)*R)+(m/(m+v)*C)');q_books['q_ratings']=q_books.apply(weighted_rating,axis=1);q_books=q_books.sort_values('q_ratings',ascending=False);q_books[['User-ID','Book-Vote-Count','Book-Rating','q_ratings']].head(7);print(q_books)";
        String language = "python3";
        String versionIndex = "2";

        try {
            URL url = new URL("https://api.jdoodle.com/v1/execute");
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoOutput(true);
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "application/json");

            String input = "{\"clientId\": \"" + clientId + "\",\"clientSecret\":\"" + clientSecret + "\",\"script\":\"" + script +
                    "\",\"language\":\"" + language + "\",\"versionIndex\":\"" + versionIndex + "\"} ";

            //System.out.println(input);

            OutputStream outputStream = connection.getOutputStream();
            outputStream.write(input.getBytes());
            outputStream.flush();

            if (connection.getResponseCode() != HttpURLConnection.HTTP_OK) {
                throw new RuntimeException("Please check your inputs : HTTP error code : "+ connection.getResponseCode());
            }

            BufferedReader bufferedReader;
            bufferedReader = new BufferedReader(new InputStreamReader(
                    (connection.getInputStream())));

            String output;
            System.out.println("Output from JDoodle .... \n");
            while ((output = bufferedReader.readLine()) != null) {
                System.out.println(output);
                return output;
            }

            connection.disconnect();

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Internet Is Not Available.";
    }
}


