package com.example.arkarcy.rawx;

import java.io.Serializable;

public class modelSavedStorySolo implements Serializable {
    private static final long serialVersionUID = 1L;
    private String SID, Title, Content, Name, Type;

    public modelSavedStorySolo() {
    }

    public modelSavedStorySolo(String SID, String title, String content, String name, String type) {
        this.SID = SID;
        Title = title;
        Content = content;
        Name = name;
        Type = type;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getSID() {
        return SID;
    }

    public void setSID(String SID) {
        this.SID = SID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getContent() {
        return Content;
    }

    public void setContent(String content) {
        Content = content;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }
}
