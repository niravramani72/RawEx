package com.example.arkarcy.rawx;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;

public class AcceptDeclineGroupStory extends AppCompatActivity {
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser;
    private DatabaseReference mUserDatabase;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    private TextView mStory,mTitle,mName,mUID,que;
    private Button yes,no;
    private String SID,email,email1,res="";
    private String ts;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_accept_decline_group_story);

        /*Intent i1 = getIntent();
        res = i1.getStringExtra("act");*/

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        mStory = findViewById(R.id.stText);
        mTitle = findViewById(R.id.stTitle);
        mName = findViewById(R.id.stName);
        mUID = findViewById(R.id.stUID);
        yes = findViewById(R.id.yes);
        no = findViewById(R.id.no);
        que = findViewById(R.id.text);

        Intent intent = getIntent();
        final modelSharedStory mod = (modelSharedStory) intent.getSerializableExtra("pass");
        getSupportActionBar().setTitle("-By " + mod.getName1());
//        Toast.makeText(this, mod.getTitle(), Toast.LENGTH_SHORT).show();
        mStory.setText(mod.getContent1()+ " " + mod.getContent2()+ " " + mod.getContent3()+ " " + mod.getContent4()+ " " + mod.getContent5());
        mTitle.setText(mod.getTitle());
        mName.setText(mod.getName1());
        mUID.setText(mod.getUID());
        SID = mod.getSID();

        email1 = mAuth.getEmail();
        email = mAuth.getEmail();
        email = email.replaceAll("[^a-zA-Z0-9]", "");
        email = email.toLowerCase();
        //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
        final String finalEmail = email;

        if (email1.equals(mod.getMember2())){
            que.setText("Do you want to contribute as Member 2");
        }

        if (email1.equals(mod.getMember3())){
            que.setText("Do you want to contribute as Member 3");
        }

        if (email1.equals(mod.getMember4())){
            que.setText("Do you want to contribute as Member 4");
        }

        if (email1.equals(mod.getMember5())){
            que.setText("Do you want to contribute as Last Member");
        }

        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
        String current_uid = mCurrentUser.getUid();
        mUserDatabase = FirebaseDatabase.getInstance().getReference();

        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child(SID).setValue("True");
                //ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("TimeStamp").setValue("Member2");
                //Toast.makeText(AcceptDeclineGroupStory.this, email, Toast.LENGTH_SHORT).show();
                if (email1.equals(mod.getMember2())){

                    try {
                       ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).child("TimeStamp").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                    Log.e("AcceptDe123 ---->>>",dataSnapshot.getValue().toString());
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("TimeStamp").setValue(dataSnapshot.getValue().toString());
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("MemberNumber").setValue("Member2");
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).removeValue();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                       }
                    catch (Exception e){
                        Log.e("foundexe1",e.toString());
                    }
                }

                if (email1.equals(mod.getMember3())){
                    try {
                        ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).child("TimeStamp").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Log.e("AcceptDe123 ---->>>",dataSnapshot.getValue().toString());
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("TimeStamp").setValue(dataSnapshot.getValue().toString());
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("MemberNumber").setValue("Member3");
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).removeValue();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                    catch (Exception e){
                        Log.e("foundexe2",e.toString());
                    }
                }

                if (email1.equals(mod.getMember4())){
                    try {
                        ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).child("TimeStamp").addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                Log.e("AcceptDe123 ---->>>",dataSnapshot.getValue().toString());
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("TimeStamp").setValue(dataSnapshot.getValue().toString());
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("MemberNumber").setValue("Member3");
                                ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).removeValue();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                    catch (Exception e){
                        Log.e("foundexe4",e.toString());
                    }
                }

                if (email1.equals(mod.getMember5())) {
                    try {
                       ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                ts = (String) dataSnapshot.child("TimeStamp").getValue();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                        ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("TimeStamp").setValue(ts.toString());
                        ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(SID).child("MemberNumber").setValue("Member5");
                        ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).removeValue();
                    }
                    catch (Exception e){
                        Log.e("foundexe5",e.toString());
                    }
                }

                //ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).removeValue();

                Intent intent = new Intent(getApplicationContext(),story_group_member.class);
                intent.putExtra("pass", (Serializable) mod);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
                finish();
            }

        });

        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
                ref.child("StoryUser").child(finalEmail).child("SharedWithMe").child(SID).removeValue();

                if (email1.equals(mod.getMember2())){
                    ref.child("StoryGroupPending").child(SID).child("Member2").setValue("");
                }

                if (email1.equals(mod.getMember3())){
                    ref.child("StoryGroupPending").child(SID).child("Member3").setValue("");
                }

                if (email1.equals(mod.getMember4())){
                    ref.child("StoryGroupPending").child(SID).child("Member4").setValue("");
                }

                if (email1.equals(mod.getMember5())){
                    ref.child("StoryGroupPending").child(SID).child("Member5").setValue("");
                }
            }
        });

    }
}
