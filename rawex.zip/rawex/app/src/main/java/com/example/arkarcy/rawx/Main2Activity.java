package com.example.arkarcy.rawx;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.SearchView;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.miguelcatalan.materialsearchview.MaterialSearchView;

public class Main2Activity extends AppCompatActivity
        implements PopularityRec.OnFragmentInteractionListener,TrendingBooksPopularity.OnFragmentInteractionListener, AllBooks.OnFragmentInteractionListener,NavigationView.OnNavigationItemSelectedListener ,BookListFragment.OnFragmentInteractionListener,searched_Book.OnFragmentInteractionListener,Book_tab.OnFragmentInteractionListener,Home.OnFragmentInteractionListener,Map_Fragment.OnFragmentInteractionListener{
   // private MaterialSearchView searchView;
    private Toolbar toolbar;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference ref = database.getReference("Users");
    private FirebaseUser mAuth2 = FirebaseAuth.getInstance().getCurrentUser();
    private static final int MY_PERMISSION_ACCESS_COARSE_LOCATION = 11;
    private static final int MY_INTERNET =11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //searchView =  findViewById(R.id.search_view);


        setSupportActionBar(toolbar);

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }



       /* if (ActivityCompat.checkSelfPermission(this , android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this , android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_COARSE_LOCATION}, MY_PERMISSION_ACCESS_COARSE_LOCATION);
        }*/
        ref.child(mAuth2.getUid()).child("UID").setValue(mAuth2.getUid());
        ref.child(mAuth2.getUid()).child("Email").setValue(mAuth2.getEmail());
        ref.child(mAuth2.getUid()).child("Name").setValue("one");

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this , drawer , toolbar , R.string.navigation_drawer_open , R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
        View headerView = navigationView.getHeaderView(0);
        TextView navUsername = (TextView) headerView.findViewById(R.id.emailID);
        navUsername.setText(mAuth2.getEmail().toString());

        if(savedInstanceState==null) {
                //working old one
            //getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new BookListFragment()).commit();
            //added 10/29/2018
            getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new Home()).commit();
           // navigationView.setCheckedItem(R.id.nav_bookcat);
        }
/*
        if (android.os.Build.VERSION.SDK_INT > 9)
        {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            Server server = new Server();
            Toast.makeText(this , server.fetch() , Toast.LENGTH_SHORT).show();
        }
*/


       // searchViewCode();
       // searchView.closeSearch();
    }




    /* private void searchViewCode() {
                searchView = (MaterialSearchView) findViewById(R.id.search_view);
               // searchView.setSuggestions(getResources().getStringArray(R.array.query_suggestions));
                searchView.setEllipsize(true);
                searchView.setOnQueryTextListener(new MaterialSearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        Toast.makeText(getApplicationContext(), query, Toast.LENGTH_SHORT).show();

                        getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new searched_Book(query)).addToBackStack(null).commit();
                        return false;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        return false;
                    }
                });
                searchView.setOnSearchViewListener(new MaterialSearchView.SearchViewListener() {
                    @Override
                    public void onSearchViewShown() {
                    }

                    @Override
                    public void onSearchViewClosed() {
                    }
                });
            }*/
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        }
       /* else  if (searchView.isSearchOpen()) {
            searchView.closeSearch();
        } */else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main2 , menu);
       // MenuItem item = menu.findItem(R.id.action_search);


        MenuItem searchMenu = menu.findItem(R.id.action_search);

        // Get SearchView object.
        SearchView searchView = (SearchView) MenuItemCompat.getActionView(searchMenu);

        // Get SearchView autocomplete object.
        final SearchView.SearchAutoComplete searchAutoComplete = (SearchView.SearchAutoComplete)searchView.findViewById(android.support.v7.appcompat.R.id.search_src_text);
        searchAutoComplete.setBackgroundColor(Color.WHITE);
        searchAutoComplete.setTextColor(Color.BLACK);
        searchAutoComplete.setDropDownBackgroundResource(android.R.color.white);

        // Create a new ArrayAdapter and add data to search auto complete object.
        String dataArr[] = getApplicationContext().getResources().getStringArray(R.array.bookname);
        ArrayAdapter<String> newsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_dropdown_item_1line, dataArr);
        searchAutoComplete.setAdapter(newsAdapter);

        // Listen to search view item on click event.
        searchAutoComplete.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int itemIndex, long id) {
                String queryString=(String)adapterView.getItemAtPosition(itemIndex);
                getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new searched_Book(queryString)).addToBackStack(null).commit();
                searchAutoComplete.setText("" + queryString);
                //Toast.makeText(getApplicationContext(), "you clicked " + queryString, Toast.LENGTH_LONG).show();
            }
        });

        // Below event is triggered when submit search query.
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {

                getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new searched_Book(query)).addToBackStack(null).commit();
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        if(id == R.id.action_search){

            return true;
        }
        if(id == R.id.action_signout)
        {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(Main2Activity.this,Login.class));
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_bookcat) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new BookListFragment()).commit();
        } else if (id == R.id.nav_trends) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new TrendingBooksPopularity()).commit();
        } else if (id == R.id.nav_story) {
            startActivity(new Intent(Main2Activity.this,story.class));
        }else if (id == R.id.nav_recommendation) {
            getSupportFragmentManager().beginTransaction().replace(R.id.frameofbooks , new PopularityRec()).commit();
        } else if (id == R.id.nav_share) {
            Intent sharingIntent = new Intent(android.content.Intent.ACTION_SEND);
            sharingIntent.setType("text/plain");
            String shareBody = "If you haven't installed yet installed it now....";
            sharingIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "RawEx");
            sharingIntent.putExtra(android.content.Intent.EXTRA_TEXT, shareBody);
            startActivity(Intent.createChooser(sharingIntent, "Share via"));

        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
    @Override
    public void onFragmentInteraction(Uri uri) {

    }




}
