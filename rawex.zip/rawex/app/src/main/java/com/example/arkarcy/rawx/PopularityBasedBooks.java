package com.example.arkarcy.rawx;

public class PopularityBasedBooks {
    private String BookName,BookRating,BookVoteCount,ISBN;

    public PopularityBasedBooks() {
    }

    public PopularityBasedBooks(String bookName , String bookRating , String bookVoteCount , String ISBN) {
        BookName = bookName;
        BookRating = bookRating;
        BookVoteCount = bookVoteCount;
        this.ISBN = ISBN;
    }

    public String getBookName() {
        return BookName;
    }

    public void setBookName(String bookName) {
        BookName = bookName;
    }

    public String getBookRating() {
        return BookRating;
    }

    public void setBookRating(String bookRating) {
        BookRating = bookRating;
    }

    public String getBookVoteCount() {
        return BookVoteCount;
    }

    public void setBookVoteCount(String bookVoteCount) {
        BookVoteCount = bookVoteCount;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }
}
