package com.example.arkarcy.rawx;

import java.io.Serializable;

public class modelSavedStoryGroup implements Serializable {
    private static final long serialVersionUID = 1L;
    private String SID,Title,Type,UID,Content1,Content2,Content3,Content4,Content5,Name1,Name2,Name3,Name4,Name5,Member1,Member2,Member3,Member4,Member5;

    public modelSavedStoryGroup(String SID, String title, String type, String UID, String content1, String content2, String content3, String content4, String content5, String name1, String name2, String name3, String name4, String name5, String member1, String member2, String member3, String member4, String member5) {
        this.SID = SID;
        Title = title;
        Type = type;
        this.UID = UID;
        Content1 = content1;
        Content2 = content2;
        Content3 = content3;
        Content4 = content4;
        Content5 = content5;
        Name1 = name1;
        Name2 = name2;
        Name3 = name3;
        Name4 = name4;
        Name5 = name5;
        Member1 = member1;
        Member2 = member2;
        Member3 = member3;
        Member4 = member4;
        Member5 = member5;
    }

    public modelSavedStoryGroup() {

    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public String getSID() {
        return SID;
    }

    public void setSID(String SID) {
        this.SID = SID;
    }

    public String getTitle() {
        return Title;
    }

    public void setTitle(String title) {
        Title = title;
    }

    public String getType() {
        return Type;
    }

    public void setType(String type) {
        Type = type;
    }

    public String getUID() {
        return UID;
    }

    public void setUID(String UID) {
        this.UID = UID;
    }

    public String getContent1() {
        return Content1;
    }

    public void setContent1(String content1) {
        Content1 = content1;
    }

    public String getContent2() {
        return Content2;
    }

    public void setContent2(String content2) {
        Content2 = content2;
    }

    public String getContent3() {
        return Content3;
    }

    public void setContent3(String content3) {
        Content3 = content3;
    }

    public String getContent4() {
        return Content4;
    }

    public void setContent4(String content4) {
        Content4 = content4;
    }

    public String getContent5() {
        return Content5;
    }

    public void setContent5(String content5) {
        Content5 = content5;
    }

    public String getName1() {
        return Name1;
    }

    public void setName1(String name1) {
        Name1 = name1;
    }

    public String getName2() {
        return Name2;
    }

    public void setName2(String name2) {
        Name2 = name2;
    }

    public String getName3() {
        return Name3;
    }

    public void setName3(String name3) {
        Name3 = name3;
    }

    public String getName4() {
        return Name4;
    }

    public void setName4(String name4) {
        Name4 = name4;
    }

    public String getName5() {
        return Name5;
    }

    public void setName5(String name5) {
        Name5 = name5;
    }

    public String getMember1() {
        return Member1;
    }

    public void setMember1(String member1) {
        Member1 = member1;
    }

    public String getMember2() {
        return Member2;
    }

    public void setMember2(String member2) {
        Member2 = member2;
    }

    public String getMember3() {
        return Member3;
    }

    public void setMember3(String member3) {
        Member3 = member3;
    }

    public String getMember4() {
        return Member4;
    }

    public void setMember4(String member4) {
        Member4 = member4;
    }

    public String getMember5() {
        return Member5;
    }

    public void setMember5(String member5) {
        Member5 = member5;
    }
}

