package com.example.arkarcy.rawx;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.Serializable;

public class story_group_member extends AppCompatActivity {
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser,mCurrentUser1;
    private DatabaseReference mUserDatabase,mUserDatabase1;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    EditText e1,e2,e3;
    TextView t1;
    Button b1,b2,b3;
    int SID1,SID2;
    String res="";
    //String t1,t2,t3,t4,t5;
    public String m5 = "",m2 = "",m3 = "",m4 = "";
    public String content,name,sid,title;
    String fetch2="", fetch3="", fetch4="", fetch5="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_group_member);

        getSupportActionBar().setTitle("Shared Story");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP){
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        Intent intent = getIntent();
        final modelSharedStory mod = (modelSharedStory) intent.getSerializableExtra("pass");

        e1 = findViewById(R.id.title);
        e2 = findViewById(R.id.story);
        e3 = findViewById(R.id.userName);
        b1 = findViewById(R.id.submit);
        b2 = findViewById(R.id.seeStory);
        b3 = findViewById(R.id.save);
        t1 = findViewById(R.id.id);

        t1.setText(mod.getSID());
        e1.setText(mod.getTitle());

        String email = mAuth.getEmail();
        email = email.replaceAll("[^a-zA-Z0-9]", "");
        String lowerCase = email.toLowerCase();
        //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
        final String finalEmail = lowerCase;
        final String finalEmail1 = mAuth.getEmail();

        try{
            if  (finalEmail1.equals(mod.getMember2())){
                e1.setText(mod.getTitle());
                e2.setText(mod.getContent2());
                e3.setText(mod.getName2());
            }

            if  (finalEmail1.equals(mod.getMember3())){
                e1.setText(mod.getTitle());
                e2.setText(mod.getContent3());
                e3.setText(mod.getName3());
            }

            if  (finalEmail1.equals(mod.getMember4())){
                e1.setText(mod.getTitle());
                e2.setText(mod.getContent4());
                e3.setText(mod.getName4());
            }

            if  (finalEmail1.equals(mod.getMember5())){
                e1.setText(mod.getTitle());
                e2.setText(mod.getContent5());
                e3.setText(mod.getName5());
            }
        }
        catch(Exception e){

        }

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if  (finalEmail1.equals(mod.getMember2())){
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name2").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content2").setValue(e2.getText().toString().trim());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("Type").setValue("Group");

                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryListingShared").child(mod.getSID()).child("UID").setValue(mAuth.getEmail());
                    //ref.child("StoryListingShared").child(String.valueOf(SID1)).child("PartNo").setValue("1");
                    ref.child("StoryListingShared").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Content").setValue(e2.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Name").setValue(e3.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("ViewCount").setValue(0);
                    ref.child("StoryListingShared").child(mod.getSID()).child("Like").setValue(0);

                    ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(mod.getSID()).removeValue();
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).removeValue();
                    finish();
                }

                if  (finalEmail1.equals(mod.getMember3())){
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name3").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content3").setValue(e2.getText().toString().trim());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("Type").setValue("Group");

                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryListingShared").child(mod.getSID()).child("UID").setValue(mAuth.getEmail());
                    //ref.child("StoryListingShared").child(String.valueOf(SID1)).child("PartNo").setValue("1");
                    ref.child("StoryListingShared").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Content").setValue(e2.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Name").setValue(e3.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("ViewCount").setValue(0);
                    ref.child("StoryListingShared").child(mod.getSID()).child("Like").setValue(0);

                    ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(mod.getSID()).removeValue();
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).removeValue();
                    finish();
                }

                if  (finalEmail1.equals(mod.getMember4())){
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name4").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content4").setValue(e2.getText().toString().trim());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("Type").setValue("Group");

                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryListingShared").child(mod.getSID()).child("UID").setValue(mAuth.getEmail());
                    //ref.child("StoryListingShared").child(String.valueOf(SID1)).child("PartNo").setValue("1");
                    ref.child("StoryListingShared").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Content").setValue(e2.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Name").setValue(e3.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("ViewCount").setValue(0);
                    ref.child("StoryListingShared").child(mod.getSID()).child("Like").setValue(0);

                    ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(mod.getSID()).removeValue();
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).removeValue();
                    finish();
                }

                if  (finalEmail1.equals(mod.getMember5())){
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name5").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content5").setValue(e2.getText().toString().trim());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("Type").setValue("Group");

                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("StoryShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryListingShared").child(mod.getSID()).child("UID").setValue(mAuth.getEmail());
                    //ref.child("StoryListingShared").child(String.valueOf(SID1)).child("PartNo").setValue("1");
                    ref.child("StoryListingShared").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Content").setValue(e2.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Name").setValue(e3.getText().toString().trim());
                    ref.child("StoryListingShared").child(mod.getSID()).child("Type").setValue("Shared");
                    ref.child("StoryListingShared").child(mod.getSID()).child("ViewCount").setValue(0);
                    ref.child("StoryListingShared").child(mod.getSID()).child("Like").setValue(0);

                    ref.child("StoryUser").child(finalEmail).child("SharedWithMeSave").child(mod.getSID()).removeValue();
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).removeValue();
                    finish();
                }
                /*ref.child(finalEmail).child(mod.getSID());
                ref.child(finalEmail).child(mod.getSID()).child("SID").setValue(mod.getSID());
                ref.child(finalEmail).child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                ref.child(finalEmail).child(mod.getSID()).setValue(e2.getText().toString().trim());*/
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),SoloStoryDetail.class);
                intent.putExtra("pass", (Serializable) mod);
                intent.putExtra("act","A");
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(intent);
            }
        });

        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(story_group_member.this, finalEmail1.toString(), Toast.LENGTH_SHORT).show();
                if  (finalEmail1.equals(mod.getMember2())){
                    //Toast.makeText(story_group_member.this, "Jarvis", Toast.LENGTH_SHORT).show();
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name2").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content2").setValue(e2.getText().toString().trim());

                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("Type").setValue("True");
                    finish();
                }

                if  (finalEmail1.equals(mod.getMember3())){
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name3").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content3").setValue(e2.getText().toString().trim());

                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("Type").setValue("True");
                    finish();
                }

                if  (finalEmail1.equals(mod.getMember4())){
                    Toast.makeText(story_group_member.this, "Jarvis", Toast.LENGTH_SHORT).show();
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name4").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content4").setValue(e2.getText().toString().trim());

                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("Type").setValue("True");
                    finish();
                }

                if  (finalEmail1.equals(mod.getMember5())){
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name5").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content5").setValue(e2.getText().toString().trim());

                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    //ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("Type").setValue("True");
                    finish();
                }
            }
        });
    }
}
