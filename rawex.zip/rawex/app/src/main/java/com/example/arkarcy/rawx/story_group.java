package com.example.arkarcy.rawx;

import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;

public class story_group extends AppCompatActivity {

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private FirebaseUser mCurrentUser, mCurrentUser1;
    private DatabaseReference mUserDatabase, mUserDatabase1;
    private DatabaseReference ref = database.getReference("Story");
    private FirebaseUser mAuth = FirebaseAuth.getInstance().getCurrentUser();
    EditText e1, e2, e3;
    TextView t1;
    Button b1, b2, b3;
    int SID1, SID2;
    String res = "";
    //String t1,t2,t3,t4,t5;
    public String m5 = "", m2 = "", m3 = "", m4 = "";
    public String content, name, sid, title;
    String fetch2 = "", fetch3 = "", fetch4 = "", fetch5 = "";

    @Override
    protected void onPostResume() {
        super.onPostResume();

        try {
            mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
            String current_uid = mCurrentUser.getUid();
            mUserDatabase = FirebaseDatabase.getInstance().getReference();

            mUserDatabase.child("Story").child("StoryGroupPending").child(String.valueOf(SID1)).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    m2 = (String) dataSnapshot.child("Member2").getValue();
                    m3 = (String) dataSnapshot.child("Member3").getValue();
                    m4 = (String) dataSnapshot.child("Member4").getValue();
                    m5 = (String) dataSnapshot.child("Member5").getValue();
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        } catch (Exception e) {
            Log.d("Exception", String.valueOf(e));
            Log.d("Exception Caught", "Found");
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_story_group);

        Intent i1 = getIntent();
        res = i1.getStringExtra("act");

        getSupportActionBar().setTitle("Story Group");

        getSupportActionBar().setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.camera_light)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(R.color.camera_dark));
        }

        e1 = findViewById(R.id.title);
        e2 = findViewById(R.id.story);
        e3 = findViewById(R.id.userName);
        b1 = findViewById(R.id.submit);
        b2 = findViewById(R.id.invite);
        b3 = findViewById(R.id.save);
        t1 = findViewById(R.id.id);

        if (res.equals("A")) {
            Intent intent = getIntent();
            final modelSavedStoryGroup mod = (modelSavedStoryGroup) intent.getSerializableExtra("pass");
            try {
                if (!mod.getSID().equals("") || !mod.getTitle().equals("") || !mod.getContent1().equals("") || !mod.getName1().equals("")) {
                    t1.setText(mod.getSID());
                    e1.setText(mod.getTitle());
                    e2.setText(mod.getContent1());
                    e3.setText(mod.getName1());
                }
            } catch (Exception e) {
            }

            String email = mAuth.getEmail();
            email = email.replaceAll("[^a-zA-Z0-9]", "");
            String lowerCase = email.toLowerCase();
            //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
            final String finalEmail = lowerCase;

            /*ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Member1").setValue("");
            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Member2").setValue("");
            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Member3").setValue("");
            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Member4").setValue("");
            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Member5").setValue("");*/

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    ref.child("StoryListingGroup").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Title").setValue(mod.getTitle());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Type").setValue(mod.getType());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("UID").setValue(mod.getUID());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Content1").setValue(mod.getContent1());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Content2").setValue(mod.getContent2());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Content3").setValue(mod.getContent3());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Content4").setValue(mod.getContent4());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Content5").setValue(mod.getContent5());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Name1").setValue(mod.getName1());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Name2").setValue(mod.getName2());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Name3").setValue(mod.getName3());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Name4").setValue(mod.getName4());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Name5").setValue(mod.getName5());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Member1").setValue(mod.getMember1());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Member2").setValue(mod.getMember2());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Member3").setValue(mod.getMember3());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Member4").setValue(mod.getMember4());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Member5").setValue(mod.getMember5());
                    ref.child("StoryListingGroup").child(mod.getSID()).child("ViewCount").setValue(0);
                    ref.child("StoryListingGroup").child(mod.getSID()).child("Like").setValue(0);

                    Date c = Calendar.getInstance().getTime();
                    String DateTime = String.valueOf(c);
                    System.out.println("Current time => " + DateTime);
                    ref.child("StoryListingGroup").child(mod.getSID()).child("DateTime").setValue(DateTime);

                    ref.child("StoryGroupPending").child(mod.getSID()).removeValue();
                    ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).removeValue();
                    ref.child("StoryUser").child(finalEmail).child("UID").setValue(String.valueOf(finalEmail));
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Story").child(mod.getSID()).child("Type").setValue("Group");

                    finish();
                }
            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent i = new Intent(getApplicationContext(), addMember.class);
                    i.putExtra("SID", mod.getSID());
                    i.putExtra("Title", e1.getText().toString().trim());
                    i.putExtra("Story", e2.getText().toString().trim());
                    i.putExtra("pass", (Serializable) mod);
                    startActivity(i);
                }
            });

            b3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    ref.child("StoryGroupPending").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("UID").setValue(mAuth.getEmail());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Type").setValue("Group");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content1").setValue(e2.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name1").setValue(e3.getText().toString().trim());
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name2").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name3").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name4").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Name5").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content2").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content3").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content4").setValue("");
                    ref.child("StoryGroupPending").child(mod.getSID()).child("Content5").setValue("");

                    ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("SID").setValue(mod.getSID());
                    ref.child("StoryUser").child(finalEmail).child("Pending").child(mod.getSID()).child("Type").setValue("Group");

                    try {
                        ref.child("StoryUser").child(finalEmail).child("SavedStories").child(mod.getSID()).removeValue();
                    } catch (Exception e) {
                        Log.d("Exe", String.valueOf(e));
                        Log.d("Exe Caught", "Found");
                    }
                    finish();

                }
            });

        } else if (res.equals("B")) {
            String email = mAuth.getEmail();
            email = email.replaceAll("[^a-zA-Z0-9]", "");
            String lowerCase = email.toLowerCase();
            //Toast.makeText(story_solo.this, email.toString(), Toast.LENGTH_SHORT).show();
            final String finalEmail = lowerCase;


            b1.setVisibility(View.INVISIBLE);

            b1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    try {
                        if (m2.equals("") && m3.equals("") && m4.equals("") && m5.equals("")) {
                            Toast.makeText(story_group.this, "Please add atleast 1 member", Toast.LENGTH_SHORT).show();
                        } else {
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("UID").setValue(mAuth.getEmail());
                            //ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("PartNo").setValue("1");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Title").setValue(e1.getText().toString().trim());
                            //ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Content").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Type").setValue("Group");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Content1").setValue(e2.getText().toString().trim());
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Name1").setValue(e3.getText().toString().trim());
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Name2").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Name3").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Name4").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Name5").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Content2").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Content3").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Content4").setValue("");
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("Content5").setValue("");

                            Date c = Calendar.getInstance().getTime();
                            String DateTime = String.valueOf(c);
                            System.out.println("Current time => " + DateTime);
                            ref.child("StoryListingGroup").child(String.valueOf(SID1)).child("DateTime").setValue(DateTime);


                            //ref.child("StoryListingGroup").child("Member1").setValue("Solo");

                            ref.child("StoryUser").child(finalEmail).child("UID").setValue(String.valueOf(finalEmail));
                            ref.child("StoryUser").child(finalEmail).child("Story").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
                            ref.child("StoryUser").child(finalEmail).child("Story").child(String.valueOf(SID1)).child("Type").setValue("Group");

                            //finish();

                        }
                    } catch (Exception e) {
                        Toast.makeText(story_group.this, "Please add atleast 1 member", Toast.LENGTH_SHORT).show();
                    }

                    try {
                        ref.child("StoryUser").child(finalEmail).child("SavedStories").child(String.valueOf(SID1)).removeValue();
                    } catch (Exception e) {
                        Log.d("Exe", String.valueOf(e));
                        Log.d("Exe Caught", "Found");
                    }

                    try {
                        mCurrentUser = FirebaseAuth.getInstance().getCurrentUser();
                        String current_uid = mCurrentUser.getUid();
                        mUserDatabase = FirebaseDatabase.getInstance().getReference();

                        mUserDatabase.child("Story").child("StoryGroupPending").child(String.valueOf(SID1)).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                m2 = (String) dataSnapshot.child("Member2").getValue();
                                m3 = (String) dataSnapshot.child("Member3").getValue();
                                m4 = (String) dataSnapshot.child("Member4").getValue();
                                m5 = (String) dataSnapshot.child("Member5").getValue();
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    } catch (Exception e) {
                        Log.d("Exception", String.valueOf(e));
                        Log.d("Exception Caught", "Found");
                    }

                }
            });

            b2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    //ref.child(finalEmail).child(String.valueOf(SID1)).child("GlobalMember").setValue(String.valueOf(1));

                    Intent i = new Intent(getApplicationContext(), addMember.class);
                    i.putExtra("SID", String.valueOf(SID1));
                    i.putExtra("Title", e1.getText().toString().trim());
                    i.putExtra("Story", e2.getText().toString().trim());
                    startActivity(i);
                    //startActivity(new Intent(getApplicationContext(),addMember.class));
                }
            });


            b3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    /*ref.child("StoryUser").child(finalEmail).child("SavedStories").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
                    ref.child("StoryUser").child(finalEmail).child("SavedStories").child(String.valueOf(SID1)).child("Name").setValue(e3.getText().toString().trim());
                    ref.child("StoryUser").child(finalEmail).child("SavedStories").child(String.valueOf(SID1)).child("Title").setValue(e1.getText().toString().trim());
                    ref.child("StoryUser").child(finalEmail).child("SavedStories").child(String.valueOf(SID1)).child("Content").setValue(e2.getText().toString().trim());
                    ref.child("StoryUser").child(finalEmail).child("SavedStories").child(String.valueOf(SID1)).child("Type").setValue("Group");*/
                    try {
                        if (m2.length() == 0 && m3.length() == 0 && m4.length() == 0 && m5.length() == 0) {
                            //  if (m2.equals(null) && m3.equals(null) && m4.equals(null) && m5.equals(null)) {
                            Toast.makeText(story_group.this, "Please add atleast 1 member", Toast.LENGTH_SHORT).show();
                        } else {
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("UID").setValue(mAuth.getEmail());
                            //ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("PartNo").setValue("1");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Title").setValue(e1.getText().toString().trim());
                            //ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Content").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Type").setValue("Group");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Content1").setValue(e2.getText().toString().trim());
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Name1").setValue(e3.getText().toString().trim());
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Name2").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Name3").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Name4").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Name5").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Content2").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Content3").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Content4").setValue("");
                            ref.child("StoryGroupPending").child(String.valueOf(SID1)).child("Content5").setValue("");

                            //ref.child("StoryGroupPending").child("Member1").setValue("Solo");

                            ref.child("StoryUser").child(finalEmail).child("Pending").child("UID").setValue(String.valueOf(finalEmail));
                            ref.child("StoryUser").child(finalEmail).child("Pending").child(String.valueOf(SID1)).child("SID").setValue(String.valueOf(SID1));
                            ref.child("StoryUser").child(finalEmail).child("Pending").child(String.valueOf(SID1)).child("Type").setValue("Group");

                            finish();

                        }
                    } catch (Exception e) {
                        Toast.makeText(story_group.this, "Please add atleast 1 member", Toast.LENGTH_SHORT).show();
                    }

                    try {
                        ref.child("StoryUser").child(finalEmail).child("SavedStories").child(String.valueOf(SID1)).removeValue();
                    } catch (Exception e) {
                        Log.d("Exe", String.valueOf(e));
                        Log.d("Exe Caught", "Found");
                    }
                }
            });

            mCurrentUser1 = FirebaseAuth.getInstance().getCurrentUser();
            String current_uid = mCurrentUser1.getUid();
            mUserDatabase1 = FirebaseDatabase.getInstance().getReference().child("Story");
            //mUserDatabase.keepSynced(true);

            mUserDatabase1.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    SID1 = Integer.parseInt(dataSnapshot.child("GlobalStoryID").getValue().toString());
                    t1.setText(String.valueOf(SID1));
                    SID2 = SID1 + 1;
                    mUserDatabase1.child("GlobalStoryID").setValue(SID2);
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {

                }
            });
        }
    }
}
