package com.example.arkarcy.rawx;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.List;

public class storyHolderSavedSolo extends RecyclerView.Adapter<storyHolderSavedSolo.MyViewHolder> {

    private Context mContext;
    private List<modelSavedStorySolo> mDataList;
    private RecyclerView.Adapter adapter;

    public storyHolderSavedSolo(Context mContext, List<modelSavedStorySolo> mDataList) {
        this.mContext = mContext;
        this.mDataList = mDataList;
    }

    @NonNull
    @Override
    public storyHolderSavedSolo.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.model,viewGroup,false);
        return new storyHolderSavedSolo.MyViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull storyHolderSavedSolo.MyViewHolder myViewHolder, int i) {
        final modelSavedStorySolo mod = mDataList.get(i);

        try {
            myViewHolder.title1.setText(mod.getTitle());
            myViewHolder.story1.setText(mod.getContent());
            myViewHolder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.e("Story", mod.getContent());
                    Intent intent = new Intent(mContext, story_solo.class);
                    intent.putExtra("pass", (Serializable) mod);
                    intent.putExtra("act", "A");
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(intent);

                }
            });
        }
        catch (Exception e){}
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{


        TextView title1,story1;
        View mView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            title1 = itemView.findViewById(R.id.title);
            story1 = itemView.findViewById(R.id.story);

        }
    }
}
