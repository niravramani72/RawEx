package com.example.arkarcy.rawx;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.List;

public class storyHolderGroup  extends RecyclerView.Adapter<storyHolderGroup.MyViewHolder> {

    private Context mContext;
    private List<modelStoryGroup> mDataList;


    public storyHolderGroup(Context mContext, List<modelStoryGroup> mDataList) {
        this.mContext = mContext;
        this.mDataList = mDataList;
    }

    @NonNull
    @Override
    public storyHolderGroup.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.model,viewGroup,false);
        return new storyHolderGroup.MyViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull storyHolderGroup.MyViewHolder myViewHolder, int i) {
        final modelStoryGroup mod = mDataList.get(i);
        try{
        myViewHolder.title1.setText(mod.getTitle());
        myViewHolder.story1.setText(mod.getUID());
        myViewHolder.mView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mContext,GroupStoryDetail.class);
                intent.putExtra("pass", (Serializable) mod);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                mContext.startActivity(intent);


            }
        });}
        catch (Exception e){}
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{


        TextView title1,story1;
        View mView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            title1 = itemView.findViewById(R.id.title);
            story1 = itemView.findViewById(R.id.story);
        }
    }
}
