package com.example.arkarcy.rawx;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.io.Serializable;
import java.util.List;

public class storyHolder  extends RecyclerView.Adapter<storyHolder.MyViewHolder> {

    private Context mContext;
    private List<modelStory> mDataList;


    public storyHolder(Context mContext, List<modelStory> mDataList) {
        this.mContext = mContext;
        this.mDataList = mDataList;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View rootView = LayoutInflater.from(mContext).inflate(R.layout.model,viewGroup,false);
        return new MyViewHolder(rootView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        final modelStory mod = mDataList.get(i);
        try{
            myViewHolder.title1.setText(mod.getTitle());
            myViewHolder.story1.setText(mod.getContent());
            myViewHolder.mView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Log.e("Story",mod.getContent());
                    Intent intent = new Intent(mContext,SoloStoryDetail.class);
                    intent.putExtra("act","B");
                    intent.putExtra("pass", (Serializable) mod);
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    mContext.startActivity(intent);


                }
            });
            /*myViewHolder.mView.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    openDialog(mContext);
                    return false;
                }
            });*/
        }
        catch(Exception e){}
    }

    private void openDialog(Context context) {
        AlertDialog alertDialog = new AlertDialog.Builder(context).create(); //Use context
        alertDialog.setTitle("Warning");
        alertDialog.setMessage("You are currently in a battle");
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
        alertDialog.show();
    }

    @Override
    public int getItemCount() {
        return mDataList.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{


        TextView title1,story1;
        View mView;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;
            title1 = itemView.findViewById(R.id.title);
            story1 = itemView.findViewById(R.id.story);
        }
    }
}
